import useWebSocket from '@/hooks/useWebSocket'

const useVariable = defineStore('variable', {
  state: () => ({
    variables: {}
  }),
  actions: {
    init() {
      const { message } = useWebSocket(import.meta.env.VITE_WS_URL + '/pub/var')
      message((data) => {
        this.setVariable(data)
      })
    },
    setVariable(variable) {
      for (let key in variable) {
        this.variables[key] = variable[key]
      }
    }
  }
})

export default useVariable
