export const defaultData = {
  container: {
    markline: {
      show: true,
      color: ''
    },
    snapToGrid: true,
    gridSize: 10,
    gridColor: '',
    style: {},
    scaleRatio: 1
  },
  elements: [],
  events: []
}

export const useDeviceConfiguratorStore = defineStore('deviceConfigurator', () => {
  const data = ref(defaultData)
  const current = ref({})
  const otherElements = reactive([])
  const preview = ref(false)
  const initWidth = ref(1600)
  const initHeight = ref(900)
  const theme = ref(localStorage.getItem('theme') || 'light')

  function update(val) {
    if (!val.container) {
      val.container = { ...defaultData.container }
    }
    data.value = val || {}
  }

  return {
    data,
    current,
    otherElements,
    preview,
    initWidth,
    initHeight,
    theme,
    update
  }
})
