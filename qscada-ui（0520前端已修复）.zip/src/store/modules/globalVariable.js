import { defineStore } from 'pinia'

const { data } = useWebSocket(import.meta.env.VITE_WS_URL + '/pub/var')

export const useGlobalVariableStore = defineStore('globalVariable', () => {
  const variables = reactive({})

  watch(data, (val) => {
    setGlobalVariable(val)
  })
  function setGlobalVariable(vars) {
    const temp = typeof vars === 'string' ? JSON.parse(vars) : vars
    for (let [key, value] of Object.entries(temp)) {
      variables[key] = value
    }
  }

  return { variables, setGlobalVariable }
})
