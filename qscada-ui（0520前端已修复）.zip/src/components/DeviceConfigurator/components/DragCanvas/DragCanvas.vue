<script setup>
import { useDeviceConfiguratorStore } from '@/store/modules/deviceConfigurator'
import { useEventBus } from '@vueuse/core'
import ESDrager from 'es-drager'
import 'es-drager/lib/style.css'
import { computed, useTemplateRef } from 'vue'
import { useActions } from '../../hooks/useActions'
import { useArea } from '../../hooks/useSelectArea'
import { omit, pickStyle } from '../../utils/style'
import { components } from '../Graphics'
import GridArea from '../GridArea'
import SelectArea from '../SelectArea'
import TextEditor from '../TextEditor'

defineOptions({
  components
})

const eventBus = useEventBus('drag-canvas')
const store = useDeviceConfiguratorStore()
const { modelValue } = defineProps({
  modelValue: {
    type: Object,
    required: true,
    default: () => ({})
  }
})
const data = computed({
  get: () => modelValue,
  set: () => {}
})

const canvasRef = useTemplateRef('canvasRef')
const areaRef = useTemplateRef('areaRef')
// 每次拖拽移动的距离
const extraDragData = ref({
  startX: 0,
  startY: 0,
  disX: 0,
  disY: 0
})
const current = computed({
  get: () => store.current,
  set: (val) => {
    store.current = val
  }
})
const { areaSelected, selectedID, onEditorMouseDown, onAreaMove, onAreaUp } = useArea(data, areaRef)

const { onWheel, onContextmenu, onEditorContextMenu } = useActions(data, canvasRef)

const gridSize = computed(() => data.value.container?.gridSize || 10)
const scaleRatio = computed(() => data.value.container?.scaleRatio || 1)
const canvasStyle = computed(() => {
  const { width, height, ...others } = data.value.container.style
  return {
    ...others,
    width: `${width}px`,
    height: `${height}px`,
    transform: `scale(${scaleRatio.value})`,
    transformOrigin: 'center center'
  }
})

watch(selectedID, (ids) => {
  if (ids.size) {
    const selectedElements = data.value.elements.filter((item) => ids.has(item.id))
    const isSame = !selectedElements.some((element, index, array) => {
      if (index === 0) {
        return false
      } else {
        return element.type != array[index - 1].type
      }
    })
    const firstElement = selectedElements.find((element) => {
      const [firstId] = ids
      return firstId === element.id
    })
    current.value = isSame ? firstElement : null
    if (isSame) {
      const others = selectedElements.filter((element) => {
        const [firstId] = ids
        return firstId !== element.id
      })
      store.otherElements.splice(0, store.otherElements.length, ...others)
    } else {
      store.otherElements.splice(0, store.otherElements.length)
    }
  } else {
    current.value = null
    store.otherElements.splice(0, store.otherElements.length)
  }
})

function onDragstart(element) {
  current.value = element
  if (!areaSelected.value) {
    const seletedItems = data.value.elements.filter((item) => item.selected)
    if (seletedItems.length === 1) {
      // 将上一次移动元素变为非选
      data.value.elements.forEach((item) => (item.selected = false))
    }
  }

  // 选中当前元素
  current.value.selected = true
  // 记录按下的数据，为了计算多个选中时移动的距离
  extraDragData.value.startX = current.value.left
  extraDragData.value.startY = current.value.top

  eventBus.emit('dragstart')
}

function onDragend() {
  eventBus.emit('dragend')
}
function onDrag(dragData) {
  const disX = dragData.left - extraDragData.value.startX
  const disY = dragData.top - extraDragData.value.startY

  // 如果选中了多个
  data.value.elements.forEach((item) => {
    if (item.selected && current.value?.id !== item.id) {
      item.left += disX
      item.top += disY
    }
  })

  extraDragData.value.startX = dragData.left
  extraDragData.value.startY = dragData.top
}

function onChange(dragData, item) {
  Object.keys(dragData).forEach((key) => {
    item[key] = dragData[key]
  })
}

const globalEventMap = {
  dblclick: () => {
    if (!current.value || !current.value.selected) return
    current.value.editable = true
  },
  click: () => {
    if (!current.value) return
    current.value.editable = false
  }
}

function setGlobalEvents(flag = 'on') {
  const eventTypes = ['dblclick', 'click']
  eventTypes.forEach((type) => {
    if (flag === 'on') {
      document.addEventListener(type, globalEventMap[type])
    } else {
      document.removeEventListener(type, globalEventMap[type])
    }
  })
}

onMounted(() => {
  setGlobalEvents()
})

onBeforeMount(() => {
  setGlobalEvents('off')
})
</script>

<template>
  <div
    class="drag-canvas"
    ref="canvasRef"
    :style="canvasStyle"
    @mousedown="onEditorMouseDown"
    @contextmenu.prevent="onEditorContextMenu"
    @wheel="onWheel">
    <template v-for="item in data.elements" :key="item.id">
      <ESDrager
        rotatable
        :class="{ selected: item.selected }"
        v-bind="omit(item, ['style', 'props'])"
        :grid-x="gridSize"
        :grid-y="gridSize"
        :scaleRatio="scaleRatio"
        boundary
        :markline="data.container.markline.show"
        snap
        :snap-threshold="data.container.gridSize"
        @drag-start="onDragstart(item)"
        @drag-end="onDragend"
        @drag="onDrag"
        @change="onChange($event, item)"
        @contextmenu.stop="onContextmenu($event, item)"
        @mousedown.stop
        @click.stop>
        <component
          :is="Object.hasOwn(components, item.component) ? components[item.component] : item.component"
          :element="item"
          v-bind="item.props"
          :style="{
            ...pickStyle(item.style, false),
            width: item.type != 'polyline' ? '100%' : '',
            height: item.type != 'polyline' ? '100%' : ''
          }">
          <TextEditor
            v-if="item.text"
            :editable="item.editable"
            v-model:text="item.text"
            :style="pickStyle(item.style)" />
        </component>
      </ESDrager>
    </template>
    <GridArea :showGrid="data.container.snapToGrid" :grid="gridSize" :border-color="data.container.gridColor" />
    <SelectArea ref="areaRef" @move="onAreaMove" @up="onAreaUp" />
  </div>
</template>

<style lang="scss" scoped>
.drag-canvas {
  box-sizing: border-box;
  position: relative;
  width: 100%;
  height: 100%;
  background-size: cover;
  background-repeat: no-repeat;
  background-position: center;
}

.es-drager {
  &.border {
    border-width: 0;
  }
  &.selected {
    border-width: 1px;
    border-style: dashed;
  }
  .es-drager-mask {
    display: none;
  }
}
</style>
