export { default } from './DragCanvas.vue'
