import { createVNode, render } from 'vue'
import ContextMenu from './ContextMenu.vue'

let vm = null
let cachedContainer
const selector = `device-configurator-selected-container`
export const useEditorContainer = () => {
  if (!cachedContainer && !document.querySelector(`#${selector}`)) {
    const container = document.createElement('div')
    container.id = selector
    cachedContainer = container
    document.body.appendChild(container)
  }

  return {
    container: cachedContainer,
    selector
  }
}
export function $contextMenu(option) {
  if (!vm) {
    const { container: globalContainer } = useEditorContainer()
    const container = document.createElement('div')
    vm = createVNode(ContextMenu, { option })

    // 将组件渲染成真实节点
    render(vm, container)

    globalContainer.appendChild(container.firstElementChild)
  }

  const { open } = vm.component.exposed
  open(option)
}
