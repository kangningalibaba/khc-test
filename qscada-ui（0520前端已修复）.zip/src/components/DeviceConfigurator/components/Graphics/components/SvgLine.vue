<template>
  <svg ref="svgRef">
    <line x1="0" :y1="height / 2" :x2="parentWidth" :y2="height / 2" :stroke="stroke" :stroke-width="strokeWidth" />
  </svg>
</template>

<script setup>
import { useElementSize, useParentElement } from '@vueuse/core'
import { computed } from 'vue'

defineProps({
  stroke: {
    type: String,
    default: 'black'
  },
  strokeWidth: {
    type: Number,
    default: 2
  }
})

const svgRef = useTemplateRef('svgRef')
const parentElement = useParentElement(svgRef)
const { width, height } = useElementSize(parentElement)

const parentWidth = computed(() => {
  return width.value
})
</script>

<style scoped>
svg {
  display: block;
  margin: 0 auto;
  width: 100%;
  height: 100%;
}
</style>
