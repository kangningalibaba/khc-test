<script setup>
import { useElementSize, useParentElement } from '@vueuse/core'
import { computed, useTemplateRef } from 'vue'

const { initialAngle, sides } = defineProps({
  initialAngle: {
    type: Number,
    default: 0
  },
  sides: {
    type: Number,
    default: 5
  },
  fill: {
    type: String,
    default: 'transparent'
  },
  fillRule: {
    type: String,
    default: 'evenodd'
  },
  stroke: {
    type: String,
    default: 'transparent'
  },
  strokeWidth: {
    type: Number,
    default: 1
  }
})

const svgRef = useTemplateRef('svgRef')
const parentElement = useParentElement(svgRef)
const { width, height } = useElementSize(parentElement)

const radius = computed(() => {
  return Math.min(width.value, height.value) / 2
})

const points = computed(() => {
  const centerX = width.value / 2
  const centerY = height.value / 2
  const angle = (Math.PI * 2) / sides

  const pointsData = []
  for (let i = 0; i < sides; i++) {
    const x = centerX + radius.value * Math.cos(i * angle + initialAngle)
    const y = centerY + radius.value * Math.sin(i * angle + initialAngle)
    pointsData.push(`${x},${y}`)
  }

  return sides % 2 === 0 ? pointsData.join(' ') : oddEvenSort(pointsData).join(' ')
})

function oddEvenSort(arr) {
  const odds = arr.filter((num) => num % 2 !== 0)
  const evens = arr.filter((num) => num % 2 === 0)
  return [...odds, ...evens]
}
</script>

<template>
  <svg ref="svgRef" :viewBox="`0 0 ${width} ${height}`" xmlns="http://www.w3.org/2000/svg">
    <polygon
      :points="points"
      :fill="fill"
      :fill-rule="fillRule"
      :stroke="stroke"
      :stroke-width="strokeWidth"
      vector-effect="non-scaling-stroke" />
    <foreignObject :width="width" :height="height">
      <slot />
    </foreignObject>
  </svg>
</template>
