<script setup>
import { useElementSize, useParentElement } from '@vueuse/core'
import { useTemplateRef } from 'vue'
defineProps({
  rx: {
    type: Number,
    default: 0
  },
  ry: {
    type: Number,
    default: 0
  },
  fill: {
    type: String,
    default: 'transparent'
  },
  stroke: {
    type: String,
    default: 'transparent'
  },
  strokeWidth: {
    type: Number,
    default: 1
  }
})

const svgRef = useTemplateRef('svgRef')
const parentElement = useParentElement(svgRef)
const { width, height } = useElementSize(parentElement)
</script>

<template>
  <svg ref="svgRef" version="1.1" xmlns="http://www.w3.org/2000/svg" :viewBox="`0 0 ${width} ${height}`">
    <rect
      :rx="rx"
      :ry="ry"
      :width="width"
      :height="height"
      :fill="fill"
      :stroke="stroke"
      :stroke-width="strokeWidth"
      vector-effect="non-scaling-stroke" />
    <foreignObject :width="width" :height="height">
      <slot />
    </foreignObject>
  </svg>
</template>
