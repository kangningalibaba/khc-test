<script setup>
import { useElementSize, useParentElement } from '@vueuse/core'
import { computed, useTemplateRef } from 'vue'
defineProps({
  fill: {
    type: String,
    default: 'transparent'
  },
  stroke: {
    type: String,
    default: 'transparent'
  },
  strokeWidth: {
    type: Number,
    default: 1
  }
})
const svgRef = useTemplateRef('svgRef')
const parentElement = useParentElement(svgRef)
const { width, height } = useElementSize(parentElement)
const points = computed(() => {
  return [
    `${width.value / 4},0`,
    `${(width.value / 4) * 3},0`,
    `${width.value},${height.value}`,
    `0,${height.value}`
  ].join(' ')
})
</script>

<template>
  <svg ref="svgRef" version="1.1" xmlns="http://www.w3.org/2000/svg" :viewBox="`0 0 ${width} ${height}`">
    <polygon
      :points="points"
      :fill="fill"
      :stroke="stroke"
      :stroke-width="strokeWidth"
      vector-effect="non-scaling-stroke" />
    <foreignObject :width="width" :height="height">
      <slot />
    </foreignObject>
  </svg>
</template>
