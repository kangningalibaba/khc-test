<script setup>
import { useElementSize, useParentElement } from '@vueuse/core'
import { useTemplateRef } from 'vue'

defineProps({
  status: {
    type: [Number, String],
    default: 0
  }
})

const svgRef = useTemplateRef('svgRef')
const parentElement = useParentElement(svgRef)
const { width, height } = useElementSize(parentElement)
/**
 * 计算圆弧上的点坐标
 * @param cx 圆心X坐标
 * @param cy 圆心Y坐标
 * @param outerRadius 外圆半径
 * @param segments 段数
 * @param centerRadius 中心园半径
 */
function calculateSegmentPoints(cx, cy, outerRadius, segments, centerRadius) {
  const points = []
  const angleStep = (2 * Math.PI) / segments // 每段的角度弧度

  for (let i = 0; i < segments; i++) {
    const angle = i * angleStep

    // 外圆上的点坐标
    const outerX = cx + outerRadius * Math.cos(angle)
    const outerY = cy + outerRadius * Math.sin(angle)

    // 中心圆上的点坐标
    const centerX = cx + centerRadius * Math.cos(angle)
    const centerY = cy + centerRadius * Math.sin(angle)

    // 将线段端点坐标存入数组
    points.push([
      [outerX, outerY],
      [centerX, centerY]
    ])
  }

  return points
}

const wheelRadius = computed(() => {
  return Math.max(height.value / 2 - 10, 0)
})

const points = computed(() => {
  return calculateSegmentPoints(
    wheelRadius.value + 10,
    wheelRadius.value + 10,
    wheelRadius.value * 0.8,
    8,
    wheelRadius.value * 0.3
  )
})
</script>

<template>
  <svg
    ref="svgRef"
    :class="[{ animate: status > 0, 'animate-reverse': status == 2 }]"
    width="100%"
    height="100%"
    xmlns="http://www.w3.org/2000/svg"
    :viewBox="`0 0 ${width} ${height}`">
    <defs>
      <g id="wheel" class="wheel" :style="{ transformOrigin: `${wheelRadius + 10}px ${wheelRadius + 10}px` }">
        <circle
          :cx="wheelRadius + 10"
          :cy="wheelRadius + 10"
          :r="wheelRadius"
          fill="transparent"
          stroke="black"
          stroke-width="2" />
        <circle
          :cx="wheelRadius + 10"
          :cy="wheelRadius + 10"
          :r="wheelRadius * 0.8"
          fill="transparent"
          stroke="grey"
          stroke-width="1" />
        <circle
          :cx="wheelRadius + 10"
          :cy="wheelRadius + 10"
          :r="wheelRadius * 0.3"
          fill="yellow"
          stroke="black"
          stroke-width="1" />
        <line
          v-for="(point, index) in points"
          :key="index"
          :x1="point[0][0]"
          :y1="point[0][1]"
          :x2="point[1][0]"
          :y2="point[1][1]"
          stroke="grey"
          stroke-width="1" />
      </g>
    </defs>
    <g :class="['conveyor', { animate: status > 0, 'animate-reverse': status == 2 }]">
      <rect
        class="belt"
        x="5"
        y="5"
        :rx="Math.max((height - 10) * 0.5, 0)"
        :ry="Math.max((height - 10) * 0.5, 0)"
        :width="Math.max(width - 10, 0)"
        :height="Math.max(height - 10, 0)" />
      <use xlink:href="#wheel" />
      <use xlink:href="#wheel" :x="width - wheelRadius * 2 - 20" />
    </g>
    <foreignObject :x="0" :y="0" :width="width" :height="height">
      <slot />
    </foreignObject>
  </svg>
</template>

<style lang="scss" scoped>
.conveyor {
  .belt {
    fill: transparent;
    stroke: black;
    stroke-width: 2;
    stroke-dasharray: 5;
  }
}

.animate {
  .belt {
    animation: clockwise-march-ingants 1s forwards infinite linear;
  }
  .wheel {
    animation: clockwise-rotate 20s forwards infinite linear;
  }
}
.animate-reverse {
  .belt {
    animation: clockwise-march-ingants-reverse 1s forwards infinite linear;
  }
  .wheel {
    animation: clockwise-rotate-reverse 20s forwards infinite linear;
  }
}

// 旋转
@keyframes clockwise-rotate {
  to {
    transform: rotate(360deg);
  }
}

@keyframes clockwise-rotate-reverse {
  to {
    transform: rotate(-360deg);
  }
}

@keyframes clockwise-march-ingants {
  to {
    stroke-dashoffset: -10;
  }
}

@keyframes clockwise-march-ingants-reverse {
  to {
    stroke-dashoffset: 10;
  }
}
</style>
