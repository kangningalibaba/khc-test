<script setup>
import { computed, onMounted, ref } from 'vue'

const points = ref([
  { x: 10, y: 10 },
  { x: 490, y: 10 }
])

const virtualAnchors = ref([]) // 虚拟锚点
const showAnchors = ref(false) // 控制是否显示锚点
const draggingIndex = ref(null)
const isVirtualAnchorClicked = ref(false) // 标记虚拟锚点是否已被点击
const isMoved = ref(false) // 新增：标记虚拟点是否发生移动

// 计算折线点字符串
const pointsString = computed(() => points.value.map((p) => `${p.x},${p.y}`).join(' '))

// 计算两点之间的虚拟锚点位置
const calculateVirtualAnchors = () => {
  virtualAnchors.value = []
  for (let i = 0; i < points.value.length - 1; i++) {
    const midX = (points.value[i].x + points.value[i + 1].x) / 2
    const midY = (points.value[i].y + points.value[i + 1].y) / 2
    virtualAnchors.value.push({ x: midX, y: midY })
  }
}

// 动态计算SVG宽高和viewBox
const svgWidth = ref(0)
const svgHeight = ref(0)
const viewBox = ref('') // 新增：用于存储viewBox值

// 更新SVG宽高和viewBox
const updateSvgDimensions = () => {
  const maxX = Math.max(...points.value.map((p) => p.x))
  const maxY = Math.max(...points.value.map((p) => p.y))
  const minX = Math.min(...points.value.map((p) => p.x))
  const minY = Math.min(...points.value.map((p) => p.y))

  // 添加边距
  const padding = 10
  svgWidth.value = maxX - minX + 2 * padding
  svgHeight.value = maxY - minY + 2 * padding

  // 计算viewBox
  viewBox.value = `${minX - padding} ${minY - padding} ${svgWidth.value} ${svgHeight.value}`
}

// 初始化
onMounted(() => {
  calculateVirtualAnchors()
  updateSvgDimensions() // 初始化时计算宽高和viewBox
})

// 拖动锚点
const dragAnchor = (event, index) => {
  event.preventDefault()
  const svgElement = event.target.closest('svg')
  if (!svgElement) {
    console.warn('SVG element not found in the event target.')
    return // 如果找不到 SVG 元素，直接退出函数
  }
  const svgRect = svgElement.getBoundingClientRect()
  const offsetX = event.clientX - svgRect.left
  const offsetY = event.clientY - svgRect.top

  // 如果是虚拟点且未移动，则不更新 points
  if (isVirtualAnchorClicked.value && !isMoved.value) {
    return
  }

  // 更新点的位置
  points.value[index] = { x: offsetX, y: offsetY }
  calculateVirtualAnchors() // 实时更新虚拟锚点
  updateSvgDimensions() // 更新SVG宽高和viewBox
}

// 开始拖动锚点
const startDrag = (index, event, isVirtual = false) => {
  event.preventDefault()
  if (isVirtual) {
    // 如果是虚拟锚点，标记为已点击但暂不插入新点
    isVirtualAnchorClicked.value = true
    isMoved.value = false // 重置移动标志
  } else {
    draggingIndex.value = index // 更新拖动索引
  }

  // 绑定拖动事件
  const onMouseMove = () => {
    event.preventDefault()
    if (isVirtualAnchorClicked.value && !isMoved.value) {
      // 如果是虚拟点且未移动，则插入新点
      const virtualAnchor = virtualAnchors.value[index]
      points.value.splice(index + 1, 0, virtualAnchor) // 插入新点
      calculateVirtualAnchors() // 重新计算虚拟锚点
      isMoved.value = true // 标记为已移动
      draggingIndex.value = index + 1
    }
    if (draggingIndex.value !== null) {
      dragAnchor(event, draggingIndex.value)
    }
  }

  // 停止拖动
  const stopDrag = () => {
    draggingIndex.value = null
    window.removeEventListener('mousemove', onMouseMove)
    window.removeEventListener('mouseup', stopDrag)
    isVirtualAnchorClicked.value = false // 重置虚拟锚点点击标志
    isMoved.value = false // 重置移动标志
  }
  window.addEventListener('mousemove', onMouseMove)
  window.addEventListener('mouseup', stopDrag)
}

// 删除点
const deletePoint = (index) => {
  if (points.value.length > 2) {
    points.value.splice(index, 1)
    calculateVirtualAnchors()
    updateSvgDimensions() // 删除点后更新宽高和viewBox
  } else {
    console.warn('Cannot delete point: polyline must have at least 2 points.')
  }
}

// 鼠标移入时计算锚点
const handleMouseMove = (e) => {
  e.preventDefault()
  if (showAnchors.value) {
    calculateVirtualAnchors()
  }
}
</script>

<template>
  <svg
    class="free-polyline"
    :width="svgWidth"
    :height="svgHeight"
    :viewBox="viewBox"
    @mousemove="handleMouseMove"
    @mouseenter="showAnchors = true"
    @mouseleave="showAnchors = false">
    <!-- 绘制折线 -->
    <polyline :points="pointsString" fill="none" stroke="black" stroke-width="2" vector-effect="non-scaling-stroke" />
    <!-- 绘制端点锚点 -->
    <circle
      v-for="(point, index) in points"
      v-show="showAnchors"
      :key="'point-' + index"
      :cx="point.x"
      :cy="point.y"
      r="5"
      stroke="blue"
      stroke-width="2"
      fill="white"
      @mousedown="startDrag(index, $event)"
      @dblclick="deletePoint(index)" />
    <!-- 绘制虚拟锚点 -->
    <circle
      v-for="(anchor, index) in virtualAnchors"
      v-show="showAnchors"
      :key="'virtual-anchor-' + index"
      :cx="anchor.x"
      :cy="anchor.y"
      r="5"
      stroke="rgba(255, 0, 0, 0.5)"
      stroke-width="2"
      fill="transparent"
      @mousedown="startDrag(index, $event, true)" />
  </svg>
</template>

<style lang="scss" scoped>
.free-polyline {
  overflow: visible;
}
</style>
