<template>
  <div class="chart-container">
    <v-chart class="chart" :option="option" :autoresize="true" />
    <!-- <div class="chart-toolbar">
      <el-space>
        <el-button type="primary">切换当日数据</el-button>
        <el-button type="primary">切换小时数据</el-button>
        <el-button type="primary">切换分钟数据</el-button>
      </el-space>
    </div> -->
  </div>
</template>

<script setup>
import { BarChart, LineChart, PieChart, ScatterChart } from 'echarts/charts'
import {
  DataZoomComponent,
  GridComponent,
  LegendComponent,
  TitleComponent,
  ToolboxComponent,
  TooltipComponent
} from 'echarts/components'
import { use } from 'echarts/core'
import { SVGRenderer } from 'echarts/renderers'
import VChart from 'vue-echarts'

use([
  BarChart,
  DataZoomComponent,
  GridComponent,
  LegendComponent,
  LineChart,
  PieChart,
  ScatterChart,
  SVGRenderer,
  TitleComponent,
  ToolboxComponent,
  TooltipComponent
])

// provide(THEME_KEY, 'dark')

defineProps({
  option: {
    type: Object,
    required: true
  },
  bindData: {
    type: String,
    default: ''
  },
  pastTime: {
    type: Number,
    default: 1
  },
  pastTimeType: {
    type: Number,
    default: 2
  },
  customIntervalTime: {
    type: Boolean,
    default: false
  },
  interval: {
    type: Number,
    default: 1
  },
  intervalUnit: {
    type: Number,
    default: 1
  }
})
</script>

<style lang="scss" scoped>
.chart-container {
  display: flex;
  flex-direction: column;

  .chart {
    flex: 1;
  }

  .chart-toolbar {
    display: flex;
    justify-content: center;
    padding: 10px;
  }
}
</style>
