const modules = import.meta.glob('./components/*.vue')
const components = ref({})

Object.entries(modules).forEach(([path, asyncCom]) => {
  const name = path.replace(/\.\/components\/(.*)\.vue/, '$1')
  components.value[name] = markRaw(defineAsyncComponent(asyncCom))
})

const graphicGroups = []
export const baseGraphicGroup = {
  title: '基础图形',
  name: 'base',
  graphics: [
    {
      type: 'polyline',
      text: '直线',
      component: 'SvgLine',
      icon: 'liner',
      width: 300,
      height: 20,
      skewable: false,
      border: false,
      resizeList: ['left', 'right'],
      props: {
        stroke: 'rgba(0,0,0,1)',
        strokeWidth: 1,
        strokeDasharray: 'none',
        strokeDashoffset: 0
      }
    },
    {
      type: 'rect',
      text: '矩形',
      component: 'SvgRect',
      icon: 'oui-stop',
      props: {
        width: 100,
        height: 100,
        stroke: '#000',
        strokeWidth: 1,
        strokeDasharray: 'none',
        strokeDashoffset: 0
      }
    },
    {
      type: 'ellipse',
      text: '圆形',
      component: 'SvgEllipse',
      width: 100,
      height: 100,
      icon: 'circle',
      props: {
        fill: '#69f',
        strokeWidth: 1,
        strokeDasharray: 'none',
        strokeDashoffset: 0
      }
    },
    {
      type: 'triangle',
      text: '三角形',
      component: 'SvgTriangle',
      width: 100,
      height: 100,
      icon: 'triangle',
      props: {
        fill: '#6f9',
        strokeWidth: 1,
        strokeDasharray: 'none',
        strokeDashoffset: 0
      }
    },
    {
      type: 'trapezium',
      text: '梯形',
      component: 'SvgTrapezium',
      width: 100,
      height: 100,
      icon: 'trapezium',
      props: {
        fill: '#f96',
        strokeWidth: 1,
        strokeDasharray: 'none',
        strokeDashoffset: 0
      }
    },
    {
      type: 'polygon',
      text: '多边形',
      component: 'SvgPolygon',
      width: 100,
      height: 100,
      icon: 'polygon',
      equalProportion: true,
      props: {
        sides: 5,
        initialAngle: -180,
        fill: '#f69',
        strokeWidth: 1,
        strokeDasharray: 'none',
        strokeDashoffset: 0
      }
    }
  ]
}

export const extendComponentGroup = {
  title: '状态图形',
  name: 'extend',
  graphics: [
    {
      type: 'conveyor',
      text: '传输带',
      component: 'SvgConveyor',
      width: 300,
      height: 60,
      minHeight: 40,
      minWidth: 120,
      icon: 'conveyor',
      resizeList: ['left', 'right']
    }
  ]
}

export const chartComponentGroup = {
  title: '图表组件',
  name: 'eChart',
  graphics: [
    {
      type: 'e-chart',
      text: '折线图',
      component: 'EChart',
      width: 600,
      height: 400,
      icon: 'chart-line',
      props: {
        option: {
          title: { text: '折线图', left: 'center' },
          toolbox: {
            feature: {
              magicType: { show: true, type: ['bar'] },
              restore: { show: true }
            }
          },
          dataZoom: [
            {
              type: 'slider', // 内置型数据区域缩放组件
              show: true,
              xAxisIndex: 0,
              start: 0,
              end: 100
            }
          ],
          xAxis: {
            data: ['00:00', '00:10', '00:20', '00:30', '00:40', '00:50', '01:00']
          },
          yAxis: {},
          series: [
            {
              data: [10, 22, 28, 43, 49, 67, 34],
              type: 'line'
            },
            {
              data: [5, 4, 3, 5, 10, 6, 2],
              type: 'line'
            }
          ]
        },
        pastTime: 1,
        pastTimeType: 3,
        interval: 10,
        intervalUnit: 2
      }
    },
    {
      type: 'e-chart',
      text: '柱形图',
      component: 'EChart',
      width: 600,
      height: 400,
      icon: 'chart-bar',
      props: {
        option: {
          title: { text: '柱形图', left: 'center' },
          toolbox: {
            feature: {
              magicType: { show: true, type: ['line'] },
              restore: { show: true }
            }
          },
          dataZoom: [
            {
              type: 'slider', // 内置型数据区域缩放组件
              show: true,
              xAxisIndex: 0,
              start: 0,
              end: 100
            }
          ],
          xAxis: {
            data: ['00:00', '00:10', '00:20', '00:30', '00:40', '00:50', '01:00']
          },
          yAxis: {},
          series: [
            {
              type: 'bar',
              data: [23, 24, 18, 25, 27, 28, 25]
            }
          ]
        },
        pastTime: 1,
        pastTimeType: 3,
        interval: 10,
        intervalUnit: 2
      }
    },
    {
      type: 'e-chart',
      text: '散点图',
      component: 'EChart',
      width: 600,
      height: 400,
      icon: 'chart-scatter',
      props: {
        option: {
          title: { text: '散点图', left: 'center' },
          dataZoom: [
            {
              type: 'slider', // 内置型数据区域缩放组件
              show: true,
              xAxisIndex: 0,
              start: 0,
              end: 100
            }
          ],
          xAxis: {
            data: ['00:00', '00:10', '00:20', '00:30', '00:40', '00:50', '01:00']
          },
          yAxis: {},
          series: [
            {
              type: 'scatter',
              data: [220, 182, 191, 234, 290, 330, 310]
            }
          ]
        },
        pastTime: 1,
        pastTimeType: 3,
        interval: 10,
        intervalUnit: 2
      }
    }
  ]
}

export const interactComponentGroup = {
  title: '交互组件',
  name: 'customize',
  graphics: [
    {
      type: 'el-button',
      text: '按钮',
      component: 'ElButton',
      width: 100,
      height: 32,
      icon: 'btn',
      rotatable: false
    },
    {
      type: 'text-box',
      text: '文本',
      component: 'div',
      width: 120,
      height: 30,
      icon: 'text'
    }
  ]
}

function initialGraphicData(graphics) {
  return graphics.map((graphic) => {
    if (!graphic.width && graphic.props?.width) {
      graphic.width = graphic.props.width
    }
    if (!graphic.height && graphic.props?.height) {
      graphic.height = graphic.props.height
    }
    graphic.isSvg = isSvg(graphic)
    return graphic
  })
}

function isSvg(graphic) {
  return graphic.component.includes('Svg')
}

graphicGroups.push(Object.assign({}, baseGraphicGroup, { graphics: initialGraphicData(baseGraphicGroup.graphics) }))
graphicGroups.push(Object.assign({}, extendComponentGroup))
graphicGroups.push(Object.assign({}, chartComponentGroup))
graphicGroups.push(Object.assign({}, interactComponentGroup))

export { components, graphicGroups }
