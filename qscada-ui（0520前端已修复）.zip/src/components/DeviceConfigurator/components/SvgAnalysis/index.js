export { default } from './SvgAnalysis.vue'
