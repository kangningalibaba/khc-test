<script setup>
const { name } = defineProps({
  name: {
    type: String,
    required: true
  },
  props: {
    type: Object,
    default: () => ({})
  }
})
const symbolId = computed(() => `#icon-${name}`)
</script>

<template>
  <svg class="svg-analysis" aria-hidden="true">
    <use :xlink:href="symbolId" v-bind="props" />
  </svg>
</template>

<style lang="scss" scoped>
.svg-analysis {
  width: 1em;
  height: 1em;
  vertical-align: -0.15em;
  fill: currentColor;
  overflow: hidden;
}
</style>
