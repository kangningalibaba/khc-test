export { default } from './GridArea.vue'
