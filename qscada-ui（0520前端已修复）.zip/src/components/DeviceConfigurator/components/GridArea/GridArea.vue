<script setup>
import { useDark } from '@vueuse/core'
import MColor from 'color'
const isDark = useDark()
const { grid, gridCount, borderColor } = defineProps({
  grid: {
    // 小网格的大小
    type: Number,
    default: 10
  },
  gridCount: {
    // 小网格的数量，默认为5个
    type: Number,
    default: 5
  },
  showGrid: {
    // 是否显示大网格
    type: Boolean,
    default: true
  },
  showSmallGrid: {
    // 是否显示小网格
    type: Boolean,
    default: true
  },
  borderColor: {
    type: String
  }
})

// 计算大网格的大小
const bigGrid = computed(() => grid * gridCount)

// 处理网站皮肤，可忽略
const color = computed(() => {
  if (borderColor) {
    return {
      bigGrid: borderColor,
      smallGrid: MColor(borderColor).fade(0.5).rgb().string()
    }
  }
  const colors = [
    ['#e4e7ed', '#ebeef5'],
    ['#414243', '#363637']
  ]
  const [bigGrid, smallGrid] = colors[isDark.value ? 1 : 0]
  return { bigGrid, smallGrid }
})

const gridAreaStyle = computed(() => ({ '--border-color': color.value.bigGrid }))
</script>

<template>
  <svg class="grid-area" :style="gridAreaStyle" width="100%" height="100%" xmlns="http://www.w3.org/2000/svg">
    <defs>
      <pattern v-if="showSmallGrid" id="smallGrid" :width="grid" :height="grid" patternUnits="userSpaceOnUse">
        <path :d="`M ${grid} 0 L 0 0 0 ${grid}`" fill="none" :stroke="color.smallGrid" stroke-width="0.5" />
      </pattern>
      <pattern id="grid" :width="bigGrid" :height="bigGrid" patternUnits="userSpaceOnUse">
        <rect v-if="showSmallGrid" :width="bigGrid" :height="bigGrid" fill="url(#smallGrid)" />
        <path :d="`M ${bigGrid} 0 L 0 0 0 ${bigGrid}`" fill="none" :stroke="color.bigGrid" stroke-width="1" />
      </pattern>
    </defs>
    <rect v-if="showGrid" width="100%" height="100%" fill="url(#grid)" />
  </svg>
</template>
