<script setup>
import { Delete, Upload } from '@element-plus/icons-vue'
import color from 'color'
import { computed, onBeforeMount, ref } from 'vue'
import ColorPicker from './ColorPicker.vue'

const uploadInputRef = useTemplateRef('uploadInputRef')

const { modelValue } = defineProps({
  modelValue: {
    type: Object,
    default: () => ({
      backgroundColor: 'rgba(0, 0, 0, 0)',
      backgroundImage: '',
      backgroundSize: 'cover',
      backgroundRepeat: 'no-repeat'
    })
  }
})
const emit = defineEmits(['update:modelValue'])
const defaultValueMap = {
  startColor: 'rgba(255, 255, 255, 1)',
  endColor: 'rgba(255, 255, 255, 1)',
  gradientRotate: 90
}

const typeList = [
  { label: '纯色背景', value: 1 },
  { label: '渐变背景', value: 2 },
  { label: '背景图片', value: 3 } // 启用背景图片选项
]
const type = ref(typeList[0].value)

const gradientTypeList = [
  { label: '线性渐变', value: 'linear' },
  { label: '径向渐变', value: 'radial' }
]
const gradientType = ref(gradientTypeList[0].value)
const backgroundColor = computed({
  get: () => modelValue.backgroundColor,
  set: (val) => {
    emit('update:modelValue', { ...modelValue, backgroundColor: val })
  }
})
const backgroundImage = computed({
  get: () => {
    if (modelValue.backgroundImage?.includes('url')) {
      return modelValue.backgroundImage.replace('url(', '').replace(')', '').replace(/"/g, '')
    } else {
      return ''
    }
  },
  set: (val) => {
    if (val) {
      emit('update:modelValue', { ...modelValue, backgroundImage: `url(${val})` })
    } else {
      emit('update:modelValue', { backgroundColor: modelValue.backgroundColor })
    }
  }
})
const backgroundSize = computed({
  get: () => modelValue.backgroundSize ?? 'cover',
  set: (val) => {
    emit('update:modelValue', { ...modelValue, backgroundSize: val })
  }
})
const backgroundRepeat = computed({
  get: () => modelValue.backgroundRepeat ?? 'no-repeat',
  set: (val) => {
    emit('update:modelValue', { ...modelValue, backgroundRepeat: val })
  }
})
const backgroundPositionX = computed({
  get: () => modelValue.backgroundPositionX ?? 'center',
  set: (val) => {
    emit('update:modelValue', { ...modelValue, backgroundPositionX: val })
  }
})
const backgroundPositionY = computed({
  get: () => modelValue.backgroundPositionY ?? 'center',
  set: (val) => {
    emit('update:modelValue', { ...modelValue, backgroundPositionY: val })
  }
})
const startColor = computed({
  get: () => getGradientValue('startColor'),
  set: (val) => {
    handleGradientColorChange(gradientRotate.value, val, endColor.value)
  }
})
const endColor = computed({
  get: () => getGradientValue('endColor'),
  set: (val) => {
    handleGradientColorChange(gradientRotate.value, startColor.value, val)
  }
})
const gradientRotate = computed({
  get: () => getGradientValue('gradientRotate'),
  set: (val) => {
    handleGradientColorChange(val, startColor.value, endColor.value)
  }
})

function handleTypeChange() {
  if (type.value === 1) {
    emit('update:modelValue', { backgroundColor: modelValue.backgroundColor })
  } else if (type.value === 2) {
    handleGradientColorChange(gradientRotate.value, startColor.value, endColor.value)
  } else if (type.value === 3) {
    emit('update:modelValue', {
      backgroundColor: modelValue.backgroundColor,
      backgroundSize: 'cover',
      backgroundRepeat: 'no-repeat'
    })
  }
}

function handleGradientColorChange(rotate, startColor, endColor) {
  let val = `linear-gradient(${rotate}deg, ${startColor}, ${endColor})`
  if (gradientType.value === 'radial') {
    val = `radial-gradient(${startColor}, ${endColor})`
  }
  emit('update:modelValue', { backgroundColor: startColor, backgroundImage: val })
}

function getGradientValue(type) {
  const gradientString = modelValue.backgroundImage ?? defaultValueMap['startColor']

  // 判断是否是渐变
  const isGradient = gradientString.includes('gradient')
  if (!isGradient) {
    // 不是渐变
    return type === 'startColor' ? color(modelValue.backgroundColor).rgb().string() : defaultValueMap[type]
  }

  let gradientRegex = /gradient\((\d+deg),\s*(rgba?\([^)]+\)),\s*(rgba?\([^)]+\))\)/
  const isRadial = gradientString.includes('radial')
  if (isRadial) {
    gradientRegex = /(gradient)\(.*(rgba?\([^)]+\)),\s*(rgba?\([^)]+\))\)/
  }

  const match = gradientString.match(gradientRegex)
  const defaultValue = defaultValueMap[type]
  if (!match) {
    return defaultValue
  }
  if (type === 'startColor') {
    return match[2] || defaultValue
  } else if (type === 'endColor') {
    return match[3] || defaultValue
  } else if (type === 'gradientRotate') {
    return parseInt(match[1]) || defaultValue
  }

  return defaultValue
}

function handleImageUpload(event) {
  const file = event.target.files[0]
  if (file) {
    const reader = new FileReader()
    reader.onload = (e) => {
      backgroundImage.value = e.target.result // 将图片转换为Base64并存储
    }
    reader.readAsDataURL(file)
  }
}

function uploadBackgroundImage() {
  uploadInputRef.value.click()
}

function clearBackgroundImage() {
  backgroundImage.value = ''
}

onBeforeMount(() => {
  if (modelValue.backgroundImage) {
    if (modelValue.backgroundImage.includes('url')) {
      type.value = 3
    } else {
      type.value = 2
    }
  } else {
    type.value = 1
  }
})
</script>

<template>
  <el-row :gutter="10">
    <el-col :span="12">
      <el-select v-model="type">
        <el-option v-for="item in typeList" :key="item.value" v-bind="item" @change="handleTypeChange" />
      </el-select>
    </el-col>
    <el-col :span="12">
      <ColorPicker v-if="type === 1" v-model="backgroundColor" color-format="rgb" />
      <el-select
        v-else-if="type === 2"
        v-model="gradientType"
        @change="handleGradientColorChange(gradientRotate, startColor, endColor)">
        <el-option v-for="item in gradientTypeList" :key="item.value" v-bind="item" />
      </el-select>
      <template v-else-if="type === 3">
        <input ref="uploadInputRef" class="upload-input" type="file" accept="image/*" @change="handleImageUpload" />
        <el-button-group>
          <el-button type="primary" :icon="Upload" @click="uploadBackgroundImage" />
          <el-button type="primary" :icon="Delete" @click="clearBackgroundImage" />
        </el-button-group>
      </template>
    </el-col>
  </el-row>
  <template v-if="type === 3 && backgroundImage">
    <el-row :gutter="10">
      <el-col :span="12"> 缩放方式: </el-col>
      <el-col :span="12">
        <el-select v-model="backgroundSize">
          <el-option label="自动 (auto)" value="auto" />
          <el-option label="覆盖 (cover)" value="cover" />
          <el-option label="适应 (contain)" value="contain" />
        </el-select>
      </el-col>
    </el-row>
    <el-row :gutter="10">
      <el-col :span="12"> 背景位置X: </el-col>
      <el-col :span="12">
        <el-select v-model="backgroundPositionX">
          <el-option label="左对齐 (left)" value="left" />
          <el-option label="居中对齐 (center)" value="center" />
          <el-option label="右对齐 (right)" value="right" />
        </el-select>
      </el-col>
    </el-row>
    <el-row :gutter="10">
      <el-col :span="12"> 背景位置Y: </el-col>
      <el-col :span="12">
        <el-select v-model="backgroundPositionY">
          <el-option label="上对齐 (top)" value="top" />
          <el-option label="居中对齐 (center)" value="center" />
          <el-option label="下对齐 (bottom)" value="bottom" />
        </el-select>
      </el-col>
    </el-row>
    <el-row :gutter="10">
      <el-col :span="12"> 平铺方式: </el-col>
      <el-col :span="12">
        <el-select v-model="backgroundRepeat">
          <el-option label="不平铺 (no-repeat)" value="no-repeat" />
          <el-option label="水平平铺 (repeat-x)" value="repeat-x" />
          <el-option label="垂直平铺 (repeat-y)" value="repeat-y" />
          <el-option label="平铺 (repeat)" value="repeat" />
        </el-select>
      </el-col>
    </el-row>
    <!-- <el-row :gutter="10" v-if="backgroundImage">
      <el-col :span="24">
        <div class="image-preview">
          <img :src="backgroundImage" alt="背景预览" />
        </div>
      </el-col>
    </el-row> -->
  </template>
  <template v-if="type === 2">
    <el-row :gutter="10">
      <el-col :span="12"> 起点颜色: </el-col>
      <el-col :span="12"><ColorPicker v-model="startColor" /></el-col>
    </el-row>
    <el-row :gutter="10">
      <el-col :span="12"> 终点颜色: </el-col>
      <el-col :span="12"><ColorPicker v-model="endColor" /></el-col>
    </el-row>
    <el-row :gutter="10" v-if="gradientType === 'linear'">
      <el-col :span="12"> 渐变角度: </el-col>
      <el-col :span="12"><el-slider size="small" v-model="gradientRotate" :max="360" /></el-col>
    </el-row>
  </template>
</template>

<style lang="scss" scoped>
.el-row {
  margin-bottom: 10px;
}

.upload-input {
  display: none; // 隐藏默认文件输入框
}

.image-preview {
  max-width: 100%;
  max-height: 150px;
  overflow: hidden;
  display: flex;
  justify-content: center;
  align-items: center;

  img {
    max-width: 100%;
    max-height: 100%;
    object-fit: cover;
  }
}
</style>
