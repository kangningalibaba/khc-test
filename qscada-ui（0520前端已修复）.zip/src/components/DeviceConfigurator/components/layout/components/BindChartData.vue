<script setup>
import VariableSelection from '@/components/VariableSelection'
import { useCommandDialog } from '@/hooks'
import { useDeviceConfiguratorStore } from '@/store/modules/deviceConfigurator'
import dayjs from 'dayjs'
import quarterOfYear from 'dayjs/plugin/quarterOfYear'

dayjs.extend(quarterOfYear)

const store = useDeviceConfiguratorStore()
const variableSelection = useCommandDialog(VariableSelection)

const TimeUnitEnum = {
  SECOND: 1,
  MINUTE: 2,
  HOUR: 3,
  DAY: 4,
  MONTH: 5,
  QUARTER: 6,
  YEAR: 7
}

function setYearInterval(count) {
  const now = dayjs()
  const data = []
  store.current.props.interval = 1
  if (count > 1) {
    const year = now.year()
    for (let i = count; i > 0; i--) {
      data.push(`${year - i + 1} 年`)
    }
    store.current.props.option.xAxis.data = data
    store.current.props.intervalUnit = TimeUnitEnum.YEAR
  } else {
    store.current.props.option.xAxis.data = [
      '一月份',
      '二月份',
      '三月份',
      '四月份',
      '五月份',
      '六月份',
      '七月份',
      '八月份',
      '九月份',
      '十月份',
      '十一月份',
      '十二月份'
    ]
    store.current.props.intervalUnit = TimeUnitEnum.MONTH
  }
}

function setQuarterInterval(count) {
  const now = dayjs()
  const data = [] // 季度
  store.current.props.interval = 1
  if (count > 1) {
    for (let i = count; i > 0; i--) {
      data.push(`${now.year() - i + 1} 年`)
    }
    store.current.props.option.xAxis.data = data
    store.current.props.intervalUnit = TimeUnitEnum.QUARTER
  } else {
    for (let i = 0; i < 3; i++) {
      data.push(now.startOf('quarter').add(i, 'month').format('YYYY年MM月'))
    }
    store.current.props.option.xAxis.data = data
    store.current.props.intervalUnit = TimeUnitEnum.MONTH
  }
}

function setMonthInterval(count) {
  const now = dayjs()
  const data = []
  store.current.props.interval = 1
  if (count > 1) {
    const month = now.month() + 1
    for (let i = count; i > 0; i--) {
      data.push(`${month - i + 1} 月`)
    }
    store.current.props.option.xAxis.data = data
    store.current.props.intervalUnit = TimeUnitEnum.MONTH
  } else {
    const daysInMonth = now.startOf('month').daysInMonth()
    for (let i = 0; i < daysInMonth; i++) {
      data.push(now.startOf('month').add(i, 'day').format('YYYY/MM/DD'))
    }
    store.current.props.option.xAxis.data = data
    store.current.props.intervalUnit = TimeUnitEnum.DAY
  }
}

function setDayInterval(count) {
  const now = dayjs()
  const data = []
  store.current.props.interval = 1
  if (count > 1) {
    for (let i = count; i > 0; i--) {
      data.push(`${now.subtract(i, 'day').format('YYYY/MM/DD')}`)
    }
    store.current.props.option.xAxis.data = data
    store.current.props.intervalUnit = TimeUnitEnum.DAY
  } else {
    for (let i = 0; i < 24; i++) {
      data.push(`${now.startOf('day').add(i, 'hour').format('HH:mm')}`)
    }
    store.current.props.option.xAxis.data = data
    store.current.props.intervalUnit = TimeUnitEnum.HOUR
  }
}

function setHourInterval(count) {
  const now = dayjs()
  const data = []
  store.current.props.interval = 1
  if (count > 1) {
    for (let i = count; i > 0; i--) {
      data.push(`${now.subtract(i, 'hour').format('HH:mm')}`)
    }
    store.current.props.option.xAxis.data = data
    store.current.props.intervalUnit = TimeUnitEnum.HOUR
  } else {
    for (let i = 0; i < 6; i++) {
      data.push(
        `${now
          .startOf('hour')
          .add(i * 10, 'minute')
          .format('HH:mm')}`
      )
    }
    store.current.props.option.xAxis.data = data
    store.current.props.interval = 10
    store.current.props.intervalUnit = TimeUnitEnum.MINUTE
  }
}

function setMinuteInterval(count) {
  const now = dayjs()
  const data = []
  store.current.props.interval = 1
  if (count > 1) {
    for (let i = count; i > 0; i--) {
      data.push(`${now.subtract(i, 'minute').format('HH:mm')}`)
    }
    store.current.props.option.xAxis.data = data
    store.current.props.intervalUnit = TimeUnitEnum.MINUTE
  } else {
    for (let i = 0; i < 6; i++) {
      data.push(
        `${now
          .startOf('minute')
          .add(i * 10, 'second')
          .format('HH:mm:ss')}`
      )
    }
    store.current.props.option.xAxis.data = data
    store.current.props.interval = 10
    store.current.props.intervalUnit = TimeUnitEnum.SECOND
  }
}

function setSecondInterval(count) {
  const now = dayjs()
  const data = []
  store.current.props.interval = 1
  for (let i = count; i > 0; i--) {
    data.push(`${now.subtract(i, 'second').format('HH:mm:ss')}`)
  }
  store.current.props.option.xAxis.data = data
  store.current.props.intervalUnit = TimeUnitEnum.SECOND
}

function handlePastTimeChange() {
  const count = store.current.props.pastTime ?? 1
  const unit = store.current.props.pastTimeType ?? TimeUnitEnum.HOUR
  if (unit === TimeUnitEnum.YEAR) {
    setYearInterval(count)
  } else if (unit === TimeUnitEnum.QUARTER) {
    setQuarterInterval(count)
  } else if (unit === TimeUnitEnum.MONTH) {
    setMonthInterval(count)
  } else if (unit === TimeUnitEnum.DAY) {
    setDayInterval(count)
  } else if (unit === TimeUnitEnum.HOUR) {
    setHourInterval(count)
  } else if (unit === TimeUnitEnum.MINUTE) {
    setMinuteInterval(count)
  } else {
    setSecondInterval(count)
  }
}

function handleBindDataChange() {
  const bindData = store.current.props.bindData.split(',')
  const chartType = store.current.icon.split('-')[1]
  const data = []
  for (let i = 0; i < bindData.length; i++) {
    data.push({
      data: [],
      type: chartType,
      name: bindData[i]
    })
  }
  store.current.props.option.legend = { data: bindData, left: 'left' }
  store.current.props.option.series = data
}
</script>

<template>
  <div class="bind-chart">
    <el-row :gutter="10">
      <el-col :span="10">图表名称：</el-col>
      <el-col :span="14">
        <el-input v-model="store.current.props.option.title.text" placeholder="请输入图表名称" />
      </el-col>
    </el-row>
    <el-row :gutter="10">
      <el-col :span="10">变量绑定：</el-col>
      <el-col :span="14">
        <el-input
          type="textarea"
          v-model="store.current.props.bindData"
          placeholder="请输入变量名称，多个变量用英文逗号隔开"
          :rows="4"
          @change="handleBindDataChange" />
        <el-button
          type="primary"
          icon="CollectionTag"
          @click="variableSelection({ visible: true })"
          :style="{ width: '100%', marginTop: '10px' }"
          >变量选择</el-button
        ></el-col
      >
    </el-row>
    <el-row :gutter="10">
      <el-col :span="10">时间周期：</el-col>
      <el-col :span="7">
        <el-input-number
          :min="1"
          v-model="store.current.props.pastTime"
          placeholder="周期"
          controls-position="right"
          :style="{ width: '100%' }"
          @change="handlePastTimeChange">
        </el-input-number>
      </el-col>
      <el-col :span="7">
        <el-select
          v-model="store.current.props.pastTimeType"
          placeholder="单位"
          :style="{ width: '100%' }"
          @change="handlePastTimeChange">
          <!-- <el-option label="秒" :value="1"></el-option> -->
          <el-option label="分" :value="2"></el-option>
          <el-option label="时" :value="3"></el-option>
          <el-option label="日" :value="4"></el-option>
          <el-option label="月" :value="5"></el-option>
          <el-option label="季" :value="6"></el-option>
          <el-option label="年" :value="7"></el-option>
        </el-select>
      </el-col>
    </el-row>
    <!-- <el-row :gutter="10">
      <el-col :span="10">时间间隔：</el-col>
      <el-col :span="14">
        <el-switch v-model="store.current.props.customIntervalTime" active-text="自定义" inactive-text="自动" />
      </el-col>
    </el-row> -->
    <el-row v-if="store.current.props.customIntervalTime" :gutter="10">
      <el-col :span="10">间隔时长：</el-col>
      <el-col :span="7">
        <el-input-number
          :min="1"
          v-model="store.current.props.interval"
          placeholder="时长"
          :style="{ width: '100%' }"
          controls-position="right">
        </el-input-number>
      </el-col>
      <el-col :span="7">
        <el-select v-model="store.current.props.intervalUnit" placeholder="单位" :style="{ width: '100%' }">
          <el-option label="秒" :value="1"></el-option>
          <el-option label="分" :value="2"></el-option>
          <el-option label="时" :value="3"></el-option>
          <el-option label="日" :value="4"></el-option>
          <el-option label="月" :value="5"></el-option>
          <el-option label="季" :value="6"></el-option>
          <el-option label="年" :value="7"></el-option>
        </el-select>
      </el-col>
    </el-row>
  </div>
</template>

<style lang="scss" scoped>
.el-row {
  margin-bottom: 10px;
}
</style>
