<script setup>
import VariableSelection from '@/components/VariableSelection'
import { useCommandDialog } from '@/hooks'
import { useDeviceConfiguratorStore } from '@/store/modules/deviceConfigurator'
import { CollectionTag, Delete, Minus, Plus } from '@element-plus/icons-vue'
const store = useDeviceConfiguratorStore()
const conditionalStyles = computed({
  get: () => store.current.conditionalStyles ?? [],
  set: (value) => {
    store.current.conditionalStyles = value
  }
})
const activeConditional = ref(null)
const variableSelection = useCommandDialog(VariableSelection)
function addConditionalStyle() {
  const newConditionalStyle = {
    expression: '',
    props: [{ propName: '', propValue: '' }]
  }
  if (conditionalStyles.value.length === 0) {
    conditionalStyles.value = ref([])
  }
  conditionalStyles.value.push({ ...newConditionalStyle })
  activeConditional.value = conditionalStyles.value.length - 1
}

function removeConditionalStyle(event, index) {
  event.preventDefault()
  conditionalStyles.value.splice(index, 1)
  if (activeConditional.value === index) {
    activeConditional.value = null
  }
}

function addProp() {
  if (activeConditional.value !== null) {
    conditionalStyles.value[activeConditional.value].props.push({
      propName: '',
      propValue: ''
    })
  }
}

function removeProp(index) {
  if (activeConditional.value !== null) {
    conditionalStyles.value[activeConditional.value].props.splice(index, 1)
  }
}
</script>

<template>
  <el-form label-width="64px">
    <el-collapse v-if="conditionalStyles.length > 0" v-model="activeConditional" accordion>
      <el-collapse-item v-for="(conditionalStyle, index) in conditionalStyles" :key="index" :name="index">
        <template #title>
          <el-space>
            <el-text>条件{{ index + 1 }}</el-text>
            <el-icon @click="removeConditionalStyle($event, index)"><Delete /></el-icon>
          </el-space>
        </template>
        <el-form-item label="表达式">
          <el-input v-model="conditionalStyle.expression" placeholder="请输入条件的表达式">
            <template #append>
              <el-button :icon="CollectionTag" @click="variableSelection({ visible: true })" />
            </template>
          </el-input>
        </el-form-item>
        <template v-for="(prop, i) in conditionalStyle.props" :key="i">
          <el-form-item label="属性名">
            <el-col :span="10">
              <el-select
                v-model="prop.propName"
                placeholder="请选择"
                :style="{ width: '100%' }"
                @change="prop.propValue = ''">
                <el-option label="填充色" :value="store.current.isSvg ? 'fill' : 'backgroundColor'"></el-option>
                <el-option label="边框色" :value="store.current.isSvg ? 'stroke' : 'borderColor'"></el-option>
                <el-option label="文本色" value="color"></el-option>
                <el-option label="状态" value="status"></el-option>
              </el-select>
            </el-col>
            <el-col :span="10">
              <el-select v-if="prop.propName === 'animation'" v-model="prop.propValue">
                <el-option label="闪烁" value="animate__flash"></el-option>
                <el-option label="抖动" value="animate__headShake"></el-option>
              </el-select>
              <el-input
                v-else-if="prop.propName === 'status'"
                v-model="prop.propValue"
                placeholder="输入状态值"></el-input>
              <el-color-picker v-else v-model="prop.propValue" :style="{ width: '100%' }" />
            </el-col>
            <el-col :span="4">
              <el-space size="small">
                <el-button :icon="Plus" link size="small" @click="addProp" />
                <el-button :icon="Minus" link size="small" @click="removeProp(i)" />
              </el-space>
            </el-col>
          </el-form-item>
        </template>
      </el-collapse-item>
    </el-collapse>
    <el-button type="primary" :style="{ width: '100%' }" @click="addConditionalStyle">添加</el-button>
  </el-form>
</template>
