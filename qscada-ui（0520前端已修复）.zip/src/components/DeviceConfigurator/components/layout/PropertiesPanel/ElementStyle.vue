<template>
  <el-form :model="store.current" label-width="80px" label-position="left" class="element-style">
    <template v-if="store.current.style">
      <template v-if="store.current.type !== 'polyline'">
        <div class="color-list">
          <div
            v-for="(style, index) in itemList"
            :key="index"
            class="color-item"
            :style="style"
            @click="handleColorClick(style)"></div>
        </div>

        <el-divider />
        <Background v-model="elementBg" />
        <el-divider />
      </template>

      <el-row :gutter="10">
        <el-col :span="10">透明度:</el-col>
        <el-col :span="14">
          <el-slider
            :modelValue="opacity"
            :step="0.01"
            :min="0"
            :max="1"
            size="small"
            @input="onChange('opacity', $event)" />
        </el-col>
      </el-row>

      <template v-if="!['image', 'polyline', 'e-chart'].includes(store.current.type)">
        <el-divider />
        <TextStyle />
      </template>

      <template v-if="store.current.type === 'e-chart'">
        <el-divider />
        <BindChartData />
      </template>

      <el-divider />
      <Border />

      <template v-if="store.current.type !== 'polyline'">
        <el-divider />
        <Shadow />
      </template>
    </template>
  </el-form>
</template>

<script setup>
import { useDeviceConfiguratorStore } from '@/store/modules/deviceConfigurator'
import { computed, ref } from 'vue'
import Background from '../components/Background.vue'
import BindChartData from '../components/BindChartData.vue'
import Border from '../components/Border.vue'
import Shadow from '../components/Shadow.vue'
import TextStyle from '../components/TextStyle.vue'

const store = useDeviceConfiguratorStore()
const itemList = ref([
  { backgroundColor: '#ff4500' },
  { backgroundColor: '#ff8c00' },
  { backgroundColor: '#ffd700' },
  { backgroundColor: '#90ee90' },
  { backgroundColor: '#00ced1' },
  { backgroundColor: '#1e90ff' },
  { backgroundColor: '#c71585' },
  { backgroundColor: 'rgba(255, 69, 0, 0.68)' }
])

const elementBg = computed({
  get: () => {
    const background = { backgroundColor: store.current.style.backgroundColor ?? 'rgba(0, 0, 0, 0)' }
    if (store.current.style.backgroundImage) {
      background.backgroundImage = store.current.style.backgroundImage
      if (!store.current.style.backgroundImage.includes('gradient')) {
        background.backgroundSize = store.current.style.backgroundSize ?? 'cover'
        background.backgroundRepeat = store.current.style.backgroundRepeat ?? 'no-repeat'
        background.backgroundPositionX = store.current.style.backgroundPositionX ?? 'center'
        background.backgroundPositionY = store.current.style.backgroundPositionY ?? 'center'
      }
    }
    return background
  },
  set: (background) => {
    store.current.style.backgroundColor = background.backgroundColor
    if (background.backgroundImage) {
      store.current.style.backgroundImage = background.backgroundImage
      if (!background.backgroundImage.includes('gradient')) {
        store.current.style.backgroundSize = background.backgroundSize ?? 'cover'
        store.current.style.backgroundRepeat = background.backgroundRepeat ?? 'no-repeat'
        store.current.style.backgroundPositionX = background.backgroundPositionX ?? 'center'
        store.current.style.backgroundPositionY = background.backgroundPositionY ?? 'center'
      }
    } else {
      delete store.current.style.backgroundImage
      delete store.current.style.backgroundSize
      delete store.current.style.backgroundRepeat
      delete store.current.style.backgroundPositionX
      delete store.current.style.backgroundPositionY
    }
  }
})
const opacity = computed({
  get: () => (Object.prototype.hasOwnProperty.call(store.current.style, 'opacity') ? store.current.style.opacity : 1),
  set: (val) => {
    store.current.style.opacity = val
  }
})

const handleColorClick = (style) => {
  if (!store.current.selected) return
  if (store.current.isSvg) {
    store.current.props.fill = style.backgroundColor
  } else {
    store.current.style = { ...store.current.style, ...style }
  }
}

function onChange(key, value) {
  store.current.style[key] = value
}
</script>

<style lang="scss" scoped>
.element-style {
  &:deep(.el-button-group) {
    display: inline-flex;
    width: 100%;
  }
}

.color-list {
  display: flex;
  flex-wrap: wrap;
  justify-content: space-around;
  .color-item {
    width: 22%;
    height: 28px;
    margin-top: 10px;
  }
}
.es-col {
  display: flex;
  align-items: center;
}
.text-btn {
  display: flex;
  justify-content: center;
  align-items: center;
  width: 50%;
  height: 100%;
  border-radius: 4px;
  cursor: pointer;
  &:hover {
    background-color: var(--el-fill-color-light);
  }
  :deep(.es-icon) {
    margin-right: 4px;
  }
}
</style>
