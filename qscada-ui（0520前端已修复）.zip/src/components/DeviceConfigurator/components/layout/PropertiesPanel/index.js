export { default } from './PropertiesPanel.vue'
