<script setup>
import { listScene } from '@/api/scada/scene'
import { useCommandDialog } from '@/hooks'
import { useDeviceConfiguratorStore } from '@/store/modules/deviceConfigurator'
import { Delete, Minus, Plus } from '@element-plus/icons-vue'
import { onBeforeMount, ref } from 'vue'
import CodeEditDialog from '../../CodeEditDialog'

const store = useDeviceConfiguratorStore()
const codeEdit = useCommandDialog(CodeEditDialog)
const events = computed({
  get: () => store.current.events || [],
  set: (value) => {
    store.current.events = value
  }
})
const activeEvent = ref(null)
const sceneList = ref([])
function addEvent() {
  const newEvent = {
    eventName: '',
    actions: [{ actionName: '', actionValue: '' }]
  }
  if (events.value.length === 0) {
    events.value = ref([])
  }
  events.value.push(newEvent)
  activeEvent.value = events.value.length - 1
}

function removeEvent(event, index) {
  event.preventDefault()
  events.value.splice(index, 1)
  if (activeEvent.value === index) {
    activeEvent.value = null
  }
}

function addAction() {
  if (activeEvent.value !== null) {
    events.value[activeEvent.value].actions.push({
      actionName: '',
      actionValue: ''
    })
  }
}

function removeAction(index) {
  if (activeEvent.value !== null) {
    events.value[activeEvent.value].actions.splice(index, 1)
  }
}

function getSceneList() {
  listScene({
    page: 1,
    limit: 1000
  }).then((res) => {
    if (res.code === 200) {
      sceneList.value = res.rows.map((item) => {
        return {
          label: item.name,
          value: item.id
        }
      })
      console.log(res.rows)
    }
  })
}

function handleCodeEdit(action) {
  codeEdit({
    code: action.actionValue,
    onDone: (val) => {
      action.actionValue = val
    }
  })
}

onBeforeMount(() => {
  getSceneList()
})
</script>
<template>
  <el-form>
    <el-collapse v-if="events.length > 0" v-model="activeEvent" accordion>
      <el-collapse-item v-for="(event, index) in events" :key="index" :name="index">
        <template #title>
          <el-space>
            <el-text>事件 {{ index + 1 }}</el-text>
            <el-icon @click="removeEvent($event, index)"><Delete /></el-icon>
          </el-space>
        </template>
        <el-form-item label="事件">
          <el-select v-model="event.eventName" placeholder="请选择触发的事件" :style="{ width: '100%' }">
            <el-option label="点击" value="click"></el-option>
            <el-option label="按下" value="mousedown"></el-option>
            <el-option label="松开" value="mouseup"></el-option>
            <!-- <el-option label="表达式触发" value="expression"></el-option> -->
          </el-select>
        </el-form-item>
        <!-- <el-form-item v-if="event.eventName === 'expression'" label="表达式">
          <el-input v-model="event.expression" placeholder="请输入事件的表达式" />
        </el-form-item> -->
        <template v-for="(action, i) in event.actions" :key="i">
          <el-divider v-if="i > 0" />
          <el-form-item label="行为">
            <el-col :span="18">
              <el-select v-model="action.actionName" placeholder="请选择触发的行为" :style="{ width: '100%' }">
                <el-option label="打开页面" value="open"></el-option>
                <el-option label="变量赋值" value="setValue"></el-option>
                <el-option label="执行代码" value="executeCode"></el-option>
              </el-select>
            </el-col>
            <el-col :span="6">
              <el-button :icon="Plus" link @click="addAction" />
              <el-button :icon="Minus" link @click="removeAction(i)" />
            </el-col>
          </el-form-item>
          <template v-if="action.actionName === 'open'">
            <el-form-item label="打开方式">
              <el-select v-model="action.openWith" placeholder="请选择打开方式" :style="{ width: '100%' }">
                <el-option label="新标签页" value="blank"></el-option>
                <el-option label="页面跳转" value="self"></el-option>
                <el-option label="弹出窗口" value="dialog"></el-option>
              </el-select>
            </el-form-item>
            <el-form-item label="打开页面">
              <!-- <el-input v-model="action.pageUrl" placeholder="请输入要打开的组态地址" /> -->
              <el-select v-model="action.sceneId" placeholder="请选择要打开的组态" :style="{ width: '100%' }">
                <el-option
                  v-for="item in sceneList"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value"></el-option>
              </el-select>
            </el-form-item>
          </template>
          <template v-if="action.actionName === 'setValue'">
            <el-form-item label="变量赋值">
              <el-input
                v-model="action.variables"
                type="textarea"
                placeholder="请输入变量及赋值，多个赋值请用','间隔。如：var1=1,var2=2" />
            </el-form-item>
          </template>
          <template v-if="action.actionName === 'executeCode'">
            <el-form-item label="代码">
              <el-button type="primary" icon="EditPen" @click="handleCodeEdit(action)" :style="{ width: '100%' }"
                >编辑代码</el-button
              >
            </el-form-item>
          </template>
        </template>
      </el-collapse-item>
    </el-collapse>
    <el-button type="primary" :style="{ width: '100%' }" @click="addEvent">添加</el-button>
  </el-form>
</template>
