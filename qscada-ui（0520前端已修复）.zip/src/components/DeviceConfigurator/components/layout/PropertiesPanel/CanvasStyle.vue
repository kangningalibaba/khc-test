<script setup>
import { useDeviceConfiguratorStore } from '@/store/modules/deviceConfigurator'
import { computed } from 'vue'
import Background from '../components/Background.vue'
import ColorPicker from '../components/ColorPicker.vue'
import InputNumber from '../components/InputNumber.vue'
const store = useDeviceConfiguratorStore()

const scaleRatio = computed({
  get: () => {
    const sRatio = store.data.container.scaleRatio || 1
    return Math.round(sRatio * 100)
  },
  set: (val) => {
    store.data.container.scaleRatio = val / 100
  }
})

const editorSize = computed({
  get: () => {
    const { width, height } = store.data.container.style
    return `${width} x ${height}`
  },
  set: (val) => {
    const [width, height] = val.split(' x ')
    store.data.container.style.width = +width
    store.data.container.style.height = +height
  }
})

const screenSize = [
  {
    label: 'PC',
    options: [
      { label: '1920 x 1200', value: '1920 x 1200' },
      { label: '1920 x 1080', value: '1920 x 1080' },
      { label: '1680 x 1050', value: '1680 x 1050' },
      { label: '1600 x 900', value: '1600 x 900' },
      { label: '1440 x 900', value: '1440 x 900' },
      { label: '1360 x 760', value: '1360 x 760' },
      { label: '1280 x 1024', value: '1280 x 1024' },
      { label: '1280 x 720', value: '1280 x 720' },
      { label: '1024 x 768', value: '1024 x 768' },
      { label: '800 x 600', value: '800 x 600' }
    ]
  },
  {
    label: 'Mobile Phone',
    options: [
      { label: '360 x 780', value: '360 x 780' },
      { label: 'iPhone 6/7/8', value: '375 x 667' },
      { label: 'iPhone 6/7/8 Plus', value: '414 x 736' },
      { label: 'iPhone X', value: '375 x 812' },
      { label: 'iPhone 11', value: '414 x 896' },
      { label: 'iPhone 12', value: '390 x 844' },
      { label: 'iPhone 14 Pro Max', value: '430 x 932' }
    ]
  }
]

const elementBg = computed({
  get: () => {
    const background = { backgroundColor: store.data.container.style.backgroundColor ?? 'rgba(0, 0, 0, 0)' }
    if (store.data.container.style.backgroundImage) {
      background.backgroundImage = store.data.container.style.backgroundImage
      if (!store.data.container.style.backgroundImage.includes('gradient')) {
        background.backgroundSize = store.data.container.style.backgroundSize ?? 'auto'
        background.backgroundRepeat = store.data.container.style.backgroundRepeat ?? 'no-repeat'
        background.backgroundPositionX = store.data.container.style.backgroundPositionX ?? 'center'
        background.backgroundPositionY = store.data.container.style.backgroundPositionY ?? 'center'
      }
    }
    return background
  },
  set: (background) => {
    store.data.container.style.backgroundColor = background.backgroundColor
    if (background.backgroundImage) {
      store.data.container.style.backgroundImage = background.backgroundImage
      if (!background.backgroundImage.includes('gradient')) {
        store.data.container.style.backgroundSize = background.backgroundSize ?? 'auto'
        store.data.container.style.backgroundRepeat = background.backgroundRepeat ?? 'no-repeat'
        store.data.container.style.backgroundPositionX = background.backgroundPositionX ?? 'center'
        store.data.container.style.backgroundPositionY = background.backgroundPositionY ?? 'center'
      }
    } else {
      delete store.data.container.style.backgroundImage
      delete store.data.container.style.backgroundSize
      delete store.data.container.style.backgroundRepeat
      delete store.data.container.style.backgroundPositionX
      delete store.data.container.style.backgroundPositionY
    }
  }
})
</script>

<template>
  <el-form :model="store.data.container" label-width="90px" label-position="left">
    <el-row :gutter="10">
      <el-col :span="10">画布尺寸:</el-col>
      <el-col :span="14">
        <el-select v-model="editorSize">
          <el-option-group v-for="group in screenSize" :key="group.label" :label="group.label">
            <el-option v-for="item in group.options" :key="item.value" :label="item.label" :value="item.value" />
          </el-option-group>
        </el-select>
      </el-col>
    </el-row>

    <el-row :gutter="10">
      <el-col :span="10">缩放比例:</el-col>
      <el-col :span="14">
        <el-input-number v-model="scaleRatio" controls-position="right" style="width: 100%" />
      </el-col>
    </el-row>

    <el-row :gutter="10">
      <el-col :span="10">画布宽度:</el-col>
      <el-col :span="14">
        <InputNumber v-model="store.data.container.style.width" />
      </el-col>
    </el-row>

    <el-row :gutter="10">
      <el-col :span="10">画布高度:</el-col>
      <el-col :span="14">
        <InputNumber v-model="store.data.container.style.height" />
      </el-col>
    </el-row>

    <el-divider />

    <Background v-model="elementBg" />
    <el-divider />

    <el-row :gutter="10">
      <el-col :span="10">画布网格:</el-col>
      <el-col :span="14">
        <div style="display: flex; justify-content: flex-end">
          <el-switch v-model="store.data.container.snapToGrid" />
        </div>
      </el-col>
    </el-row>

    <template v-if="store.data.container.snapToGrid">
      <el-row :gutter="10">
        <el-col :span="10">网格大小:</el-col>
        <el-col :span="14">
          <InputNumber v-model="store.data.container.gridSize" />
        </el-col>
      </el-row>

      <el-row :gutter="10">
        <el-col :span="10">网格颜色:</el-col>
        <el-col :span="14">
          <ColorPicker v-model="store.data.container.gridColor" />
        </el-col>
      </el-row>
    </template>

    <el-divider />

    <el-row :gutter="10">
      <el-col :span="10">参考线:</el-col>
      <el-col :span="14">
        <div style="display: flex; justify-content: flex-end">
          <el-switch v-model="store.data.container.markline.show" />
        </div>
      </el-col>
    </el-row>
  </el-form>
</template>

<style lang="scss" scoped>
.el-form {
  padding: 10px;
}
.el-row {
  margin-bottom: 10px;
}
</style>
