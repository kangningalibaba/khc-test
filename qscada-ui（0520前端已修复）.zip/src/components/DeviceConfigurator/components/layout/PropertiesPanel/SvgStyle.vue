<script setup>
import { useDeviceConfiguratorStore } from '@/store/modules/deviceConfigurator'
import ColorPicker from '../components/ColorPicker.vue'
import TextStyle from '../components/TextStyle.vue'

const store = useDeviceConfiguratorStore()
</script>

<template>
  <el-form :model="store.current" label-width="80px" label-position="left" class="svg-style">
    <template v-if="!store.current.type.includes('line')">
      <el-row :gutter="10">
        <el-col :span="12">填充颜色：</el-col>
        <el-col :span="12">
          <ColorPicker v-model="store.current.props.fill" />
        </el-col>
      </el-row>
    </template>

    <el-row :gutter="10">
      <el-col :span="12">边框颜色：</el-col>
      <el-col :span="12">
        <ColorPicker v-model="store.current.props.stroke" />
      </el-col>
    </el-row>
    <el-row :gutter="10">
      <el-col :span="12">边框宽度：</el-col>
      <el-col :span="12">
        <el-input-number v-model="store.current.props.strokeWidth" :min="0" />
      </el-col>
    </el-row>
    <template v-if="store.current.type === 'rect'">
      <el-row :gutter="10">
        <el-col :span="12">水平圆角：</el-col>
        <el-col :span="12">
          <el-input-number v-model="store.current.props.rx" :min="0" />
        </el-col>
      </el-row>
      <el-row :gutter="10">
        <el-col :span="12">垂直圆角：</el-col>
        <el-col :span="12">
          <el-input-number v-model="store.current.props.ry" :min="0" />
        </el-col>
      </el-row>
    </template>
    <template v-if="store.current.type === 'polygon'">
      <el-row :gutter="10">
        <el-col :span="12">图形边数：</el-col>
        <el-col :span="12">
          <el-input-number v-model="store.current.props.sides" :min="0" />
        </el-col>
      </el-row>
      <el-row :gutter="10">
        <el-col :span="12">初始角度：</el-col>
        <el-col :span="12">
          <el-slider v-model="store.current.props.initialAngle" :min="-180" :max="180" />
        </el-col>
      </el-row>
    </template>
    <template v-if="!store.current.type.includes('line')">
      <el-divider />
      <TextStyle />
    </template>
  </el-form>
</template>
<style lang="scss" scoped>
.svg-style {
  &:deep(.el-button-group) {
    display: inline-flex;
    width: 100%;
  }
}

.text-btn {
  display: flex;
  justify-content: center;
  align-items: center;
  width: 50%;
  height: 100%;
  border-radius: 4px;
  cursor: pointer;
  &:hover {
    background-color: var(--el-fill-color-light);
  }
  :deep(.es-icon) {
    margin-right: 4px;
  }
}
</style>
