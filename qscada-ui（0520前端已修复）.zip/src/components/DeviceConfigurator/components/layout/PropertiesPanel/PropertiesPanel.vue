<script setup>
import { useDeviceConfiguratorStore } from '@/store/modules/deviceConfigurator'
import CanvasStyle from './CanvasStyle.vue'
import ConditionalStyle from './ConditionalStyle.vue'
import ElementStyle from './ElementStyle.vue'
import EventAction from './EventAction.vue'
import GlobalEvents from './GlobalEvents.vue'
import SvgStyle from './SvgStyle.vue'

const store = useDeviceConfiguratorStore()
const elementPanel = ref('properties')
const canvasPanel = ref('properties')

watch(
  () => ({ ...store.current }), // 解构触发所有属性依赖
  (newVal, oldVal) => {
    if (oldVal) {
      // 遍历对象，找出变化的属性
      for (const key in newVal) {
        if (newVal[key] !== oldVal[key]) {
          for (const target of store.otherElements) {
            target[key] = newVal[key] // 仅复制变化的属性
          }
        }
      }
    }
  },
  { deep: true, immediate: true }
)
</script>

<template>
  <div class="properties-panel">
    <el-tabs v-if="store.current?.selected" v-model="elementPanel">
      <el-tab-pane label="静态属性" name="properties">
        <SvgStyle v-if="store.current?.isSvg" />
        <ElementStyle v-else />
      </el-tab-pane>
      <el-tab-pane label="条件样式" name="styles">
        <ConditionalStyle />
      </el-tab-pane>
      <el-tab-pane label="事件动作" name="events">
        <EventAction />
      </el-tab-pane>
    </el-tabs>
    <el-tabs v-else v-model="canvasPanel">
      <el-tab-pane label="画布属性" name="properties">
        <CanvasStyle />
      </el-tab-pane>
      <el-tab-pane label="组态事件" name="structure">
        <GlobalEvents />
      </el-tab-pane>
    </el-tabs>
  </div>
</template>

<style lang="scss" scoped>
.properties-panel {
  height: 100%;
  &:deep(.el-tabs__nav) {
    min-width: 100%;
  }

  &:deep(.el-tabs__item) {
    padding: 0;
    flex-grow: 1;
  }

  &:deep(.el-tabs__content) {
    height: calc(100% - 40px);
    overflow-y: auto;
    padding: 0 10px;
  }

  &:deep(.el-color-picker) {
    width: 100%;

    .el-tooltip__trigger {
      width: 100%;
    }

    .el-color-picker__trigger {
      justify-content: flex-start;
      width: 100%;
      &:after {
        content: '';
        display: inline-block;
        width: 20px;
        height: 20px;
        background-image: url('data:image/svg+xml;charset=utf-8;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBzdGFuZGFsb25lPSJubyI/PjwhRE9DVFlQRSBzdmcgUFVCTElDICItLy9XM0MvL0RURCBTVkcgMS4xLy9FTiIgImh0dHA6Ly93d3cudzMub3JnL0dyYXBoaWNzL1NWRy8xLjEvRFREL3N2ZzExLmR0ZCI+PHN2ZyB0PSIxNzEwODI4MDEyMjYwIiBjbGFzcz0iaWNvbiIgdmlld0JveD0iMCAwIDEwMjQgMTAyNCIgdmVyc2lvbj0iMS4xIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHAtaWQ9IjQyOTMiIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiB3aWR0aD0iMjAwIiBoZWlnaHQ9IjIwMCI+PHBhdGggZD0iTTQ3NS4yIDkwMy4yYy0xNi44IDAtMzQuNC0xLjYtNTMuNi00bC00LjgtMC44Yy0xMzYtMjAuOC0yMjguOC0xNTIuOC0yMzIuOC0xNTguNC0xMzEuMi0yMDAtNjUuNi00MDIuNCA1OC40LTUxNC40IDEyMy4yLTExMiAzMjguOC0xNjAgNTA4LjgtMTUuMkM4NjcuMiAzMDQgOTAyLjQgNDMzLjYgOTA0IDQzOS4ydjEuNmMxNi44IDkxLjIgMy4yIDE1OC40LTQwLjggMjAxLjYtNjcuMiA2NC44LTE3OC40IDQ0LTE5My42IDQwLjgtMjAuOC0yLjQtMzYgNC00Ny4yIDE3LjYtMTIgMTUuMi0xNC40IDM1LjItMTAuNCA0Ny4yIDExLjIgMzMuNiAxMi44IDU5LjIgNC44IDc4LjQtMjMuMiA1MC40LTcwLjQgNzYuOC0xNDEuNiA3Ni44eiBtLTUxLjItNTIuOGw0LjggMC44Yzc3LjYgMTIgMTI0LjgtMy4yIDE0NC00Ni40IDAtMC44IDQtMTEuMi02LjQtNDMuMi0xMC40LTI4LjgtMi40LTY2LjQgMTguNC05MiAyMS42LTI3LjIgNTMuNi0zOS4yIDkxLjItMzUuMmwyLjQgMC44YzAuOCAwIDEwMCAyMS42IDE1MS4yLTI4IDMxLjItMzAuNCA0MC44LTgzLjIgMjcuMi0xNTYuOC0zLjItMTAuNC0zNy42LTEyMy4yLTEzNi44LTIwMi40LTE1Ni44LTEyOC0zMzYuOC04NS42LTQ0NS42IDEyLjhDMTc0LjQgMzUyIDEwMC44IDUyNS42IDIyNCA3MTMuNmMwLjggMCA4NC44IDEyMCAyMDAgMTM2Ljh6IiBwLWlkPSI0Mjk0Ij48L3BhdGg+PHBhdGggZD0iTTI4NCA1MjYuNG0tNDggMGE0OCA0OCAwIDEgMCA5NiAwIDQ4IDQ4IDAgMSAwLTk2IDBaIiBwLWlkPSI0Mjk1Ij48L3BhdGg+PHBhdGggZD0iTTM0MCAzODIuNG0tNDggMGE0OCA0OCAwIDEgMCA5NiAwIDQ4IDQ4IDAgMSAwLTk2IDBaIiBwLWlkPSI0Mjk2Ij48L3BhdGg+PHBhdGggZD0iTTQ4NCAzMDIuNG0tNDggMGE0OCA0OCAwIDEgMCA5NiAwIDQ4IDQ4IDAgMSAwLTk2IDBaIiBwLWlkPSI0Mjk3Ij48L3BhdGg+PHBhdGggZD0iTTY0NCAzNDIuNG0tNDggMGE0OCA0OCAwIDEgMCA5NiAwIDQ4IDQ4IDAgMSAwLTk2IDBaIiBwLWlkPSI0Mjk4Ij48L3BhdGg+PHBhdGggZD0iTTcyNCA0NzAuNG0tNDggMGE0OCA0OCAwIDEgMCA5NiAwIDQ4IDQ4IDAgMSAwLTk2IDBaIiBwLWlkPSI0Mjk5Ij48L3BhdGg+PC9zdmc+');
        background-size: contain;
        margin-left: 4px;
      }
      .el-color-picker__color {
        width: calc(100% - 10px);
      }
    }
  }
}
</style>
