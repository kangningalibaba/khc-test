<script setup>
import { getGlobalJs, setGlobalJs } from '@/api/scada/js'
import { useCommandDialog } from '@/hooks'
import { useDeviceConfiguratorStore } from '@/store/modules/deviceConfigurator.js'
import {
  Delete,
  Download,
  Edit,
  Expand,
  Fold,
  Loading,
  RefreshLeft,
  RefreshRight,
  Upload,
  UploadFilled,
  View
} from '@element-plus/icons-vue'
import { useConfirmDialog } from '@vueuse/core'
import { ElMessage } from 'element-plus'
import { useCommand } from '../../../hooks/useCommand'
import Preview from '../../../Preview.vue'
import CodeEditDialog from '../../CodeEditDialog/'

const emit = defineEmits(['save', 'toggle'])

const { isRevealed, reveal, cancel } = useConfirmDialog()
const store = useDeviceConfiguratorStore()
const codeEdit = useCommandDialog(CodeEditDialog)
const { commands } = useCommand(store)
const graphicPanelVisible = ref(true)
const propertiesPanelVisible = ref(true)
const globalCode = ref('')
const isLoading = ref(false)

const backgroundColor = computed(() => {
  const color = store.data.container.style.backgroundColor
  return color ? color : 'transparent'
})

watch(graphicPanelVisible, (value) => {
  emit('toggle', {
    panel: 'graphic',
    visible: value
  })
})

watch(propertiesPanelVisible, (value) => {
  emit('toggle', {
    panel: 'properties',
    visible: value
  })
})

const exportGraphics = () => {
  const data = JSON.stringify(store.data, null, 2)
  const blob = new Blob([data], { type: 'application/json' })
  const url = URL.createObjectURL(blob)
  const link = document.createElement('a')
  link.href = url
  link.download = `graphics-${Date.now()}.json`
  document.body.appendChild(link)
  link.click()
  document.body.removeChild(link)
  URL.revokeObjectURL(url)
}

const handleToggle = (panel) => {
  if (panel === 'graphic') {
    graphicPanelVisible.value = !graphicPanelVisible.value
  } else if (panel === 'properties') {
    propertiesPanelVisible.value = !propertiesPanelVisible.value
  }
}

const handleImport = (event) => {
  const file = event.target.files[0]
  if (file) {
    const reader = new FileReader()
    reader.onload = (e) => {
      try {
        const data = JSON.parse(e.target.result)
        commands.updateContainer(data)
        // emit('import', data)
      } catch (error) {
        console.error('Failed to parse JSON file:', error)
      }
    }
    reader.readAsText(file)
  }
}

const handleExport = () => {
  exportGraphics()
  // emit('export')
}

const handleSave = () => {
  if (!isLoading.value) {
    isLoading.value = true
    emit('save')
  }
}

function saveDone() {
  isLoading.value = false
}

const handleEditGlobalCode = () => {
  getGlobalJs().then((res) => {
    globalCode.value = res.data
    codeEdit({
      code: globalCode.value,
      onDone: (val) => {
        globalCode.value = val
        setGlobalJs(globalCode.value).then(() => {
          ElMessage.success('全局函数保存成功')
        })
      }
    })
  })
}

defineExpose({
  saveDone
})
</script>

<template>
  <div class="header-panel">
    <el-space class="tools">
      <el-tooltip :content="`${graphicPanelVisible ? '隐藏' : '显示'}图形面板`">
        <el-icon @click="handleToggle('graphic')">
          <Fold v-if="graphicPanelVisible" />
          <Expand v-else />
        </el-icon>
      </el-tooltip>
      <el-divider direction="vertical" />
      <el-tooltip content="撤销">
        <el-icon @click="commands.undo"><RefreshLeft /></el-icon>
      </el-tooltip>
      <el-tooltip content="重做"
        ><el-icon @click="commands.redo"><RefreshRight /></el-icon
      ></el-tooltip>
      <el-divider direction="vertical" />
      <el-tooltip content="全局函数">
        <el-icon @click="handleEditGlobalCode"><Edit /></el-icon>
      </el-tooltip>
      <el-tooltip content="清空">
        <el-icon @click="commands.clear"><Delete /></el-icon>
      </el-tooltip>
      <el-divider direction="vertical" />
      <el-tooltip content="导入">
        <el-icon>
          <label for="import-file" style="cursor: pointer">
            <Upload />
            <input
              id="import-file"
              type="file"
              accept="application/json"
              style="display: none"
              @change="handleImport" />
          </label>
        </el-icon>
      </el-tooltip>
      <el-tooltip content="导出">
        <el-icon @click="handleExport"><Download /></el-icon>
      </el-tooltip>
      <el-divider direction="vertical" />
      <el-tooltip content="保存">
        <el-icon @click="handleSave"><Loading class="is-loading" v-if="isLoading" /><UploadFilled v-else /></el-icon>
      </el-tooltip>
    </el-space>
    <el-space class="settings">
      <el-tooltip content="预览">
        <el-icon @click="reveal"><View /></el-icon>
      </el-tooltip>
      <el-divider direction="vertical" />
      <!-- <el-tooltip content="帮助"
        ><el-icon><QuestionFilled /></el-icon
      ></el-tooltip>
      <el-divider direction="vertical" /> -->
      <el-tooltip :content="`${propertiesPanelVisible ? '隐藏' : '显示'}属性面板`">
        <el-icon @click="handleToggle('properties')">
          <Expand v-if="propertiesPanelVisible" />
          <Fold v-else />
        </el-icon>
      </el-tooltip>
    </el-space>
    <el-dialog
      class="preview-dialog"
      v-model="isRevealed"
      title="组态预览"
      draggable
      destroy-on-close
      :modal="false"
      :width="store.data.container.style.width"
      @close="cancel">
      <el-scrollbar wrap-class="designer-preview-wrap" view-class="designer-preview-view">
        <Preview :data="store.data" />
      </el-scrollbar>
    </el-dialog>
  </div>
</template>

<style lang="scss" scoped>
.header-panel {
  display: flex;
  justify-content: space-between;
  width: 100%;
}
</style>

<style lang="scss">
.preview-dialog {
  padding: 0;
  margin: auto;
  display: flex;
  flex-direction: column;
  max-width: 95vw;
  max-height: 95vh;

  .el-dialog__title {
    line-height: 2.4;
    padding-left: 16px;
  }

  .el-dialog__header {
    padding-bottom: 0;
  }

  .el-dialog__body {
    flex: 1;
    padding: 0;
  }

  .designer-preview-wrap {
    display: flex;
    align-items: center;
    background-color: v-bind(backgroundColor);
  }

  .designer-preview-view {
    display: flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
    margin: auto;
    flex-direction: column;
  }
}

.is-loading {
  animation: rotating 2s linear infinite;
}

@keyframes rotating {
  from {
    transform: rotate(0deg);
  }
  to {
    transform: rotate(360deg);
  }
}
</style>
