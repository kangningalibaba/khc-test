export { default } from './FooterPanel.vue'
