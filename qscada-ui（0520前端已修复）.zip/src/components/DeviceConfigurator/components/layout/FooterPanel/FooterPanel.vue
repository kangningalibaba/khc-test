<template>
  <div class="footer-panel">© 2025</div>
</template>

<style lang="scss" scoped>
.footer-panel {
  height: 100%;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: var(--el-font-size-extra-small);
  color: var(--el-text-color-secondary);
}
</style>
