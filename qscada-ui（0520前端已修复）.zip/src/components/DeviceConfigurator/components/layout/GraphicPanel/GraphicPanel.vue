<script setup>
import { listAllFolder } from '@/api/scada/folder'
import { getImagesByFolderId } from '@/api/scada/image'
import { graphicGroups } from '../../Graphics'

const emit = defineEmits(['dragstart', 'dragend'])

const activeNames = ref(['base'])
const customGallery = ref([])

const allGraphicGroups = computed(() => {
  return [...graphicGroups, ...customGallery.value]
})
function dragstart(e, component) {
  let width = 50,
    height = 50
  if (component.component !== 'es-icon') {
    width = component.width || e.target.offsetWidth
    height = component.height || e.target.offsetHeight
  }
  emit('dragstart', {
    ...component,
    width,
    height
  })
}

function dragend() {
  emit('dragend')
}

function getCustomGallery() {
  listAllFolder()
    .then((data) => {
      const promises = data.map(function (item) {
        return getImagesByFolderId(item.id)
      })
      return Promise.all(promises)
    })
    .then((data) => {
      customGallery.value = data
        .filter((arr) => arr.length)
        .map(function (item) {
          return {
            title: item[0].folderName,
            name: item[0].folderName,
            graphics: item.map((image) => {
              return {
                type: 'image',
                text: image.imageName,
                component: 'img',
                width: 200,
                height: 200,
                props: {
                  src: import.meta.env.VITE_APP_BASE_API + image.imagePath
                }
              }
            })
          }
        })
    })
}

onBeforeMount(() => {
  getCustomGallery()
})
</script>

<template>
  <el-scrollbar>
    <el-collapse class="graphic-panel" v-model="activeNames">
      <el-collapse-item v-for="group in allGraphicGroups" :key="group.name" :title="group.title" :name="group.name">
        <div class="collapse-content">
          <div
            class="graphic-block"
            v-for="graphic in group.graphics"
            :key="graphic.id"
            draggable="true"
            @dragstart="dragstart($event, graphic)"
            @dragend="dragend">
            <div class="block-icon" v-if="graphic.icon"><svg-icon :icon-class="graphic.icon" /></div>
            <div v-else-if="graphic.component === 'img'" class="block-icon">
              <img :src="graphic.props.src" />
            </div>
            <div v-if="graphic.text" class="block-text">{{ graphic.text }}</div>
          </div>
        </div>
      </el-collapse-item>
    </el-collapse>
  </el-scrollbar>
</template>

<style lang="scss" scoped>
.graphic-panel {
  border-top: 0;
  border-bottom: 0;
  --el-collapse-border-color: var(--el-border-color);

  .el-collapse-item {
    :deep(.el-collapse-item__header) {
      padding-left: 10px;
    }
    :deep(.el-collapse-item__content) {
      padding-top: 16px;
      padding-bottom: 16px;
    }
    &.is-active {
      :deep(.el-collapse-item__wrap) {
        border-top: 1px solid var(--el-collapse-border-color);
      }
    }
    &:last-of-type {
      :deep(.el-collapse-item__wrap) {
        border-bottom-color: transparent;
      }
    }
  }
}

.collapse-content {
  display: grid;
  grid-template-columns: repeat(auto-fill, 80px);
  grid-gap: 10px;
  justify-content: space-evenly;

  .graphic-block {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    cursor: grab;
    user-select: none;
    border: 1px solid var(--el-border-color);
    border-radius: 4px;

    .block-icon {
      font-size: 48px;
      line-height: 1.5;
      img {
        width: 48px;
        height: 48px;
        object-fit: contain;
      }
    }
  }
}
</style>
