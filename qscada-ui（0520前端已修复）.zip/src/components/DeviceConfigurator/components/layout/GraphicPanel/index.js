export { default } from './GraphicPanel.vue'
