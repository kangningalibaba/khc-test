export { default } from './MainPanel.vue'
