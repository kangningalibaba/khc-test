<script setup>
import { useDeviceConfiguratorStore } from '@/store/modules/deviceConfigurator'
const store = toRef(useDeviceConfiguratorStore())

const { width, height } = store.value.data.container.style
</script>

<template>
  <div class="main-panel" :style="{ width, height }">
    <slot></slot>
  </div>
</template>

<style lang="scss" scoped>
.main-panel {
  width: v-bind(width);
  height: v-bind(height);
  background-color: var(--el-bg-color);
  box-shadow: 0 0 10px rgba(64, 64, 64, 0.1);
  overflow: hidden;
}
</style>
