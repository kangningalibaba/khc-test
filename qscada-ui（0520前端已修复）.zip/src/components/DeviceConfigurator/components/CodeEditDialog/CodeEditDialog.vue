<template>
  <el-dialog v-model="dialogVisible" title="JavaScript" width="1000">
    <code-editor height="calc(100vh - 300px)" v-model="editingCode" :language="language" v-loading="loading" />
    <div v-if="tip.title">{{ tip.title }}</div>
    <strong v-if="tip.subTitle">
      例如：<code>{{ tip.subTitle }}</code>
    </strong>
    <template #footer>
      <div class="dialog-footer">
        <el-button @click="cancel">取消</el-button>
        <el-button type="primary" @click="handleConfirm">确定</el-button>
      </div>
    </template>
  </el-dialog>
</template>

<script setup>
import CodeEditor from '@/components/CodeEditor/index.vue'
import { computed, onMounted, ref } from 'vue'

const editingCode = ref('')
const loading = ref(false)
const { code, language, visible, tip, onDone } = defineProps({
  code: { type: String, default: '' },
  visible: { type: Boolean, default: false },
  tip: { type: Object, default: () => ({}) },
  language: { type: String, default: 'javascript' },
  onDone: { type: Function, default: () => {} }
})

const dialogVisible = computed({
  get() {
    return visible
  },
  set(val) {
    emits('update:visible', val)
    if (!val) {
      emits('close')
    }
  }
})

const emits = defineEmits(['update:visible', 'close'])

function cancel() {
  dialogVisible.value = false
}
function handleConfirm() {
  onDone(editingCode.value)
  cancel()
}

onMounted(() => {
  editingCode.value = code
})
</script>
