export { default } from './SelectArea.vue'
