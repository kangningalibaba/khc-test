<script setup name="ConfigurationPreview">
import { getDataByPastTime } from '@/api/scada/echart'
import { getGlobalJs } from '@/api/scada/js'
import { getScene } from '@/api/scada/scene'
import { setVariables } from '@/api/scada/variable'
import { useFreeDialog } from '@/components/FreeDialog'
import { useGlobalVariableStore } from '@/store/modules/globalVariable'
import { useDebounceFn, useIntervalFn } from '@vueuse/core'
import { computed, onBeforeMount, onBeforeUnmount, onMounted, reactive, watch } from 'vue'
import { components } from './components/Graphics'
import TextEditor from './components/TextEditor'
import { Preview } from './index'
import { extractFunctions, sandbox } from './utils/common'
import { enableAnimation, enableProps, enableStyle, pickStyle } from './utils/style'

const { data } = defineProps({
  data: { type: Object, required: true }
})

const { open, close, has } = useFreeDialog()
const { variables } = useGlobalVariableStore()
const expressionAction = reactive(new Map())
const expressionResult = reactive(new Map())
const router = useRouter()
const functions = ref({})
const periodicEvents = reactive([])
const echarts = ref([])

const context = computed(() => {
  return {
    ...variables,
    ...functions.value
  }
})
const canvasStyle = computed(() => {
  const { width, height, ...others } = data.container.style
  return {
    ...others,
    width: `${width}px`,
    height: `${height}px`
  }
})

const debounceExecuteAction = useDebounceFn((actions) => {
  executeAction(actions)
}, 1000)
const { pause, resume } = useIntervalFn(updateECharts, 5000)

watch(
  () => context.value,
  () => {
    compileExpressions()
  },
  { deep: true }
)

watch(
  () => expressionResult,
  (exprResult) => {
    for (let [expr, result] of exprResult.entries()) {
      if (result) {
        const actionList = expressionAction.get(expr)
        debounceExecuteAction(actionList)
      }
    }
  },
  { deep: true }
)

function parseStringToObject(str) {
  const obj = {}
  str.split(',').forEach((pair) => {
    const [key, value] = pair.split('=')
    obj[key] = value
  })
  return obj
}
function executeAction(actions, event) {
  actions.forEach((action) => {
    if (action.actionName == 'open') {
      if (action.openWith) {
        if (action.openWith == 'blank') {
          // router.push(action.pageUrl)
          const url = router.resolve({ name: 'DeviceConfigurationPreview', query: { id: action.sceneId } })
          window.open(url.href, '_blank')
        } else if (action.openWith == 'self') {
          router.replace({ name: 'DeviceConfigurationPreview', query: { id: action.sceneId } })
        } else if (action.openWith == 'dialog') {
          getScene(action.sceneId).then((res) => {
            if (res.code == 200) {
              const { data } = res
              const sceneData = JSON.parse(data.data)
              const id = `sceneId-${action.sceneId}`
              if (has(id)) {
                close(id)
              } else {
                open({
                  id: `sceneId-${action.sceneId}`,
                  title: `组态预览`,
                  initialPosition: { top: event?.clientX ?? 0, left: event?.clientX ?? 0 },
                  content: h(Preview.default, { data: sceneData }) // 新增：传递字符串内容
                })
              }
            }
          })
          // previewDialog({
          //   title: '详情',
          //   url: action.pageUrl
          // })
        }
      }
    } else if (action.actionName == 'setValue') {
      if (action.variables) {
        const variablesData = parseStringToObject(action.variables)
        setVariables(variablesData).then((res) => {
          console.log(res)
        })
      }
    } else if (action.actionName == 'executeCode') {
      sandbox(action.actionValue, context.value, false)
    }
  })
}
function processEvent(events) {
  let eventMaps = {}
  if (events && events.length) {
    events
      .filter((event) => {
        if (event.eventName === 'expression') {
          expressionAction.set(event.expression, event.actions)
          return false
        } else {
          return true
        }
      })
      .forEach((event) => {
        eventMaps[event.eventName] = function (e) {
          e.stopPropagation()
          executeAction(event.actions, e)
        }
      })
  }
  return eventMaps
}

function analyze(text) {
  // 使用正则匹配花括号包裹的内容
  const regex = /\{\{([^}]+)\}\}/g
  if (regex.test(text)) {
    // 提取并解析花括号内的表达式
    return text.replace(regex, (_, expr) => {
      try {
        return sandbox(expr, context.value)
      } catch (error) {
        console.error(`Error evaluating expression: ${expr}`, error)
        return `{{${expr}}}` // 如果解析失败，返回原始花括号内容
      }
    })
  }
  // 如果没有花括号，原样返回
  return text
}

function eventDelivery() {
  data.events?.forEach((event) => {
    if (event.eventName === 'period') {
      periodicEvents.push(
        setInterval(() => {
          const { actions } = event
          executeAction(actions)
        }, event.period)
      )
    } else if (event.eventName === 'expression') {
      expressionAction.set(event.expression, event.actions)
      expressionResult.set(event.expression, false)
    }
  })
}

function compileExpressions() {
  for (let expression of expressionResult.keys()) {
    expressionResult.set(expression, sandbox(expression, context.value))
  }
}

function init() {
  getGlobalJs().then((res) => {
    if (res.code == 200) {
      functions.value = extractFunctions(res.data)
    }
  })
}

function extractECharts() {
  echarts.value = data.elements.filter((item) => {
    return item.type === 'e-chart' && item.props?.bindData
  })
}

function setChartData(data, chartOption) {
  const xAxisData = new Set()
  const series = []
  const type = chartOption.series[0].type
  for (let varName in data) {
    series.push({
      name: varName,
      type: type,
      data: data[varName].map((item) => {
        xAxisData.add(item.name)
        return item.value
      })
    })
  }
  chartOption.xAxis.data = [...xAxisData]
  chartOption.series = series
}

function updateECharts() {
  for (let item of echarts.value) {
    const { bindData, pastTime, pastTimeType, interval, intervalUnit, option } = item.props
    getDataByPastTime({ varList: bindData.split(','), pastTime, pastTimeType, interval, intervalUnit }).then((res) => {
      if (res.code == 200) {
        setChartData(res.data, option)
      }
    })
  }
}

onMounted(() => {
  extractECharts()
  resume()
})

onBeforeMount(() => {
  init()
  eventDelivery()
})

onBeforeUnmount(() => {
  periodicEvents.forEach((item) => {
    clearInterval(item)
  })
  pause()
})
</script>

<template>
  <div class="preview" :style="canvasStyle">
    <template v-for="item in data.elements" :key="item.id">
      <div
        :style="{
          width: item.width + 'px',
          height: item.height + 'px',
          position: 'absolute',
          left: item.left + 'px',
          top: item.top + 'px'
        }">
        <component
          :is="Object.hasOwn(components, item.component) ? components[item.component] : item.component"
          v-bind="{
            ...item.props,
            ...enableProps(item.conditionalStyles, context),
            class: enableAnimation(item.conditionalStyles, context)
          }"
          v-on="processEvent(item.events)"
          :style="{
            ...pickStyle(item.style, false),
            width: item.width + 'px',
            height: item.height + 'px',
            ...enableStyle(item.conditionalStyles, context)
          }">
          <TextEditor v-if="item.text" :text="analyze(item.text)" :style="pickStyle(item.style)" />
        </component>
      </div>
    </template>
  </div>
</template>

<style lang="scss" scoped>
.preview {
  position: relative;
  height: 100%;
}
</style>
