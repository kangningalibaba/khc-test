<script setup name="DeviceConfiguratorDesigner">
import { useDeviceConfiguratorStore } from '@/store/modules/deviceConfigurator'
import request from '@/utils/request'
import { useEventBus } from '@vueuse/core'
import html2canvas from 'html2canvas'
import { ref, useTemplateRef } from 'vue'
import DragCanvas from './components/DragCanvas'
import FooterPanel from './components/layout/FooterPanel'
import GraphicPanel from './components/layout/GraphicPanel'
import HeaderPanel from './components/layout/HeaderPanel'
import MainPanel from './components/layout/MainPanel'
import PropertiesPanel from './components/layout/PropertiesPanel'
import { deepCopy, useId } from './utils/common'

const eventBus = useEventBus('drag-canvas')
const store = useDeviceConfiguratorStore()
const graphicPanelVisible = ref(true)
const propertiesPanelVisible = ref(true)
const mainRef = useTemplateRef('mainRef')
const headerRef = useTemplateRef('headerRef')

const { data, onSave } = defineProps({
  data: {
    type: Object,
    required: true
  },
  onSave: {
    type: Function,
    default: (saveData) => {
      console.log('save', saveData)
    }
  }
})
function handleSave() {
  const canvas = mainRef.value.$el
  html2canvas(canvas).then((canvas) => {
    canvas.toBlob((blob) => {
      const file = new File([blob], 'image.png', {
        type: 'image/png'
      })
      const formData = new FormData()
      formData.append('file', file)
      request({
        url: '/common/upload',
        method: 'post',
        headers: { 'Content-Type': 'multipart/form-data' },
        data: formData
      })
        .then((res) => {
          onSave({ ...store.data }, res.fileName)
        })
        .finally(() => {
          headerRef.value.saveDone()
        })
      store.upload(formData)
    })
  })
  // onSave({ ...store.data })
}

let currentComponent = null

function init() {
  store.data.container.style.width = store.initWidth
  store.data.container.style.height = store.initHeight
}

function handlePanelToggle({ panel, visible }) {
  if (panel === 'graphic') {
    graphicPanelVisible.value = visible
  } else if (panel === 'properties') {
    propertiesPanelVisible.value = visible
  }
}

function handleAsideDragStart(component) {
  eventBus.emit('dragstart')
  // 拷贝
  currentComponent = deepCopy(component)
}
function handleAsideDragEnd() {
  eventBus.emit('dragend')
}
function dragenter(e) {
  e.dataTransfer.dropEffect = 'move'
}

function drop(e) {
  if (!currentComponent) return
  const isIcon = currentComponent.component === 'es-icon'
  const elements = [
    ...store.data.elements,
    {
      ...currentComponent,
      equalProportion: isIcon,
      left: e.offsetX - currentComponent.width / 2,
      top: e.offsetY - currentComponent.height / 2,
      id: useId(),
      style: currentComponent.style || {}
    }
  ]
  for (let i = 0; i < elements.length; i++) {
    if (i < elements.length - 1) {
      elements[i].selected = false
    }
  }
  store.data.elements = elements
  store.current = elements[elements.length - 1]
  store.current.selected = true
  currentComponent = null
}

watch(
  () => data,
  () => {
    store.update(data)
  },
  { immediate: true }
)

onMounted(() => {
  init()
})
</script>

<template>
  <el-container class="designer">
    <el-header>
      <HeaderPanel ref="headerRef" @save="handleSave" @toggle="handlePanelToggle" />
    </el-header>
    <el-container>
      <Transition name="aside">
        <el-aside v-if="graphicPanelVisible">
          <GraphicPanel @dragstart="handleAsideDragStart" @dragend="handleAsideDragEnd" />
        </el-aside>
      </Transition>

      <el-container class="container">
        <el-container>
          <el-main>
            <el-scrollbar wrap-class="main-wrap" viewClass="main-view">
              <main-panel ref="mainRef">
                <DragCanvas v-model="store.data" @dragenter="dragenter" @drop="drop" @dragover.prevent />
              </main-panel>
            </el-scrollbar>
          </el-main>
        </el-container>
        <el-footer>
          <FooterPanel />
        </el-footer>
      </el-container>
      <Transition name="aside">
        <el-aside v-if="propertiesPanelVisible">
          <PropertiesPanel />
        </el-aside>
      </Transition>
    </el-container>
  </el-container>
</template>

<style lang="scss" scoped>
.designer {
  .el-header {
    --el-header-height: 48px;
    display: flex;
    align-items: center;
    border-bottom: 1px solid var(--el-border-color);
  }

  position: relative;
  height: 100%;

  .el-aside {
    --el-aside-width: 320px;
    border-right: 1px solid var(--el-border-color);
    border-left: 1px solid var(--el-border-color);
  }

  .el-container {
    overflow: hidden;
  }

  .container {
    display: flex;
    flex-direction: column;
    position: relative;

    .el-main {
      background-color: var(--el-bg-color-page);
      position: relative;
      padding: 0;
      :deep(.main-wrap) {
        display: flex;
        align-items: center;
      }

      :deep(.main-view) {
        display: flex;
        align-items: center;
        justify-content: center;
        flex-shrink: 0;
        margin: auto;
        flex-direction: column;
      }
    }

    .el-footer {
      --el-footer-height: 32px;
      border-top: 1px solid var(--el-border-color);
    }
  }
}

.aside-enter-active,
.aside-leave-active {
  transition: all 0.2s ease;

  & > * {
    opacity: 0;
  }
}

.aside-enter-from,
.aside-leave-to {
  width: 0;
}
</style>
