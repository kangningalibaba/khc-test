import { sandbox } from './common'

const unitKeys = ['fontSize', 'lineHeight', 'borderWidth', 'borderRadius']
// 将数字转换为百分比
export function toPercent(val) {
  return val * 100 + '%'
}
// 将百分比转换为数字
export function perToNum(perStr) {
  return parseFloat(perStr) / 100
}
export function addPxUnit(value) {
  // 检查传入的值是否已经有单位，例如 %, rem, em 等
  if (`${value}`.match(/^[0-9.-]+(px|%|rem|em|vh|vw)$/)) {
    return value // 如果已经有单位，则不做替换，直接返回
  }

  // 否则，添加 px 单位并返回
  return value + 'px'
}

const textStyleKeys = [
  'fontSize',
  'fontWeight',
  'fontFamily',
  'color',
  'lineHeight',
  'fontStyle',
  'textDecoration',
  'justifyContent',
  'alignItems'
]
// 实现 pickStyle 函数
export function pickStyle(obj, flag = true) {
  if (!obj) return obj
  const result = {}
  const keys = Object.keys(obj).filter((key) => {
    return flag ? textStyleKeys.includes(key) : !textStyleKeys.includes(key)
  })
  for (const key of keys) {
    result[key] = unitKeys.includes(key) ? addPxUnit(obj[key]) : obj[key]
  }
  return result
}

// 实现 pick 函数
export function pick(obj, keys) {
  return keys.reduce((acc, key) => {
    if (Object.prototype.hasOwnProperty.call(obj, key)) {
      acc[key] = obj[key]
    }
    return acc
  }, {})
}

// 实现 omit 函数
export function omit(obj, keys) {
  return Object.keys(obj).reduce((acc, key) => {
    if (!keys.includes(key)) {
      acc[key] = obj[key]
    }
    return acc
  }, {})
}

// 根据表达式启用样式
export function enableStyle(conditionalStyles, globalVariable) {
  let style = {}
  if (conditionalStyles) {
    conditionalStyles.forEach((item) => {
      const { expression, props } = item
      if (Object.keys(globalVariable).length && sandbox(expression, globalVariable)) {
        let newStyle = {}
        props.forEach((item) => {
          if (item.propName != 'animation') {
            newStyle[item.propName] = item.propValue
          }
        })
        style = {
          ...style,
          ...newStyle
        }
      }
    })
  }
  return style
}

//根据表达式启用动画
export function enableAnimation(conditionalStyles, globalVariable) {
  let animation = []
  if (conditionalStyles) {
    conditionalStyles.forEach((item) => {
      const { expression, props } = item
      if (Object.keys(globalVariable).length && sandbox(expression, globalVariable)) {
        props.forEach((item) => {
          if (item.propName == 'animation') {
            animation.push(item.propValue)
          }
        })
      }
    })
    if (animation.length) {
      return animation.push('animate__animated')
    }
  }
  return animation
}

//根据表达式变更状态
export function enableProps(conditionalStyles, globalVariable) {
  let propsData = {}
  if (conditionalStyles) {
    conditionalStyles.forEach((item) => {
      const { expression, props } = item
      if (Object.keys(globalVariable).length && sandbox(expression, globalVariable)) {
        let newProps = {}
        props.forEach((item) => {
          newProps[item.propName] = item.propValue
        })
        propsData = {
          ...propsData,
          ...newProps
        }
      }
    })
  }
  return propsData
}
