import { useId } from './common'
import { perToNum, toPercent } from './style'

/**
 * 组合元素
 * @param elements 元素列表
 * @param editorRect 画布react信息
 * @returns 组合后的列表
 */
export function makeGroup(elements, editorRect) {
  const selectedItems = elements.filter((item) => item.selected)

  if (!selectedItems.length) return elements

  let minLeft = Infinity,
    minTop = Infinity,
    maxLeft = -Infinity,
    maxTop = -Infinity

  Math.max(...selectedItems.map((item) => item.left))
  selectedItems.forEach((item) => {
    // 获取拖拽元素的位置信息，使用rect只是为了处理旋转后位置的边界
    const itemRect = document.getElementById(item.id).getBoundingClientRect()
    // 最小left
    minLeft = Math.min(minLeft, itemRect.left - editorRect.left)
    // 最大left
    maxLeft = Math.max(maxLeft, itemRect.right - editorRect.left)

    // 最小top
    minTop = Math.min(minTop, itemRect.top - editorRect.top)
    // 最大top
    maxTop = Math.max(maxTop, itemRect.bottom - editorRect.top)
  })

  const dragData = {
    left: minLeft,
    top: minTop,
    width: maxLeft - minLeft, // 宽度 = 最大left - 最小left
    height: maxTop - minTop // 高度 = 最大top - 最小top
  }
  let hasRotate = false
  // 子元素相对父元素的位置
  selectedItems.forEach((item) => {
    item.left = item.left - minLeft
    item.top = item.top - minTop
    item.groupStyle = {
      // 使用百分比的好处是组合元素缩放里面的子元素可以自适应
      ...item.style,
      width: toPercent(item.width / dragData.width),
      height: toPercent(item.height / dragData.height),
      left: toPercent(item.left / dragData.width),
      top: toPercent(item.top / dragData.height),
      transform: `rotate(${item.angle || 0}deg)`,
      position: 'absolute'
    }
    if (item.angle) {
      hasRotate = true
    }
  })

  // 组合组件信息
  const groupElement = {
    id: useId(),
    component: 'es-group',
    group: true,
    selected: true,
    ...dragData,
    equalProportion: hasRotate,
    props: {
      // 组合组件的props，参见Group.vue
      elements: selectedItems
    }
  }

  const newElements = elements.filter((item) => !item.selected)

  return [...newElements, groupElement]
}

/**
 * 取消组合
 * @param elements 元素列表
 * @param editorRect 画布react信息
 * @returns 拆分后的列表
 */
export function cancelGroup(elements, editorRect) {
  // 得到当前选中元素
  const current = elements.find((item) => item.selected)
  // 如果没有选中的元素或者不是组合元素直接返回
  if (!current || current.component !== 'es-group') {
    return elements
  }

  // 获取组合元素的子元素列表
  const items = current.props.elements
  const newElements = items.map((item) => {
    // 子组件相对于浏览器视口位置大小
    const componentRect = document.getElementById(item.id).getBoundingClientRect()
    // 获取元素的中心点坐标
    const center = {
      x: componentRect.left - editorRect.left + componentRect.width / 2,
      y: componentRect.top - editorRect.top + componentRect.height / 2
    }
    const groupStyle = item.groupStyle
    // 拆分后的宽高
    const width = current.width * perToNum(groupStyle.width)
    const height = current.height * perToNum(groupStyle.height)

    const obj = {
      width,
      height,
      left: center.x - width / 2,
      top: center.y - height / 2,
      angle: (item.angle || 0) + (current.angle || 0)
    }
    // 将组合样式置空
    item.groupStyle = {}

    return {
      ...item,
      ...obj
    }
  })

  const list = elements.filter((item) => item !== current)
  return [...list, ...newElements]
}
