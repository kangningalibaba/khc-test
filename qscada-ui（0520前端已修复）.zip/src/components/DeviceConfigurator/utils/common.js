import * as acorn from 'acorn'
import * as walk from 'acorn-walk'

let uid = 1
// 设置允许访问的函数
const permittedFunctions = ['console', 'Math']
export function useId(prefix = 'es-drager') {
  return `${prefix}-${Date.now()}-${uid++}`
}

export function deepCopy(obj) {
  return JSON.parse(JSON.stringify(obj))
}
/**
 * 沙盒执行
 * @param {string} code 表达式
 * @param {object} ctx 上下文对象
 * @param {boolean} [needReturn=true] 是否需要返回值
 * @returns 表达式运行结果
 */
export function sandbox(code, ctx = {}, needReturn = true) {
  const proxyHandler = {
    has(target, prop) {
      // 允许访问特定内置函数
      if (permittedFunctions.includes(prop)) return true
      return Object.prototype.hasOwnProperty.call(target, prop)
    },
    get(target, prop) {
      if (prop === Symbol.unscopables) return undefined
      // 优先从上下文中获取属性，避免直接访问全局对象
      if (Object.prototype.hasOwnProperty.call(target, prop)) {
        return target[prop]
      }
      console.warn(`沙盒警告: 尝试访问未定义的属性 "${prop}"`)
      return undefined
    }
  }

  const ctxWithProxy = new Proxy(ctx, proxyHandler)

  try {
    const func = new Function(
      'context',
      `
      with (context) {
        ${needReturn ? 'return ' : ''}${code};
      }
    `
    )
    return func(ctxWithProxy)
  } catch (error) {
    console.error('沙盒执行异常:', error.message || error)
    return null
  }
}
/**
 * 提取代码中的函数
 * @param {string} code js代码
 * @returns 函数集合
 */
export function extractFunctions(code) {
  const functionMap = {}
  const ast = acorn.parse(code, { ecmaVersion: 'latest' })

  walk.simple(ast, {
    // 捕获函数声明（如 function foo(){}）
    FunctionDeclaration(node) {
      if (node.id?.name) {
        const func = new Function('return ' + code.slice(node.start, node.end))()
        functionMap[node.id.name] = func
      }
    },
    // 捕获变量声明的函数（如 const bar = function(){}）
    VariableDeclarator(node) {
      if (node.init?.type === 'FunctionExpression' && node.id?.name) {
        const func = new Function('return ' + code.slice(node.init.start, node.init.end))()
        functionMap[node.id.name] = func
      }
    }
  })

  return functionMap
}
