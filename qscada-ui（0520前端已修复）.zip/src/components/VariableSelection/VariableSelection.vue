<script setup>
import { listDevice } from '@/api/scada/device'
import { listVariable } from '@/api/scada/variable'
import { useTable } from '@/hooks'
import { useClipboard } from '@vueuse/core'
import { ElMessage } from 'element-plus'

const { visible } = defineProps({
  visible: { type: Boolean, default: false }
})
const emits = defineEmits(['update:visible', 'close'])

const showSearch = ref(true) // 显示搜索条件
const devices = ref([])
const { tableData, loading, total, queryParams, page, getList, resetQuery, handleQuery } = useTable(listVariable)
const { copy, isSupported } = useClipboard()
const dialogVisible = computed({
  get() {
    return visible
  },
  set(val) {
    emits('update:visible', val)
    if (!val) {
      emits('close')
    }
  }
})

function getDevice() {
  listDevice({ pageSize: 100000 }).then((r) => {
    devices.value = r.rows
  })
}

function handleCopy(text) {
  copy(text).then(() => {
    ElMessage({
      message: `变量"${text}"已拷贝至剪贴板`,
      type: 'success'
    })
  })
}

onMounted(() => {
  getDevice()
  getList()
})
</script>

<template>
  <el-dialog title="变量选择" v-model="dialogVisible" width="1000px" append-to-body>
    <el-form :model="queryParams" ref="queryForm" size="small" :inline="true" v-show="showSearch" label-width="68px">
      <el-form-item label="名称" prop="name">
        <el-input v-model="queryParams.name" placeholder="请输入名称" clearable @keyup.enter="handleQuery" />
      </el-form-item>
      <el-form-item label="所属设备" prop="deviceId">
        <el-select v-model="queryParams.deviceId" placeholder="请选择" style="width: 200px">
          <el-option v-for="v in devices" :key="v.id" :label="v.name" :value="v.id"></el-option>
        </el-select>
      </el-form-item>
      <el-form-item>
        <el-button type="primary" icon="Search" @click="handleQuery">搜索</el-button>
        <el-button icon="Refresh" @click="resetQuery">重置</el-button>
      </el-form-item>
    </el-form>
    <el-table :data="tableData" v-loading="loading" border stripe>
      <el-table-column label="序号" align="center" type="index" width="60" />
      <el-table-column label="名称" align="center" prop="name" />
      <el-table-column label="所属设备" align="center" prop="deviceName" />
      <el-table-column label="数据类型" align="center" prop="dataType" />
      <el-table-column label="数据长度" align="center" prop="dataLength" />
      <el-table-column label="DB块" align="center" prop="block" />
      <el-table-column label="地址" align="center" prop="address" />
      <el-table-column label="地址字符串" align="center" prop="addressStr" />
      <el-table-column label="操作" align="center" class-name="small-padding fixed-width">
        <template #default="scope">
          <el-button type="text" icon="DocumentCopy" :disabled="!isSupported" @click="handleCopy(scope.row.name)"
            >复制</el-button
          >
        </template>
      </el-table-column>
    </el-table>
    <pagination
      v-show="total > 0"
      :total="total"
      v-model:page="page.pageNum"
      v-model:limit="page.pageSize"
      @pagination="getList" />
  </el-dialog>
</template>
