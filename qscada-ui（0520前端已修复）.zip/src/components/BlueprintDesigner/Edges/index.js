import animation from './animation'
import connection from './connection'

export const registerCustomEdges = (lf) => {
  lf.register(animation)
  lf.register(connection)
}

export { animation, connection }
