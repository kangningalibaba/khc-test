import { BezierEdge, BezierEdgeModel } from '@logicflow/core'

class AnimationEdge extends BezierEdge {}

class AnimationEdgeModel extends BezierEdgeModel {
  // 重写此方法，使保存数据是能带上锚点数据。
  getData() {
    const data = super.getData()
    data.sourceAnchorId = this.sourceAnchorId
    data.targetAnchorId = this.targetAnchorId
    return data
  }
  setAttributes() {
    this.isAnimation = true
  }
  getEdgeAnimationStyle() {
    const style = super.getEdgeAnimationStyle()
    style.stroke = 'blue'
    style.strokeDasharray = '10 5'
    style.animationDuration = '30s'
    style.animationDirection = 'normal'
    return style
  }
}

export default {
  type: 'animation-edge',
  view: AnimationEdge,
  model: AnimationEdgeModel
}
