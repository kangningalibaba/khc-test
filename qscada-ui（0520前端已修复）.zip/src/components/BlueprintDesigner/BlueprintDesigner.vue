<template>
  <div class="designer-container">
    <!-- 画布区域 -->
    <div ref="containerRef" class="viewport"></div>
    <TeleportContainer :flow-id="flowId" />
  </div>
</template>

<script setup name="BlueprintDesigner">
import { allAlgsubmng } from '@/api/scada/algsubmng'
import { useCommandDialog } from '@/hooks'
import LogicFlow from '@logicflow/core'
import '@logicflow/core/es/index.css'
import { Control, Menu, MiniMap, SelectionSelect, Snapshot } from '@logicflow/extension'
import '@logicflow/extension/lib/style/index.css'
import { getTeleport } from '@logicflow/vue-node-registry'
import { onMounted, ref } from 'vue'
import { registerCustomEdges } from './Edges'
import { DndPanelVue } from './Extension/dndPanelVue'
import icons from './icons'
import { registerCustomNodes } from './Nodes'
import PropertySetting from './Properties/PropertySetting.vue'

// 初始化 LogicFlow 实例
const lf = ref(null)
const flowId = ref('')
const containerRef = ref(null)
const TeleportContainer = getTeleport()
const propertySetting = useCommandDialog(PropertySetting)

function getCustomOperator(dndPanelPlugin, patternItems = []) {
  allAlgsubmng().then((res) => {
    const { data } = res
    const customPatternItems = data
      .map((item) => {
        return {
          group: item.dictLabel,
          items: item.child.map((func) => {
            const { algsId, algsName, algsType, algsVersion, defaultVersion, returnName, paramArrObj, returnDes } = func
            return {
              type: 'functionNode',
              text: algsName,
              label: algsName,
              icon: icons.function,
              properties: {
                algsId,
                algsName,
                algsType,
                version: defaultVersion ?? algsVersion,
                defaultVersion: defaultVersion,
                inputParameters: paramArrObj.map((param) => {
                  return {
                    name: param.name,
                    value: param.valDemo,
                    label: param.des,
                    type: param.type,
                    required: param.required
                  }
                }),
                outputParameters: [
                  {
                    name: 'return',
                    value: null,
                    label: '输出参数',
                    type: returnName
                  }
                ],
                returnType: returnName,
                returnDescribe: returnDes
              }
            }
          })
        }
      })
      .filter((item) => item.items.length)
    dndPanelPlugin.setPatternItems(patternItems.concat(customPatternItems))
  })
}

onMounted(() => {
  if (containerRef.value) {
    lf.value = new LogicFlow({
      container: containerRef.value,
      grid: true,
      plugins: [Control, DndPanelVue, Menu, MiniMap, SelectionSelect, Snapshot], // 启用右键菜单、快照插件
      keyboard: { enabled: true }, // 启用键盘快捷键
      edgeType: 'animation-edge',
      edgeGenerator: (sourceNode, targetNode, currentEdge) => {
        console.log('edgeGenerator', sourceNode, targetNode, currentEdge)
        // 起始节点类型 rect 时使用 自定义的边 custom-edge
        if (sourceNode.type === 'variableNode') return 'connection'
      }
    })

    lf.value.setTheme({
      anchorLine: {
        stroke: '#999999',
        strokeWidth: 2,
        strokeDasharray: '3,2'
      }
    })

    lf.value.on('blank:click', (event) => {
      console.log('blank:click', event)
    })

    // 事件监听
    lf.value.on('node:click', ({ data }) => {
      console.log('node:click', data)
      propertySetting({ visible: true, lf: lf.value, nodeData: data })
    })

    lf.value.on('anchor:dragstart', ({ data, nodeModel }) => {
      console.log('dragstart', data)
      if (['functionNode', 'variableNode'].includes(nodeModel.type)) {
        lf.value.graphModel.nodes.forEach((node) => {
          // @ts-ignore
          if (nodeModel.id !== node.id) {
            node.isShowAnchor = true
            node.setProperties({
              isConnection: true
            })
          }
        })
      }
    })

    lf.value.on('anchor:dragend', ({ data, nodeModel }) => {
      console.log('dragend', data)
      if (['functionNode', 'variableNode'].includes(nodeModel.type)) {
        lf.value.graphModel.nodes.forEach((node) => {
          // @ts-ignore
          if (nodeModel.id !== node.id) {
            node.isShowAnchor = false
            lf.value.deleteProperty(node.id, 'isConnection')
          }
        })
      }
    })

    lf.value.on('edge:add', ({ data }) => {
      const { id, sourceAnchorId } = data
      const idInfo = sourceAnchorId.split('_')
      if (idInfo[0] === 'output') {
        lf.value.changeEdgeType(id, 'connection')
      }
      console.log('edge:add', data)
    })

    const patternItems = [
      {
        group: '功能节点',
        items: [
          {
            label: '选区',
            icon: icons.select,
            callback: () => {
              lf.value.extension.selectionSelect.openSelectionSelect()
              lf.value.once('selection:selected', () => {
                lf.value.extension.selectionSelect.closeSelectionSelect()
              })
            }
          }
        ]
      },
      {
        group: '事件节点',
        items: [
          {
            type: 'eventNode',
            text: '开始',
            label: '开始事件',
            properties: { type: 'start' },
            icon: icons.start
          },
          {
            type: 'eventNode',
            text: '结束',
            label: '结束事件',
            properties: { type: 'end' },
            icon: icons.end
          }
        ]
      },
      {
        group: '内置节点',
        items: [
          {
            type: 'judgmentNode',
            text: '逻辑判断',
            label: '逻辑判断',
            icon: icons.judgment
          },
          {
            type: 'branchNode',
            text: '条件分歧',
            label: '条件分歧',
            icon: icons.branch
          }
        ]
      },
      {
        group: '变量节点',
        items: [
          {
            type: 'variableNode',
            text: '变量',
            label: '变量节点',
            icon: icons.variable
          },
          {
            type: 'cacheNode',
            text: '缓存',
            label: '缓存节点',
            icon: icons.cache
          },
          {
            type: 'envNode',
            text: '环境',
            label: '环境节点',
            icon: icons.env
          },
          {
            type: 'fileNode',
            text: '文件',
            label: '文件节点',
            icon: icons.file
          },
          {
            type: 'plcNode',
            text: 'PLC',
            label: 'PLC数据',
            icon: icons.plc
          }
        ]
      }
    ]

    getCustomOperator(lf.value.extension.dndPanelVue, patternItems)

    lf.value.extension.menu.addMenuConfig({
      nodeMenu: [],
      edgeMenu: []
    })
  }

  // 注册自定义节点
  registerCustomNodes(lf.value)

  // 注册自定义边
  registerCustomEdges(lf.value)
})

defineExpose({ lf })
</script>

<style lang="scss" scoped>
.designer-container {
  display: flex;
  height: 100%;

  :deep(.lf-graph) {
    background-color: transparent;
  }

  :deep(.lf-control) {
    background-color: rgba(255, 255, 255, 0.45);

    .lf-control-item:hover {
      background-color: rgba(0, 0, 0, 0.25);
    }
  }

  :deep(.lf-dndpanel) {
    background-color: rgba(255, 255, 255, 0.45);
    .el-collapse {
      min-width: 120px;
      --el-collapse-header-bg-color: rgba(255, 255, 255, 0.45);
      --el-collapse-content-bg-color: rgba(255, 255, 255, 0.45);
    }

    .el-collapse-item__header {
      padding-left: 10px;
      font-weight: bolder;
    }
    .el-collapse-item__wrap {
      max-height: 640px;
      overflow-y: auto;
    }

    .el-collapse-item__content {
      padding-bottom: 10px;
    }

    .lf-dnd-item {
      padding: 8px;
      &:hover {
        background-color: rgba(0, 0, 0, 0.1);
      }
    }
  }
}
.node-palette {
  width: 200px;
  border-right: 1px solid #ccc;
  padding: 10px;
}
.viewport {
  flex: 1;
}
.property-panel {
  width: 300px;
  border-left: 1px solid #ccc;
  padding: 10px;
}
.node-item {
  padding: 8px;
  margin: 4px;
  background: #f0f0f0;
  cursor: move;
}
</style>
