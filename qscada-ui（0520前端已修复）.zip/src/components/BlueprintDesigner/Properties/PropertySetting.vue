<script setup>
import BranchProperty from './BranchProperty.vue'
import CacheProperty from './CacheProperty.vue'
import EnvProperty from './EnvProperty.vue'
import EventProperty from './EventProperty.vue'
import FileProperty from './FileProperty.vue'
import FunctionProperty from './FunctionProperty.vue'
import JudgmentProperty from './JudgmentProperty.vue'
import PLCProperty from './PLCProperty.vue'
import VariableProperty from './VariableProperty.vue'

const propertyFormRef = ref(null)

const { visible, nodeData, onConfirm } = defineProps({
  visible: { type: Boolean, default: false },
  lf: { type: Object, required: true },
  nodeData: { type: Object, required: true },
  onConfirm: { type: Function, default: () => {} }
})
const emits = defineEmits(['update:visible', 'close'])

const dialogVisible = computed({
  get() {
    return visible
  },
  set(val) {
    emits('update:visible', val)
    if (!val) {
      emits('close')
    }
  }
})

const title = computed(() => {
  if (nodeData.type === 'eventNode') {
    return '事件'
  } else if (nodeData.type === 'judgmentNode') {
    return '逻辑判断'
  } else if (nodeData.type === 'branchNode') {
    return '条件分歧'
  } else if (nodeData.type === 'functionNode') {
    return '算子'
  } else if (nodeData.type === 'variableNode') {
    return '变量'
  } else if (nodeData.type === 'cacheNode') {
    return '缓存'
  } else if (nodeData.type === 'envNode') {
    return '环境'
  } else if (nodeData.type === 'fileNode') {
    return '文件'
  } else if (nodeData.type === 'plcNode') {
    return 'PLC数据'
  } else {
    return '未知'
  }
})

const propertyComponent = computed(() => {
  if (nodeData.type === 'eventNode') {
    return EventProperty
  } else if (nodeData.type === 'judgmentNode') {
    return JudgmentProperty
  } else if (nodeData.type === 'branchNode') {
    return BranchProperty
  } else if (nodeData.type === 'variableNode') {
    return VariableProperty
  } else if (nodeData.type === 'cacheNode') {
    return CacheProperty
  } else if (nodeData.type === 'fileNode') {
    return FileProperty
  } else if (nodeData.type === 'envNode') {
    return EnvProperty
  } else if (nodeData.type === 'plcNode') {
    return PLCProperty
  } else {
    return FunctionProperty
  }
})

function cancel() {
  dialogVisible.value = false
}

function confirm() {
  propertyFormRef.value.saveProperty?.()
  cancel()
  onConfirm()
}
</script>

<template>
  <el-drawer v-model="dialogVisible" class="property-setting" size="480px">
    <template #header>
      <h4>{{ title }}节点属性</h4>
    </template>
    <template #default>
      <component ref="propertyFormRef" :is="propertyComponent" :lf="lf" :nodeData="nodeData" />
    </template>
    <template #footer>
      <div style="flex: auto">
        <el-button @click="cancel">取消</el-button>
        <el-button type="primary" @click="confirm">确定</el-button>
      </div>
    </template>
  </el-drawer>
</template>

<style lang="scss" scoped>
.property-setting {
  padding: 20px;
}
</style>
