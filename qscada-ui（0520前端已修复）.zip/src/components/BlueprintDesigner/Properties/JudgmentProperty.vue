<script setup>
const { lf, nodeData } = defineProps({
  lf: { type: Object, required: true },
  nodeData: { type: Object, required: true }
})

const form = reactive({
  name: nodeData.properties.name ?? nodeData.text.value,
  operator: nodeData.properties.operator ?? '$eq'
})

function saveProperty() {
  lf.getNodeModelById(nodeData.id).updateText(form.name)
  lf.getNodeModelById(nodeData.id).setProperties({ ...form })
}

defineExpose({
  saveProperty
})
</script>

<template>
  <el-form :modal="form" label-width="auto">
    <el-form-item label="判断名称">
      <el-input v-model="form.name" />
    </el-form-item>
    <el-form-item label="判断符">
      <el-select v-model="form.operator" placeholder="请选择运算符" filterable style="width: 240px">
        <el-option label="=" value="$eq" />
        <el-option label=">" value="$gt" />
        <el-option label="≥" value="$gte" />
        <el-option label="<" value="$lt" />
        <el-option label="≤" value="$lte" />
        <el-option label="≠" value="$ne" />
      </el-select>
    </el-form-item>
  </el-form>
</template>
