<script setup>
const { lf, nodeData } = defineProps({
  lf: { type: Object, required: true },
  nodeData: { type: Object, required: true }
})

const form = reactive({
  name: nodeData.properties.name ?? nodeData.text.value,
  defaultVal: nodeData.properties.defaultVal ?? false
})

function saveProperty() {
  lf.getNodeModelById(nodeData.id).updateText(form.name)
  lf.getNodeModelById(nodeData.id).setProperties({ ...form })
}

defineExpose({
  saveProperty
})
</script>

<template>
  <el-form :modal="form" label-width="auto">
    <el-form-item label="条件名称">
      <el-input v-model="form.name" />
    </el-form-item>
    <el-form-item label="条件默认值">
      <el-switch v-model="form.defaultVal" active-text="True" inactive-text="False" />
    </el-form-item>
  </el-form>
</template>
