<script setup>
const { lf, nodeData } = defineProps({
  lf: { type: Object, required: true },
  nodeData: { type: Object, required: true }
})

const form = reactive({
  name: nodeData.properties.name ?? nodeData.text.value,
  type: nodeData.properties.type ?? 'start'
})

function typeChange(value) {
  if (value === 'start') {
    form.name = form.name.replace('结束', '开始')
  } else {
    form.name = form.name.replace('开始', '结束')
  }
}

function saveProperty() {
  lf.getNodeModelById(nodeData.id).updateText(form.name)
  lf.getNodeModelById(nodeData.id).setProperties({ ...form })
}

defineExpose({
  saveProperty
})
</script>

<template>
  <el-form :modal="form" label-width="auto">
    <el-form-item label="事件名称">
      <el-input v-model="form.name" />
    </el-form-item>
    <el-form-item label="事件类型">
      <el-select v-model="form.type" placeholder="请选择事件类型" @change="typeChange">
        <el-option label="开始" value="start" />
        <el-option label="结束" value="end" />
      </el-select>
    </el-form-item>
  </el-form>
</template>
