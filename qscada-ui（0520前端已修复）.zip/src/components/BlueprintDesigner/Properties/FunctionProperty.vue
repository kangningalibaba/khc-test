<script setup>
import { allAlgsubmng, getHistoryAlgsubmng } from '@/api/scada/algsubmng'

const { lf, nodeData } = defineProps({
  lf: { type: Object, required: true },
  nodeData: { type: Object, required: true }
})

const form = reactive({
  algsId: nodeData.properties.algsId ?? null,
  algsName: nodeData.properties.algsName ?? nodeData.text.value,
  algsType: nodeData.properties.algsType ?? null,
  version: nodeData.properties.version ?? null,
  inputParameters: nodeData.properties.inputParameters ?? [],
  outputParameters: nodeData.properties.outputParameters ?? [],
  returnType: nodeData.properties.returnType ?? null,
  returnDescribe: nodeData.properties.returnDescribe ?? null
})

const operators = ref([])
const versions = reactive(new Map())
const algsIdToData = reactive(new Map())
const hasModify = ref(false)

function operatorChange(value) {
  getVersions(value)
  const { algsName, algsType } = algsIdToData.get(value)
  form.algsName = algsName
  form.algsType = algsType
  hasModify.value = true
}

function operatorVersionChange(value) {
  form.inputParameters = versions.get(value).inputParameters
  form.outputParameters = versions.get(value).outputParameters
}

function getVersions(algsId) {
  getHistoryAlgsubmng(algsId).then((res) => {
    res.data.forEach((item) => {
      const paramArr = JSON.parse(item.paramArr) ?? []
      const returnName = item.returnName
      versions.set(item.algsVersion, {
        inputParameters: paramArr.map((param) => {
          return {
            name: param.name,
            value: null,
            label: param.des,
            type: param.type
          }
        }),
        outputParameters: [
          {
            name: 'return',
            value: null,
            label: '输出参数',
            type: returnName
          }
        ]
      })
    })
  })
}
function saveProperty() {
  lf.getNodeModelById(nodeData.id).updateText(form.algsName)
  lf.getNodeModelById(nodeData.id).setProperties({ ...form })
  if (hasModify.value) {
    lf.deleteEdgeByNodeId({
      sourceNodeId: nodeData.id
    })
    lf.deleteEdgeByNodeId({
      targetNodeId: nodeData.id
    })
  }
}

onMounted(() => {
  allAlgsubmng().then((res) => {
    operators.value = res.data.map((item) => {
      return {
        label: item.dictLabel,
        options: item.child.map((func) => {
          const { algsId, algsName, ...data } = func
          algsIdToData.set(func.algsId, { algsName, ...data })
          return {
            label: algsName,
            value: algsId
          }
        })
      }
    })
  })
  if (form.algsId) {
    getVersions(form.algsId)
  }
})

defineExpose({
  saveProperty
})
</script>

<template>
  <el-form :modal="form" label-width="auto">
    <el-form-item label="运行算子">
      <el-select
        v-model="form.algsId"
        placeholder="请选择算子"
        filterable
        style="width: 240px"
        @change="operatorChange">
        <el-option-group v-for="group in operators" :key="group.label" :label="group.label">
          <el-option v-for="item in group.options" :key="item.value" :label="item.label" :value="item.value" />
        </el-option-group>
      </el-select>
    </el-form-item>
    <el-form-item label="算子名称">
      <el-input v-model="form.algsName" placeholder="请输入内容" />
    </el-form-item>
    <el-form-item label="算子版本">
      <el-select
        v-model="form.version"
        placeholder="请选择算子版本"
        filterable
        style="width: 240px"
        @change="operatorVersionChange">
        <!-- <el-option v-for="version in versions.keys()" :key="version" :label="version" :value="version" /> -->
        <el-option v-for="item in versions.keys()" :key="item" :label="item" :value="item">
          <el-space :size="100">
            <span style="float: left">{{ item }}</span>
            <span
              v-if="item == nodeData.properties.defaultVersion"
              style="float: right; color: var(--el-text-color-secondary); font-size: 12px">
              <el-tag type="primary">默认</el-tag>
            </span>
          </el-space>
        </el-option>
      </el-select>
    </el-form-item>
    <el-form-item
      v-for="(param, index) in form.inputParameters"
      :key="param.name"
      :label="`${param.label}(${param.type})`"
      :prop="`params.${index}.value`">
      <el-switch v-if="param.type === 'BOOLEAN'" v-model="param.value" />
      <el-input-number
        v-else-if="param.type === 'INTEGER' || param.type === 'DOUBLE'"
        v-model="param.value"
        :precision="param.type === 'DOUBLE' ? 2 : 0" />
      <el-input v-else v-model="param.value" placeholder="请输入内容" />
    </el-form-item>
  </el-form>
  <el-alert
    :description="`返回值类型(${form.returnType})：${form.returnDescribe}`"
    type="warning"
    show-icon
    :closable="false" />
</template>
