<script setup>
const { lf, nodeData } = defineProps({
  lf: { type: Object, required: true },
  nodeData: { type: Object, required: true }
})

const form = reactive({
  name: nodeData.properties.name ?? nodeData.text.value,
  envName: nodeData.properties.envName ?? ''
})

function saveProperty() {
  lf.getNodeModelById(nodeData.id).updateText(form.name)
  lf.getNodeModelById(nodeData.id).setProperties({ ...form })
}

defineExpose({
  saveProperty
})
</script>

<template>
  <el-form :modal="form" label-width="auto">
    <el-form-item label="变量名称">
      <el-input v-model="form.name" />
    </el-form-item>
    <el-form-item label="环境变量">
      <el-input v-model="form.envName" />
    </el-form-item>
  </el-form>
</template>
