<script setup>
const { lf, nodeData } = defineProps({
  lf: { type: Object, required: true },
  nodeData: { type: Object, required: true }
})

const form = reactive({
  name: nodeData.properties.name ?? nodeData.text.value,
  type: nodeData.properties.type ?? 'string',
  defaultVal: nodeData.properties.defaultVal ?? ''
})

function saveProperty() {
  lf.getNodeModelById(nodeData.id).updateText(form.name)
  lf.getNodeModelById(nodeData.id).setProperties({ ...form })
}

defineExpose({
  saveProperty
})
</script>

<template>
  <el-form :modal="form" label-width="auto">
    <el-form-item label="变量名">
      <el-input v-model="form.name" />
    </el-form-item>
    <el-form-item label="变量类型">
      <el-select v-model="form.type" placeholder="请选择变量类型">
        <el-option label="字符串" value="string" />
        <el-option label="整数" value="integer" />
        <el-option label="浮点数" value="double" />
        <el-option label="布尔值" value="boolean" />
      </el-select>
    </el-form-item>
    <el-form-item label="默认值">
      <el-input v-model="form.defaultVal" />
    </el-form-item>
  </el-form>
</template>
