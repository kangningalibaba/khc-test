import { register, VueNodeModel } from '@logicflow/vue-node-registry'
import BranchNode from './BranchNode.vue'
import CacheNode from './CacheNode.vue'
import EnvNode from './EnvNode.vue'
import EventNode from './EventNode.vue'
import FileNode from './FileNode.vue'
import FunctionNode from './FunctionNode.vue'
import JudgmentNode from './JudgmentNode.vue'
import PLCNode from './PLCNode.vue'
import VariableNode from './VariableNode.vue'
/**
 * 锚点规则，只允许从右边的锚点连出
 */
const anchorOnlyAsTarget = {
  message: '只允许从右边的锚点连出',
  validate: (sourceNode, targetNode, sourceAnchor) => {
    return sourceAnchor.type === 'output' || sourceAnchor.type === 'export'
  }
}
/**
 * 锚点规则，只允许连接左边的锚点
 */
const anchorOnlyAsSource = {
  message: '只允许连接左边的锚点',
  validate: (sourceNode, targetNode, sourceAnchor, targetAnchor) => {
    return (
      (sourceAnchor.type === 'output' && targetAnchor.type === 'input') ||
      (sourceAnchor.type === 'export' && targetAnchor.type === 'import')
    )
  }
}
class BranchNodeModel extends VueNodeModel {
  setAttributes() {
    this.width = 160
    this.height = 74
    this.text.y = this.y - this.height / 2 + 12
    this.sourceRules.push(anchorOnlyAsTarget)
    this.targetRules.push(anchorOnlyAsSource)
  }

  getDefaultAnchor() {
    const { x, y, width, height, id } = this
    const anchors = [
      { x: x - width / 2, y: y - height / 2 + 12, id: `import_${id}`, type: 'import' },
      {
        x: x + width / 2,
        y: y + 24 - height / 2 + 12,
        id: `export_true_${id}`,
        type: 'export'
      },
      {
        x: x + width / 2,
        y: y + 48 - height / 2 + 12,
        id: `export_false_${id}`,
        type: 'export'
      },
      { x: x - width / 2, y: y + 24 - height / 2 + 12, id: `input_${id}`, type: 'input' }
    ]
    return anchors
  }
}
/**
 * 注册判断节点
 */
class JudgmentNodeModel extends VueNodeModel {
  setAttributes() {
    this.width = 180
    this.height = 74
    this.text.y = this.y - this.height / 2 + 12
    this.sourceRules.push(anchorOnlyAsTarget)
    this.targetRules.push(anchorOnlyAsSource)
  }

  getDefaultAnchor() {
    const { x, y, width, height, id } = this
    const anchors = [
      { x: x - width / 2, y: y + 24 - height / 2 + 12, id: `input_left_${id}`, type: 'input' },
      { x: x - width / 2, y: y + 48 - height / 2 + 12, id: `input_right_${id}`, type: 'input' },
      { x: x + width / 2, y: y + 36 - height / 2 + 12, id: `output_${id}`, type: 'output' }
    ]
    return anchors
  }
}
/**
 * 注册事件节点
 */
class EventNodeModel extends VueNodeModel {
  setAttributes() {
    this.width = 80
    this.height = 80
    this.sourceRules.push(anchorOnlyAsTarget)
    this.targetRules.push(anchorOnlyAsSource)
  }

  getDefaultAnchor() {
    const {
      x,
      y,
      width,
      id,
      isHovered,
      isSelected,
      properties: { isConnection, type }
    } = this
    const anchors = []
    if ((isConnection || !(isHovered || isSelected)) && type === 'end') {
      anchors.push({ x: x - width / 2, y: y, id: `import_${id}`, type: 'import' })
    }
    if (!isConnection && type === 'start') {
      anchors.push({ x: x + width / 2, y: y, id: `export_${id}`, type: 'export' })
    }
    return anchors
  }
}
/**
 * 注册函数节点
 */
class FunctionNodeModel extends VueNodeModel {
  setAttributes() {
    this.width = 240
    const {
      properties: { inputParameters, outputParameters }
    } = this
    const isInputArray = Array.isArray(inputParameters)
    const isOutputArray = Array.isArray(outputParameters)
    const max = isInputArray && isOutputArray ? Math.max(inputParameters.length, outputParameters.length) : 0
    this.height = max * 24 + 24 + 2
    this.sourceRules.push(anchorOnlyAsTarget)
    this.targetRules.push(anchorOnlyAsSource)
    this.text.y = this.y - this.height / 2 + 12
  }

  addInputParameter() {}

  addOutputParameter() {}

  getDefaultAnchor() {
    const {
      x,
      y,
      width,
      height,
      id,
      properties: { inputParameters, outputParameters }
    } = this
    const max = inputParameters && outputParameters ? Math.max(inputParameters.length, outputParameters.length) : 0
    const anchors = [
      { x: x - width / 2, y: y - height / 2 + 12, id: `import_${id}`, type: 'import' },
      {
        x: x + width / 2,
        y: y - height / 2 + 12,
        id: `export_${id}`,
        type: 'export'
      }
    ]
    for (let i = 0; i < max; i++) {
      if (i < inputParameters.length) {
        anchors.push({ x: x - width / 2, y: y + (i + 1) * 24 - height / 2 + 12, id: `input_${i}_${id}`, type: 'input' })
      }
      if (i < outputParameters.length) {
        anchors.push({
          x: x + width / 2,
          y: y + (i + 1) * 24 - height / 2 + 12,
          id: `output_${i}_${id}`,
          type: 'output'
        })
      }
    }
    return anchors
  }
}
/**
 * 注册变量节点
 */
class VariableNodeModel extends VueNodeModel {
  /**
   * 设置节点的属性，包括宽度和高度。
   * 这个方法用于初始化或更新节点的尺寸。
   */
  setAttributes() {
    this.width = 120
    this.height = 48
    this.sourceRules.push(anchorOnlyAsTarget)
    this.targetRules.push(anchorOnlyAsSource)
  }
  getDefaultAnchor() {
    const {
      x,
      y,
      width,
      id,
      isHovered,
      isSelected,
      properties: { isConnection }
    } = this
    const anchors = []
    if (isConnection || !(isHovered || isSelected)) {
      anchors.push({ x: x - width / 2, y: y, id: `input_var_${id}`, edgeAddable: false, type: 'input' })
    }
    if (!isConnection) {
      anchors.push({ x: x + width / 2, y: y, id: `output_var_${id}`, type: 'output' })
    }
    return anchors
  }
}
/**
 * 注册缓存节点
 */
class CacheNodeModel extends VariableNodeModel {}
/**
 * 注册环境节点
 */
class EnvNodeModel extends VariableNodeModel {}
/**
 * 注册文件节点
 */
class FileNodeModel extends VariableNodeModel {}
/**
 * 注册PLC节点
 */
class PLCNodeModel extends VueNodeModel {
  /**
   * 设置节点的属性，包括宽度和高度。
   * 这个方法用于初始化或更新节点的尺寸。
   */
  setAttributes() {
    this.width = 120
    this.height = 48
    // this.sourceRules.push(anchorOnlyAsTarget)
    this.targetRules.push(anchorOnlyAsSource)
  }
  getDefaultAnchor() {
    const {
      x,
      y,
      width,
      id,
      // isHovered,
      // isSelected,
      properties: { isConnection }
    } = this
    const anchors = []
    // if (isConnection || !(isHovered || isSelected)) {
    //   anchors.push({ x: x - width / 2, y: y, id: `input_var_${id}`, edgeAddable: false, type: 'input' })
    // }
    if (!isConnection) {
      anchors.push({ x: x + width / 2, y: y, id: `output_var_${id}`, type: 'output' })
    }
    return anchors
  }
}
/**
 * 注册自定义节点
 * @param {LogicFlow} lf
 */
export const registerCustomNodes = (lf) => {
  const nodeConfigs = [
    { type: 'branchNode', component: BranchNode, model: BranchNodeModel },
    { type: 'cacheNode', component: CacheNode, model: CacheNodeModel },
    { type: 'envNode', component: EnvNode, model: EnvNodeModel },
    { type: 'eventNode', component: EventNode, model: EventNodeModel },
    { type: 'fileNode', component: FileNode, model: FileNodeModel },
    { type: 'functionNode', component: FunctionNode, model: FunctionNodeModel },
    { type: 'judgmentNode', component: JudgmentNode, model: JudgmentNodeModel },
    { type: 'plcNode', component: PLCNode, model: PLCNodeModel },
    { type: 'variableNode', component: VariableNode, model: VariableNodeModel }
  ]

  nodeConfigs.forEach((config) => register(config, lf))
}

export default { EventNode, FunctionNode, VariableNode }
