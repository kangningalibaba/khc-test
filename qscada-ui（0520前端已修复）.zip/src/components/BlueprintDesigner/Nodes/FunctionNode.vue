<template>
  <div class="function-node">
    <div :class="['title', language]"></div>
    <div class="content">
      <div class="input-parameters">
        <div class="parameter" v-for="parameter in inputParameters" :key="parameter.name">
          {{ parameter.label ?? parameter.name }}
        </div>
      </div>
      <div class="output-parameters">
        <div class="parameter" v-for="parameter in outputParameters" :key="parameter.name">
          {{ parameter.label ?? parameter.name }}
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { EventType } from '@logicflow/core'
import { vueNodesMap } from '@logicflow/vue-node-registry'
import { inject, onMounted } from 'vue'
const { proxy } = getCurrentInstance()
const { scada_algsub_type } = proxy.useDict('scada_algsub_type')

const getNode = inject('getNode')
const getGraph = inject('getGraph')
const name = ref('')
const inputParameters = ref([])
const outputParameters = ref([])
const language = ref('')

function typeFormat(algsType) {
  return proxy.selectDictLabel(scada_algsub_type.value, algsType).toLowerCase()
}

onMounted(() => {
  const node = getNode()
  const graph = getGraph()
  name.value = node.text.value
  inputParameters.value = node.properties.inputParameters ?? []
  outputParameters.value = node.properties.outputParameters ?? []
  language.value = typeFormat(node.properties.algsType)
  graph.eventCenter.on(EventType.NODE_PROPERTIES_CHANGE, (eventData) => {
    const keys = eventData.keys
    const content = vueNodesMap[node.type]
    if (content && eventData.id === node.id) {
      const { effect } = content

      // 如果没有定义 effect，则默认更新；如果定义了 effect，则只有在 effect 中的属性发生变化时才更新
      if (!effect || keys.some((key) => effect.includes(key))) {
        console.log('eventData --->>>', eventData)
        inputParameters.value = eventData.properties.inputParameters
        outputParameters.value = eventData.properties.outputParameters
        language.value = typeFormat(node.properties.algsType)
      }
    }
  })
})
</script>

<style lang="scss" scoped>
.function-node {
  width: 240px;
  min-height: 24px;
  background-color: #fff;
  border: 1px solid #333;
  border-radius: 5px;
  box-sizing: border-box;
  overflow: hidden;

  color: #000;
  .title {
    height: 24px;
    background-color: #69f;
    &.java {
      background-color: #6c9;
    }
    &.c {
      background-color: #f93;
    }
  }
  .content {
    display: flex;
    justify-content: space-between;
    padding: 0 10px;
    .parameter {
      line-height: 24px;
      font-size: 12px;
      position: relative;
    }

    .input-parameters .parameter {
      padding-left: 10px;
      &::before {
        content: '';
        border-style: solid;
        border-color: transparent;
        border-width: 6px 0 6px 6px;
        border-left-color: skyblue;
        position: absolute;
        top: calc(50% - 6px);
        left: -2px;
      }
    }

    .output-parameters .parameter {
      padding-right: 10px;
      &::after {
        content: '';
        border-style: solid;
        border-color: transparent;
        border-width: 6px 0 6px 6px;
        border-right-color: skyblue;
        position: absolute;
        top: calc(50% - 6px);
        right: -2px;
      }
    }
  }
}
</style>
