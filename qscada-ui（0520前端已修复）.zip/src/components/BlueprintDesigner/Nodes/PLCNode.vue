<template>
  <div class="plc-node"></div>
</template>

<script setup>
import { EventType } from '@logicflow/core'
import { vueNodesMap } from '@logicflow/vue-node-registry'
import { inject, onMounted } from 'vue'

const getNode = inject('getNode')
const getGraph = inject('getGraph')

onMounted(() => {
  const node = getNode()
  const graph = getGraph()
  graph.eventCenter.on(EventType.NODE_PROPERTIES_CHANGE, (eventData) => {
    const keys = eventData.keys
    const content = vueNodesMap[node.type]
    if (content && eventData.id === node.id) {
      const { effect } = content

      // 如果没有定义 effect，则默认更新；如果定义了 effect，则只有在 effect 中的属性发生变化时才更新
      if (!effect || keys.some((key) => effect.includes(key))) {
        console.log('eventData --->>>', eventData)
      }
    }
  })
})
</script>

<style lang="scss" scoped>
.plc-node {
  height: 48px;
  background-color: #999;
  border-radius: 5px;
}
</style>
