import { ElCollapse, ElCollapseItem } from 'element-plus'
import { createApp, h } from 'vue'

class DndPanelVue {
  static pluginName = 'dndPanelVue'
  constructor(options) {
    this.lf = options.lf
    this.lf.setPatternItems = (groupList) => {
      this.setPatternItems(groupList)
    }
    this.childrens = []
    this.groupList = []
    this.panelEl = null
    this.domContainer = null
    this.app = null
  }

  render(_lf, domContainer) {
    this.destroy()
    if (!this.groupList || this.groupList.length === 0) {
      // 首次render后失败后，后续调用setPatternItems支持渲染
      this.domContainer = domContainer
      return
    }
    this.panelEl = document.createElement('div')
    this.panelEl.className = 'lf-dndpanel'
    this.groupList.forEach((groupItem, index) => {
      const collapse = this.createCollapse(index, groupItem)
      this.childrens.push(collapse)
    })
    domContainer.appendChild(this.panelEl)
    this.domContainer = domContainer
    this.app = createApp({
      render: () =>
        h(
          ElCollapse,
          {
            accordion: true
          },
          {
            default: () => this.childrens
          }
        )
    })
    this.app.mount(this.panelEl)
  }

  destroy() {
    if (this.domContainer && this.panelEl && this.domContainer.contains(this.panelEl)) {
      this.domContainer.removeChild(this.panelEl)
    }
  }

  setPatternItems(groupList) {
    this.groupList = groupList
    // 支持渲染后重新设置拖拽面板
    if (this.domContainer) {
      this.render(this.lf, this.domContainer)
    }
  }

  createDndItem(shapeItem) {
    return h(
      'div',
      {
        class: shapeItem.className ? `lf-dnd-item ${shapeItem.className}` : `lf-dnd-item`,
        onmousedown: () => {
          if (shapeItem.type) {
            this.lf.dnd.startDrag({
              type: shapeItem.type,
              properties: shapeItem.properties,
              text: shapeItem.text
            })
          }
          if (shapeItem.callback) {
            shapeItem.callback(this.lf, this.domContainer)
          }
        },
        ondblclick: (e) => {
          this.lf.graphModel.eventCenter.emit('dnd:panel-dbclick', {
            e,
            data: shapeItem
          })
        },
        onclick: (e) => {
          this.lf.graphModel.eventCenter.emit('dnd:panel-click', {
            e,
            data: shapeItem
          })
        },
        oncontextmenu: (e) => {
          this.lf.graphModel.eventCenter.emit('dnd:panel-contextmenu', {
            e,
            data: shapeItem
          })
        }
      },
      [
        h('div', {
          class: 'lf-dnd-shape',
          style: {
            'background-image': shapeItem.icon ? `url(${shapeItem.icon})` : ''
          }
        }),
        h('div', {
          class: 'lf-dnd-text',
          innerText: shapeItem.label
        })
      ]
    )
  }

  createCollapse(index, groupItem) {
    const collapse = h(
      ElCollapseItem,
      {
        name: index,
        title: groupItem.group
      },
      {
        default: () => groupItem.items?.map((shapeItem) => this.createDndItem(shapeItem))
      }
    )
    return collapse
  }
}

export { DndPanelVue }
