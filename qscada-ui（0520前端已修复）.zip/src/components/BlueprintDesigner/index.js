import BlueprintDesigner from './BlueprintDesigner.vue'

export default BlueprintDesigner
