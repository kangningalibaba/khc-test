<script setup>
import { useElementBounding } from '@vueuse/core'
import { defineEmits, defineProps, onMounted, ref, useTemplateRef } from 'vue'
import { zIndex as currentZIndex } from './'

const { initialPosition, restrictToBounds, appendTo, zIndex } = defineProps({
  title: {
    type: String,
    default: '弹窗标题'
  },
  initialPosition: {
    type: Object,
    default: () => ({ top: 0, left: 0 })
  },
  restrictToBounds: {
    type: Boolean,
    default: true
  },
  appendTo: {
    type: Node,
    default: () => document.body
  },
  zIndex: {
    type: Number,
    required: true
  }
})

const emit = defineEmits(['close'])
const dialogRef = useTemplateRef('dialogRef')
const { width: dialogWidth, height: dialogHeight } = useElementBounding(dialogRef)
const { width: viewportWidth, height: viewportHeight } = useElementBounding(appendTo)

const position = ref({ ...initialPosition })
const dragging = ref(false)
const offset = ref({ x: 0, y: 0 })
const newZIndex = ref(zIndex)

const startDrag = (event) => {
  dragging.value = true
  offset.value = {
    x: event.clientX - position.value.left,
    y: event.clientY - position.value.top
  }
  document.addEventListener('mousemove', onDrag)
  document.addEventListener('mouseup', stopDrag)
}

const onDrag = (event) => {
  if (!dragging.value) return
  let newTop = event.clientY - offset.value.y
  let newLeft = event.clientX - offset.value.x

  if (restrictToBounds) {
    newTop = Math.max(0, Math.min(newTop, viewportHeight.value - dialogHeight.value))
    newLeft = Math.max(0, Math.min(newLeft, viewportWidth.value - dialogWidth.value))
  }

  position.value = { top: newTop, left: newLeft }
}

const stopDrag = () => {
  dragging.value = false
  document.removeEventListener('mousemove', onDrag)
  document.removeEventListener('mouseup', stopDrag)
}

const bringToFront = () => {
  newZIndex.value = ++currentZIndex.value
}

const close = () => {
  emit('close')
}

onMounted(() => {
  if (initialPosition.top === 0 && initialPosition.left === 0) {
    position.value = {
      top: viewportHeight.value / 2 - dialogHeight.value / 2,
      left: viewportWidth.value / 2 - dialogWidth.value / 2
    }
  } else {
    position.value = {
      top: Math.max(0, Math.min(initialPosition.top, viewportHeight.value - dialogHeight.value)),
      left: Math.max(0, Math.min(initialPosition.left, viewportWidth.value - dialogWidth.value))
    }
  }
})
</script>

<template>
  <div
    ref="dialogRef"
    class="dialog-container"
    :style="{ zIndex: newZIndex, top: position.top + 'px', left: position.left + 'px' }"
    @mousedown="bringToFront">
    <div class="dialog-header" @mousedown="startDrag">
      {{ title }}
      <div class="btnClose" @click="close"></div>
    </div>
    <div class="dialog-body">
      <!-- 新增：动态渲染内容 -->
      <slot></slot>
    </div>
  </div>
</template>

<style lang="scss" scoped>
.dialog-container {
  position: absolute;
  min-width: 200px;
  min-height: 150px;
  background-color: white;
  border: 1px solid #ccc;
  border-radius: 5px;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
  display: flex;
  flex-direction: column;
  color: #333;
  overflow-x: hidden;

  .dialog-header {
    --header-font-size: 16px;
    --header-color: #333;

    padding: 8px 16px;
    background-color: #f0f0f0;
    color: var(--header-color);
    text-shadow: 0 0 2px rgba(0, 0, 0, 0.25);
    cursor: move;
    font-size: var(--header-font-size);
    font-weight: bold;
    display: flex; /* 添加弹性布局 */
    justify-content: space-between; /* 标题与关闭按钮分开 */
    align-items: center; /* 垂直居中对齐 */
    user-select: none;
    border-top-left-radius: 5px;
    border-top-right-radius: 5px;

    .btnClose {
      --btn-x-size: 3px;

      position: relative;
      width: var(--header-font-size);
      height: var(--header-font-size);
      cursor: pointer;

      /* X线条旋转后会有偏移，使用 flex 进行居中对齐修正 */
      display: inline-flex;
      justify-content: center;
      align-items: center;

      &::before,
      &::after {
        content: '';
        position: absolute;
        width: var(--btn-x-size);
        height: var(--header-font-size);
        background-color: var(--header-color);
        border-radius: calc(var(--btn-x-size) / 2);
      }

      &::before {
        transform: rotate(45deg);
      }

      &::after {
        transform: rotate(-45deg);
      }
    }
  }

  .dialog-body {
    flex: 1;
    overflow-y: auto;
  }
}
</style>
