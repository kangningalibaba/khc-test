import { createVNode, reactive, ref, render } from 'vue'
import FreeDialog from './FreeDialog.vue'

export const zIndex = ref(5000)
export const dialogMap = reactive(new Map())

function generateId() {
  return Math.random().toString(36).substring(2)
}

export const useFreeDialog = () => {
  const open = (options) => {
    const { id = generateId(), appendTo = document.body, content = null, ...other } = options

    if (dialogMap.has(id)) {
      return dialogMap.get(id)
    }

    const container = document.createElement('div')

    const vnode = createVNode(
      FreeDialog,
      {
        ...other,
        zIndex: ++zIndex.value,
        appendTo,
        onClose: () => {
          render(null, container)
          appendTo.removeChild(container)
          dialogMap.delete(id)
        }
      },
      { default: () => content }
    )

    appendTo.appendChild(container)
    render(vnode, container)

    dialogMap.set(id, vnode.component)

    return vnode
  }

  const close = (id) => {
    if (!id) {
      dialogMap.forEach((instance) => {
        instance.emit('close')
      })
    } else if (dialogMap.has(id)) {
      dialogMap.get(id).emit('close')
    }
  }

  const has = (id) => {
    return dialogMap.has(id)
  }

  return {
    open,
    close,
    has
  }
}
