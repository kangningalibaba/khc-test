<template>
  <div class="monaco" ref="monacoRef"></div>
</template>

<script setup>
import * as monaco from 'monaco-editor'
import jsonWorker from 'monaco-editor/esm/vs/language/json/json.worker?worker'
import cssWorker from 'monaco-editor/esm/vs/language/css/css.worker?worker'
import htmlWorker from 'monaco-editor/esm/vs/language/html/html.worker?worker'
import tsWorker from 'monaco-editor/esm/vs/language/typescript/ts.worker?worker'
import EditorWorker from 'monaco-editor/esm/vs/editor/editor.worker?worker'
import { onBeforeUnmount, onMounted, ref, watch } from 'vue'

const code = defineModel()
const props = defineProps({
  width: {
    type: [String, Number],
    default: '100%'
  },
  height: {
    type: [String, Number],
    default: '100%'
  },
  language: {
    type: String,
    default: 'xml'
  },
  theme: {
    type: String,
    default: 'vs-dark'
  },
  options: {
    type: Object,
    default: () => {
      return {
        automaticLayout: true,
        domReadOnly: true,
        foldingStrategy: 'indentation',
        fontSize: 16,
        lineHeight: 24,
        minimap: {
          enabled: true
        },
        overviewRulerBorder: false,
        readOnly: false,
        renderLineHighlight: 'all',
        scrollBeyondLastLine: false,
        selectOnLineNumbers: true,
        tabSize: 2
      }
    }
  }
})
const emit = defineEmits(['mounted'])

const monacoRef = ref(null)
let editor = null

// 定义 MonacoEnvironment.getWorkerUrl
self.MonacoEnvironment = {
  getWorker(_, label) {
    if (label === 'json') {
      return new jsonWorker()
    }
    if (['css', 'scss', 'less'].includes(label)) {
      return new cssWorker()
    }
    if (['html', 'handlebars', 'razor'].includes(label)) {
      return new htmlWorker()
    }
    if (['typescript', 'javascript'].includes(label)) {
      return new tsWorker()
    }
    return new EditorWorker()
  }
}
const init = () => {
  monaco.languages.typescript.javascriptDefaults.setDiagnosticsOptions({
    noSemanticValidation: true,
    noSyntaxValidation: false
  })
  monaco.languages.typescript.javascriptDefaults.setCompilerOptions({
    target: monaco.languages.typescript.ScriptTarget.ESNext,
    allowNonTsExtensions: true
  })
  editor = monaco.editor.create(monacoRef.value, {
    value: code.value,
    language: props.language,
    theme: props.theme,
    ...props.options
  })
  editor.onDidChangeModelContent(() => {
    code.value = editor.getValue()
  })
  emit('mounted', editor)
}

const assignmentCode = (newValue) => {
  if (editor) {
    const value = editor.getValue()
    if (value !== newValue.value) {
      editor.setValue(newValue.value)
    }
  }
}

watch(() => code, assignmentCode, { immediate: true, deep: true })
watch(
  () => props.language,
  (newValue) => {
    monaco.editor.setModelLanguage(editor.getModel(), newValue)
  }
)
watch(
  () => props.options,
  (newValue) => {
    editor.updateOptions(newValue)
  },
  { deep: true }
)

onMounted(() => {
  init()
})

onBeforeUnmount(() => {
  if (editor) {
    editor.dispose()
    editor = null
  }
})
</script>

<style scoped lang="scss">
.monaco {
  width: v-bind(width);
  height: v-bind(height);
  &::v-deep(.highlight-line) {
    .highlight-line {
      background-color: rgba(140, 143, 255, 0.7); /* 设置高亮背景颜色 */
    }
  }
}
</style>
