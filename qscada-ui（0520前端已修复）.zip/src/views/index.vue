<template>
  <div class="app-container home">
    <el-row :gutter="20">
      <el-col :sm="24" :lg="24">欢迎使用 CITIC算法平台！</el-col>
    </el-row>
  </div>
</template>

<script setup name="Index"></script>

<style scoped lang="scss"></style>
