<template>
  <div class="app-container">
    <el-form :model="queryParams" ref="queryForm" :inline="true" v-show="showSearch" label-width="68px">
      <el-form-item label="名称" prop="name">
        <el-input
          v-model="queryParams.name"
          placeholder="请输入名称"
          clearable
          style="width: 200px"
          @keyup.enter="handleQuery" />
      </el-form-item>

      <el-form-item>
        <el-button type="primary" icon="Search" @click="handleQuery">搜索</el-button>
        <el-button icon="Refresh" @click="resetQuery">重置</el-button>
      </el-form-item>
    </el-form>

    <el-table v-loading="loading" :data="tableData">
      <el-table-column label="序号" align="center" type="index" width="60" />
      <el-table-column label="名称" align="center" prop="name" width="240" />

      <el-table-column label="缩略图" align="center" prop="image" width="160">
        <template #default="scope">
          <image-preview :src="scope.row.image" :width="50" :height="50" />
        </template>
      </el-table-column>
      <el-table-column label="备注" align="center" prop="remark" />
      <el-table-column label="操作" align="center" class-name="small-padding fixed-width" width="120">
        <template #default="scope">
          <el-button
            link
            type="primary"
            icon="View"
            @click="handelPrev(scope.row)"
            v-hasPermi="['scada:scene:list', 'scada:scene:run:query']"
            >查看</el-button
          >
        </template>
      </el-table-column>
    </el-table>

    <pagination
      v-show="total > 0"
      :total="total"
      v-model:page="page.pageNum"
      v-model:limit="page.pageSize"
      @pagination="getList" />
  </div>
</template>

<script setup name="Scene">
import { listScene } from '@/api/scada/scene'
import { listState } from '@/api/scada/state'
import { useTable } from '@/hooks'

const showSearch = ref(true) // 显示搜索条件
const router = useRouter()

const states = ref([])

const {
  tableData,
  loading,

  total,
  queryParams,
  page,
  getList,
  resetQuery,
  handleQuery
} = useTable(listScene, { params: {} })

onMounted(() => {
  getList()
  listState({ rtable: 'common' }).then((res) => {
    states.value = res.rows
  })
})

function handelPrev(row) {
  const url = router.resolve({ name: 'DeviceConfigurationPreview', query: { id: row.id } })
  window.open(url.href, '_blank')
  // designerPreview({ visible: true, id: row.id })
}
</script>
