<template>
  <el-scrollbar wrap-class="designer-preview-wrap" view-class="designer-preview-view">
    <DesignerPreview :data="sceneData" :style="{ transform: `scale(${scale})` }" />
  </el-scrollbar>
</template>

<script setup name="ScenePreview">
import { getScene } from '@/api/scada/scene'
import DesignerPreview from '@/components/DeviceConfigurator/Preview.vue'
import { defaultData } from '@/store/modules/deviceConfigurator.js'
import { onMounted, onUnmounted, ref } from 'vue'

const route = useRoute()
const sceneData = ref(defaultData)
const scale = ref(1)

function handleWheel(event) {
  if (event.deltaY > 0) {
    // 缩小
    scale.value = Math.max(scale.value - 0.1, 1)
  } else {
    // 放大
    scale.value = Math.min(scale.value + 0.1, 5)
  }
}

const backgroundColor = computed(() => {
  const color = sceneData.value.container.style.backgroundColor
  return color ? color : 'transparent'
})

watch(
  () => route.query.id,
  () => {
    init()
  }
)
function init() {
  const { id } = route.query
  if (id) {
    getScene(id).then((res) => {
      const { data } = res.data
      sceneData.value = JSON.parse(data, function (key, value) {
        if (typeof value === 'string' && value.startsWith('function')) {
          return eval(`(${value})`)
        }
        return value
      })
    })
  }
}

onMounted(() => {
  init()
  window.addEventListener('wheel', handleWheel)
})

onUnmounted(() => {
  window.removeEventListener('wheel', handleWheel)
})
</script>

<style lang="scss">
.designer-preview-wrap {
  display: flex;
  align-items: center;
  background-color: v-bind(backgroundColor);
  .designer-preview-view {
    display: flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
    margin: auto;
    flex-direction: column;
  }
}
</style>
