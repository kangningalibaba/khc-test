<script setup>
import { addScene, getScene, updateScene } from '@/api/scada/scene'
import { listState } from '@/api/scada/state'
import { computed, onMounted, ref } from 'vue'

const { proxy } = getCurrentInstance()

const { id, visible, onSubmit, data, preview } = defineProps({
  visible: { type: Boolean, default: false },
  title: { type: String },
  id: { type: [String, Number] },
  data: { type: Object, default: () => {} },
  preview: { type: String, default: '' },
  onSubmit: { type: Function, default: () => {} }
})

const emits = defineEmits(['update:visible', 'close'])

const dialogVisible = computed({
  get() {
    return visible
  },
  set(val) {
    emits('update:visible', val)
    if (!val) {
      emits('close')
    }
  }
})
const states = ref([])
const loading = ref(false)
const formRef = ref(null)
const form = reactive({
  name: null,
  data: JSON.stringify(data, function (key, val) {
    if (typeof val === 'function') {
      return val + ''
    }
    return val
  }),
  style: ' ',
  image: preview,
  remark: null,
  state: 0,
  createTime: null,
  createBy: null,
  updateBy: null,
  updateTime: null
})
const rules = reactive({
  name: [{ required: true, message: '名称不能为空', trigger: 'blur' }],
  data: [{ required: true, message: '画面数据不能为空', trigger: 'blur' }],
  style: [{ required: true, message: '画面样式不能为空', trigger: 'blur' }]
})

function cancel() {
  dialogVisible.value = false
  formRef.value?.resetFields?.()
}

function submitForm() {
  loading.value = false
  formRef.value.validate((valid, fields) => {
    if (valid) {
      if (id != null) {
        updateScene({ id, ...form }).then(() => {
          proxy.$modal.msgSuccess('修改成功')
          onSubmit()
          cancel()
        })
      } else {
        addScene(this.form).then(() => {
          proxy.$modal.msgSuccess('新增成功')
          onSubmit()
          cancel()
        })
      }
    } else {
      console.log(fields)
    }
  })
}

function getSceneData() {
  formRef.value?.resetFields?.()
  getScene(id).then((response) => {
    const data = response.data
    for (let key of Object.keys(form)) {
      if (!['data', 'image'].includes(key)) {
        form[key] = data[key]
      }
    }
  })
}

function getStateList() {
  listState({ rtable: 'common' }).then((response) => {
    states.value = response.rows
  })
}

onMounted(() => {
  getStateList()
  if (id) {
    getSceneData()
  }
})
</script>

<template>
  <!-- 添加或修改对话框 -->
  <el-dialog :title="title" v-model="dialogVisible" width="800px" append-to-body>
    <el-form ref="formRef" :model="form" :rules="rules" label-width="80px">
      <el-form-item label="名称" prop="name">
        <el-input v-model="form.name" placeholder="请输入名称" />
      </el-form-item>
      <el-form-item v-show="false" label="画面数据" prop="data">
        <el-input v-model="form.data" type="textarea" placeholder="请输入内容" />
      </el-form-item>
      <el-form-item v-show="false" label="画面样式" prop="style">
        <el-input v-model="form.style" type="textarea" placeholder="请输入内容" />
      </el-form-item>
      <!-- <el-form-item label="缩略图">
        <image-upload v-model="form.image" />
      </el-form-item> -->
      <el-form-item label="备注" prop="remark">
        <el-input type="textarea" :rows="5" v-model="form.remark" placeholder="请输入备注" />
      </el-form-item>
      <el-form-item v-show="false" label="状态" prop="state">
        <el-select v-model="form.state" placeholder="请选择状态" clearable size="small">
          <el-option v-for="(v, k) in states" :key="k" :label="v.name" :value="v.id" />
        </el-select>
      </el-form-item>
    </el-form>
    <template v-slot:footer>
      <div class="dialog-footer">
        <el-button type="primary" @click="submitForm(formRef)">确 定</el-button>
        <el-button @click="cancel">取 消</el-button>
      </div>
    </template>
  </el-dialog>
</template>
