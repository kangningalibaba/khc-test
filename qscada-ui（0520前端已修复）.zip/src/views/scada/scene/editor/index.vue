<script setup>
import { getScene } from '@/api/scada/scene'
import DeviceConfigurator from '@/components/DeviceConfigurator'
import { useCommandDialog } from '@/hooks'
import { defaultData } from '@/store/modules/deviceConfigurator'
import { useCloned } from '@vueuse/core'
import SaveScene from './SaveScene.vue'

const route = useRoute()
const router = useRouter()
const saveScene = useCommandDialog(SaveScene)
const { cloned: data } = useCloned(defaultData)
function getData() {
  if (route.query.id) {
    getScene(route.query.id).then((response) => {
      data.value = JSON.parse(response.data.data, function (key, value) {
        if (typeof value === 'string' && value.startsWith('function')) {
          return eval(`(${value})`)
        }
        return value
      })
    })
  }
}
function handleSave(sceneData, preview) {
  let options = {
    data: sceneData,
    preview,
    onSubmit: () => {
      router.push({ path: '/device/scene' })
    }
  }
  if (route.query.id) {
    options.id = route.query.id
  }
  saveScene(options)
}

onBeforeMount(() => {
  getData()
})
</script>

<template>
  <device-configurator :on-save="handleSave" :data="data" />
</template>

<style lang="scss">
.designer {
  .el-aside {
    padding: 0;
    margin-bottom: 0;
    background: transparent;
  }
}
</style>
