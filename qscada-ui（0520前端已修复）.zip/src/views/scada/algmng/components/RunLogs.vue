<script setup>
import { getAlgmngLog, getAlgmngLogs, getAlgmngStartStopLogs, getHistoryAlgsubmng } from '@/api/scada/algmng'
import { useTable } from '@/hooks'
import { computed, onMounted, ref } from 'vue'

const { algId, visible, runVersion } = defineProps({
  title: { type: String },
  visible: { type: Boolean, default: false },
  algId: { type: Number, required: true },
  runVersion: { type: String, default: '' }
})
const { proxy } = getCurrentInstance()
const { scada_alg_execution_status } = proxy.useDict('scada_alg_execution_status')

const emits = defineEmits(['update:visible', 'close'])

const dialogVisible = computed({
  get() {
    return visible
  },
  set(val) {
    emits('update:visible', val)
    if (!val) {
      emits('close')
    }
  }
})

const {
  tableData: algmngLogs,
  loading: algmngLogLoading,
  total,
  queryParams: algmngLogsQueryParams,
  page,
  getList: getLogsList
} = useTable(getAlgmngLogs, {
  uniqueId: 'logId',
  params: {
    algId: null,
    startLogId: null
  }
})
const operationLogs = ref([])

const runLogs = ref([])
const versions = ref([])
const version = ref(runVersion)
const operationLogLoading = ref(false)

const runLogLoading = ref(false)
const operationLogsDone = ref(false)
const disabled = computed(() => operationLogLoading.value || operationLogsDone.value)
function init() {
  getHistoryAlgsubmng(algId).then((res) => {
    res.data.forEach((item) => {
      versions.value.push({
        label: item.algVersion,
        value: item.algVersion
      })
    })
    getOptLogs()
  })
}

function getOptLogs() {
  operationLogLoading.value = true
  getAlgmngStartStopLogs({ algId, algVersion: version.value, pageNum: 2 })
    .then((res) => {
      operationLogs.value = res.rows

      if (operationLogs.value.length > 0) {
        handleLogClick(operationLogs.value[0])
      }
      operationLogsDone.value = true
    })
    .finally(() => {
      operationLogLoading.value = false
    })
}

const selectedLogId = ref(null)

function handleLogClick(item) {
  selectedLogId.value = item.logId
  getLogs(item) // 原有的点击处理逻辑
}

async function getLogs(row) {
  try {
    algmngLogLoading.value = true
    algmngLogsQueryParams.value.algId = row.algId
    algmngLogsQueryParams.value.startLogId = row.logId

    await getLogsList()
    runLogs.value = []
    // if (algmngLogs.value.length > 0) {
    //   proxy.$refs.algmngLogsRef.setCurrentRow(algmngLogs.value[0]);
    // }
  } catch (error) {
    console.error('Failed to fetch logs:', error)
  } finally {
    algmngLogLoading.value = false
  }
}

function getLog(row) {
  runLogLoading.value = true
  getAlgmngLog(row.logId)
    .then((res) => {
      runLogs.value = res.data
    })
    .finally(() => {
      runLogLoading.value = false
    })
}

onMounted(() => {
  init()
})
</script>

<template>
  <el-dialog class="logs-dialog" v-model="dialogVisible" width="1200px" append-to-body>
    <template #header>
      <el-space>
        <el-text class="title" size="large" type="primary">{{ title }}</el-text>
        <el-select
          v-model="version"
          placeholder="请选择算法版本"
          style="width: 160px"
          v-if="versions.length > 0"
          @change="getOptLogs">
          <el-option v-for="item in versions" :key="item.value" :label="item.label" :value="item.value" />
        </el-select>
      </el-space>
    </template>
    <div class="logs-container">
      <div class="aside">
        <ul
          class="start-stop-logs"
          ref="startStopLogsRef"
          v-infinite-scroll="getOptLogs"
          :infinite-scroll-disabled="disabled">
          <li
            v-for="item in operationLogs"
            :key="item.logId"
            @click="handleLogClick(item)"
            :class="{ selected: selectedLogId === item.logId }">
            <div><strong>启动时间：</strong>{{ item.startTime }}</div>
            <div><strong>停止时间：</strong>{{ item.stopTime }}</div>
          </li>
        </ul>
      </div>
      <div class="main">
        <div class="logs">
          <el-table
            height="300px"
            :data="algmngLogs"
            @row-click="getLog"
            v-loading="algmngLogLoading"
            ref="algmngLogsRef"
            highlight-current-row>
            <el-table-column prop="exeNum" label="轮次" align="center" min-width="120">
              <template #default="scope"> 第{{ scope.row.exeNum }}轮次 </template>
            </el-table-column>
            <el-table-column prop="createTime" label="时间" align="center" min-width="180" />
            <el-table-column prop="costTime" label="消耗时间(ms)" align="center" min-width="150" />
            <el-table-column prop="exeStatus" label="执行状态" align="center" min-width="120">
              <template #default="scope">
                <dict-tag :options="scada_alg_execution_status" :value="scope.row.exeStatus" />
              </template>
            </el-table-column>
          </el-table>
          <pagination
            v-show="total > 0"
            :total="total"
            v-model:page="page.pageNum"
            v-model:limit="page.pageSize"
            @pagination="getLogsList" />
        </div>
        <div class="detail">
          <el-timeline>
            <el-timeline-item v-for="log in runLogs" :key="log.detailId" :timestamp="log.createTime">
              {{ log.logMsg }}
            </el-timeline-item>
          </el-timeline>
        </div>
      </div>
    </div>
  </el-dialog>
</template>

<style lang="scss" scoped>
.logs-dialog {
  .title {
    font-weight: bolder;
  }
}
.logs-container {
  display: flex;
  background-color: #eef1f6;
  .aside {
    padding: 10px;
    width: 360px;
  }
  .main {
    flex: 1;
    display: flex;
    flex-direction: column;
    padding-top: 10px;
    padding-bottom: 10px;
    padding-right: 10px;
    .logs {
      padding-bottom: 20px;
    }
    .detail {
      height: 480px;
      overflow-y: auto;
      background-color: var(--el-bg-color);
      padding-top: 20px;
    }
  }
}

.start-stop-logs {
  margin: 0;
  padding: 0;
  height: 100%;
  overflow-y: auto;
  list-style-type: none;
  background-color: var(--el-bg-color);

  li {
    cursor: pointer;
    padding: 10px;

    &:not(:first-child) {
      margin-top: 10px;
    }

    &:hover {
      background-color: #d5dfee;
    }
    > *:not(:first-child) {
      margin-top: 5px;
    }
  }
}
.start-stop-logs li.selected {
  background-color: #f5f7fa;
  border-left: 3px solid #409eff;
}
</style>
