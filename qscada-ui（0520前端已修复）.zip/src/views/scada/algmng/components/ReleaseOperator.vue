<script setup>
import { changePubStatus, getNextVersion, isRepeatVersion } from '@/api/scada/algmng'
import { ElMessage, ElMessageBox } from 'element-plus'
import { computed, onMounted, ref } from 'vue'
const { algId, visible, onSubmit } = defineProps({
  visible: { type: Boolean, default: false },
  title: { type: String },
  algId: { type: Number, required: true },
  onSubmit: { type: Function, default: () => {} }
})

const emits = defineEmits(['update:visible', 'close'])

const dialogVisible = computed({
  get() {
    return visible
  },
  set(val) {
    emits('update:visible', val)
    if (!val) {
      emits('close')
    }
  }
})
const loading = ref(false)
const formRef = ref(null)
const form = reactive({ algVersion: '', remark: '' })

function cancel() {
  dialogVisible.value = false
  formRef.value.resetFields?.()
}

function init() {
  getNextVersion(algId).then((response) => {
    const { version: algVersion, remark } = response.data
    form.algVersion = algVersion
    form.remark = remark
  })
}

onMounted(() => {
  init()
})

function release() {
  changePubStatus(algId, form)
    .then(() => {
      ElMessage({ message: '发布成功', type: 'success' })
      onSubmit()
      cancel()
    })
    .finally(() => {
      loading.value = false
    })
}

function submitForm() {
  loading.value = true
  isRepeatVersion(algId, form.algVersion).then((response) => {
    console.log(response)
    const { data } = response
    if (data) {
      ElMessageBox.confirm('发现相同版本号，是否覆盖？', '提示', { type: 'warning' })
        .then(() => {
          release()
        })
        .catch(() => {
          loading.value = false
        })
    } else {
      release()
    }
  })
}
</script>

<template>
  <el-dialog :title="title" v-model="dialogVisible" width="600px" append-to-body>
    <el-form ref="formRef" :model="form" label-width="auto">
      <el-form-item label="版本号" prop="algVersion">
        <el-input v-model="form.algVersion" placeholder="" />
      </el-form-item>
      <el-form-item label="备注" prop="remark">
        <el-input v-model="form.remark" type="textarea" placeholder="请输入内容" />
      </el-form-item>
    </el-form>
    <template #footer>
      <div class="dialog-footer">
        <el-button type="primary" @click="submitForm" :loading="loading">发 布</el-button>
        <el-button @click="cancel">取 消</el-button>
      </div>
    </template>
  </el-dialog>
</template>
