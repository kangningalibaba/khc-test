<template>
  <div class="app-container">
    <el-form :model="queryParams" ref="queryForm" :inline="true" v-show="showSearch" label-width="68px">
      <el-form-item label="算法名称" prop="algName">
        <el-input
          v-model="queryParams.algName"
          placeholder="请输入算法名称"
          clearable
          style="width: 200px"
          @keyup.enter="handleQuery" />
      </el-form-item>

      <el-form-item label="算法编号" prop="algCode">
        <el-input
          v-model="queryParams.algCode"
          placeholder="请输入算法编号"
          clearable
          style="width: 200px"
          @keyup.enter="handleQuery" />
      </el-form-item>

      <el-form-item label="发布状态" prop="publishStatus">
        <el-select v-model="queryParams.publishStatus" placeholder="请选择发布状态" clearable style="width: 200px">
          <el-option
            v-for="dict in scada_alg_publish_status"
            :key="dict.value"
            :label="dict.label"
            :value="dict.value" />
        </el-select>
      </el-form-item>
      <el-form-item label="启用状态" prop="startStatus">
        <el-select v-model="queryParams.startStatus" placeholder="请选择启用状态" clearable style="width: 200px">
          <el-option v-for="dict in scada_alg_start_status" :key="dict.value" :label="dict.label" :value="dict.value" />
        </el-select>
      </el-form-item>
      <el-form-item label="检测状态" prop="testStatus">
        <el-select v-model="queryParams.testStatus" placeholder="请选择检测状态" clearable style="width: 200px">
          <el-option v-for="dict in scada_test_status" :key="dict.value" :label="dict.label" :value="dict.value" />
        </el-select>
      </el-form-item>
      <!-- <el-form-item label="显示顺序" prop="orderNum">
        <el-input
          v-model="queryParams.orderNum"
          placeholder="请输入显示顺序"
          clearable
          style="width: 200px"
          @keyup.enter="handleQuery" />
      </el-form-item> -->

      <el-form-item>
        <el-button type="primary" icon="Search" @click="handleQuery">搜索</el-button>
        <el-button icon="Refresh" @click="resetQuery">重置</el-button>
      </el-form-item>
    </el-form>

    <el-row :gutter="10" class="mb8">
      <el-col :span="1.5">
        <el-button type="primary" plain icon="Plus" @click="handleAdd" v-hasPermi="['scada:algmng:add']"
          >新增</el-button
        >
      </el-col>
      <!-- <el-col :span="1.5">
        <el-button
          type="success"
          plain
          icon="Edit"
          :disabled="!isSingle"
          @click="handleUpdate"
          v-hasPermi="['scada:algmng:edit']"
          >修改</el-button
        >
      </el-col>
      <el-col :span="1.5">
        <el-button
          type="danger"
          plain
          icon="Delete"
          :disabled="hasMultiple"
          @click="handleDelete"
          v-hasPermi="['scada:algmng:remove']"
          >删除</el-button
        >
      </el-col>
      <el-col :span="1.5">
        <el-button type="warning" plain icon="Download" @click="handleExport" v-hasPermi="['scada:algmng:export']"
          >导出</el-button
        >
      </el-col> -->
      <right-toolbar v-model:showSearch="showSearch" @queryTable="getList"></right-toolbar>
    </el-row>

    <el-table v-loading="loading" :data="tableData" @selection-change="handleSelectionChange">
      <!-- <el-table-column type="selection" width="55" align="center" /> -->
      <el-table-column label="序号" align="center" type="index" width="60" />
      <!-- <el-table-column label="算法id" align="center" prop="algId" /> -->
      <el-table-column label="算法名称" align="center" prop="algName" min-width="120" />
      <el-table-column label="算法编号" align="center" prop="algCode" min-width="100" />
      <!-- <el-table-column label="算法json" align="center" prop="algJson" /> -->
      <el-table-column label="执行频率" align="center" prop="exeFrequency" min-width="100" />
      <el-table-column label="版本号" align="center" prop="algVersion" min-width="100" />

      <el-table-column label="发布状态" align="center" prop="publishStatus">
        <template #default="scope">
          <dict-tag :options="scada_alg_publish_status" :value="scope.row.publishStatus" />
        </template>
      </el-table-column>
      <el-table-column label="启用状态" align="center" prop="startStatus">
        <template #default="scope">
          <dict-tag :options="scada_alg_start_status" :value="scope.row.startStatus" />
        </template>
      </el-table-column>
      <el-table-column label="检测状态" align="center" prop="testStatus">
        <template #default="scope">
          <dict-tag :options="scada_test_status" :value="scope.row.testStatus" />
        </template>
      </el-table-column>
      <!-- <el-table-column label="显示顺序" align="center" prop="orderNum" width="80" /> -->
      <el-table-column label="备注" align="center" prop="remark" min-width="120" show-overflow-tooltip />
      <el-table-column label="操作" align="center" class-name="small-padding fixed-width" min-width="150">
        <template #default="scope">
          <el-button link type="primary" icon="Edit" @click="handleUpdate(scope.row)" v-hasPermi="['scada:algmng:edit']"
            >修改</el-button
          >
          <el-button
            link
            type="primary"
            icon="Delete"
            @click="handleDelete(scope.row)"
            v-hasPermi="['scada:algmng:remove']"
            >删除</el-button
          >
          <el-button
            link
            type="primary"
            icon="Promotion"
            @click="handleRelease(scope.row)"
            v-hasPermi="['scada:algmng:release']"
            >发布</el-button
          >
        </template>
      </el-table-column>
    </el-table>

    <pagination
      v-show="total > 0"
      :total="total"
      v-model:page="page.pageNum"
      v-model:limit="page.pageSize"
      @pagination="getList" />
  </div>
</template>

<script setup name="Algmng">
import { delAlgmng, listAlgmng } from '@/api/scada/algmng'
import { useCommandDialog, useTable } from '@/hooks'
import ReleaseOperator from './components/ReleaseOperator.vue'

const router = useRouter()
const { proxy } = getCurrentInstance()
const { scada_alg_start_status, scada_alg_publish_status, scada_test_status } = proxy.useDict(
  'scada_alg_start_status',
  'scada_alg_publish_status',
  'scada_test_status'
)
const showSearch = ref(true) // 显示搜索条件
const {
  tableData,
  selectedIds,
  loading,
  total,
  queryParams,
  page,
  getList,
  resetQuery,
  handleQuery,
  handleSelectionChange
} = useTable(listAlgmng, { uniqueId: 'algsId', params: {} })
const releaseOperator = useCommandDialog(ReleaseOperator)

onMounted(() => {
  getList()
})
/** 新增按钮操作 */
function handleAdd() {
  router.push({ name: 'Blueprint' })
}
/** 修改按钮操作 */
function handleUpdate(row) {
  router.push({ name: 'Blueprint', query: { id: row.algId } })
}
/** 删除按钮操作 */
function handleDelete(row) {
  const algIds = row.algId || selectedIds.value
  proxy.$modal
    .confirm('是否确认删除算法名称为"' + row.algName + '"的数据项？')
    .then(function () {
      return delAlgmng(algIds)
    })
    .then(() => {
      getList()
      proxy.$modal.msgSuccess('删除成功')
    })
    .catch(() => {})
}
// /** 导出按钮操作 */
// function handleExport() {
//   proxy.download(
//     'scada/algmng/export',
//     {
//       ...queryParams
//     },
//     `algmng_${new Date().getTime()}.xlsx`
//   )
// }
/** 发布按钮操作 */
function handleRelease(row) {
  releaseOperator({
    title: '发布算法',
    algId: row.algId,
    onSubmit: () => {
      getList()
    }
  })
}
</script>
