<template>
  <div class="app-container">
    <el-form :model="queryParams" ref="queryForm" :inline="true" v-show="showSearch" label-width="68px">
      <el-form-item label="算法名称" prop="algName">
        <el-input
          v-model="queryParams.algName"
          placeholder="请输入算法名称"
          clearable
          style="width: 200px"
          @keyup.enter="handleQuery" />
      </el-form-item>

      <!-- <el-form-item label="算法编号" prop="algCode">
        <el-input
          v-model="queryParams.algCode"
          placeholder="请输入算法编号"
          clearable
          style="width: 200px"
          @keyup.enter="handleQuery" />
      </el-form-item> -->

      <el-form-item>
        <el-button type="primary" icon="Search" @click="handleQuery">搜索</el-button>
        <el-button icon="Refresh" @click="resetQuery">重置</el-button>
      </el-form-item>
    </el-form>

    <el-table v-loading="loading" :data="tableData">
      <el-table-column label="序号" align="center" type="index" width="60" />
      <el-table-column label="算法名称" align="center" prop="algName" min-width="120" />
      <!-- <el-table-column label="算法编号" align="center" prop="algCode" min-width="100" /> -->
      <el-table-column label="执行频率" align="center" prop="exeFrequency" min-width="100" />
      <el-table-column label="版本号" align="center" prop="algVersion" min-width="100" />
      <el-table-column label="运行版本号" align="center" prop="runVersion" min-width="100" />
      <el-table-column label="运行状态" align="center" prop="runStatus">
        <template #default="scope">
          <dict-tag :options="scada_alg_run_status" :value="scope.row.runStatus" />
        </template>
      </el-table-column>
      <!-- <el-table-column label="备注" align="center" prop="remark" /> -->
      <el-table-column label="操作" align="center" class-name="small-padding fixed-width">
        <template #default="scope">
          <el-button
            v-if="scope.row.runStatus == '0'"
            link
            type="primary"
            icon="VideoPlay"
            @click="handleRun(scope.row)"
            v-hasPermi="['scada:algmng:run']"
            >运行</el-button
          >
          <el-button
            v-else
            link
            type="primary"
            icon="VideoPause"
            @click="handleStop(scope.row)"
            v-hasPermi="['scada:algmng:stop']"
            >停止</el-button
          >
          <el-button link type="primary" icon="List" @click="handleLogs(scope.row)" v-hasPermi="['scada:algmng:logs']"
            >日志</el-button
          >
        </template>
      </el-table-column>
    </el-table>

    <pagination
      v-show="total > 0"
      :total="total"
      v-model:page="page.pageNum"
      v-model:limit="page.pageSize"
      @pagination="getList" />
  </div>
</template>

<script setup name="Algmng">
import { getHistoryAlgsubmng, listAlgmng, runAlgmng, stopAlgmng } from '@/api/scada/algmng'
import { useCommandDialog, useTable } from '@/hooks'
import { ElMessage, ElMessageBox, ElOption, ElSelect, ElText } from 'element-plus'
import RunLogs from './components/RunLogs.vue'

const { proxy } = getCurrentInstance()
const { scada_alg_run_status } = proxy.useDict('scada_alg_run_status')
const showSearch = ref(true) // 显示搜索条件
const { tableData, loading, total, queryParams, page, getList, resetQuery, handleQuery } = useTable(listAlgmng, {
  uniqueId: 'algsId',
  params: {
    publishStatus: '1'
  }
})
const runLogs = useCommandDialog(RunLogs)

onMounted(() => {
  getList()
})

function handleRun(row) {
  const version = ref(row.algVersion)
  getHistoryAlgsubmng(row.algId)
    .then((res) => {
      if (res.data.length > 0) {
        const versions = res.data.map((item) => {
          return {
            label: item.algVersion,
            value: item.algVersion
          }
        })

        return ElMessageBox({
          title: `算法运行（${row.algName}）`,
          message: () =>
            h('div', {}, [
              h(ElText, {}, '算法版本：'),
              h(
                ElSelect,
                {
                  placeholder: '请选择想要运行的版本',
                  modelValue: version.value,
                  style: { width: '240px' },
                  'onUpdate:modelValue': (val) => {
                    version.value = val
                  }
                },
                versions.map((item) => {
                  return h(ElOption, item)
                })
              )
            ])
        })
      } else {
        return Promise.reject(new Error('请先发布'))
      }
    })
    .then(() => {
      return runAlgmng(row.algId, version.value)
    })
    .then(() => {
      ElMessage({ message: `算法（${row.algName}）已运行`, type: 'success' })
      getList()
    })
}

function handleStop(row) {
  ElMessageBox.confirm('是否确认停止运行?', '警告', {
    confirmButtonText: '确定',
    cancelButtonText: '取消',
    type: 'warning'
  }).then(() => {
    stopAlgmng(row.algId).then(() => {
      ElMessage({ message: '算法已停止', type: 'success' })
      getList()
    })
  })
}
/** 日志按钮操作 */
function handleLogs(row) {
  runLogs({
    title: `运行日志(${row.algName})`,
    algId: row.algId,
    runVersion: row.runVersion
  })
}
</script>
