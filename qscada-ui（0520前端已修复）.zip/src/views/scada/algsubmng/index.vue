<template>
  <div class="app-container">
    <el-form :model="queryParams" ref="queryForm" :inline="true" v-show="showSearch" label-width="68px">
      <el-form-item label="算子分类" prop="groupType">
        <el-select v-model="queryParams.groupType" placeholder="请选择算子分类" clearable style="width: 200px">
          <el-option
            v-for="dict in scada_algsub_group_type"
            :key="dict.value"
            :label="dict.label"
            :value="dict.value" />
        </el-select>
      </el-form-item>
      <el-form-item label="算子名称" prop="algsName">
        <el-input
          v-model="queryParams.algsName"
          placeholder="请输入算子名称"
          clearable
          style="width: 200px"
          @keyup.enter="handleQuery" />
      </el-form-item>

      <el-form-item label="算子编号" prop="algsCode">
        <el-input
          v-model="queryParams.algsCode"
          placeholder="请输入算子编号"
          clearable
          style="width: 200px"
          @keyup.enter="handleQuery" />
      </el-form-item>

      <el-form-item label="算子类型" prop="algsType">
        <el-select v-model="queryParams.algsType" placeholder="请选择算子类型" clearable style="width: 200px">
          <el-option v-for="dict in scada_algsub_type" :key="dict.value" :label="dict.label" :value="dict.value" />
        </el-select>
      </el-form-item>
      <el-form-item label="发布状态" prop="publishStatus">
        <el-select v-model="queryParams.publishStatus" placeholder="请选择发布状态" clearable style="width: 200px">
          <el-option
            v-for="dict in scada_algsub_publish_status"
            :key="dict.value"
            :label="dict.label"
            :value="dict.value" />
        </el-select>
      </el-form-item>
      <el-form-item label="检测状态" prop="testStatus">
        <el-select v-model="queryParams.testStatus" placeholder="请选择检测状态" clearable style="width: 200px">
          <el-option v-for="dict in scada_test_status" :key="dict.value" :label="dict.label" :value="dict.value" />
        </el-select>
      </el-form-item>

      <el-form-item>
        <el-button type="primary" icon="Search" @click="handleQuery">搜索</el-button>
        <el-button icon="Refresh" @click="resetQuery">重置</el-button>
      </el-form-item>
    </el-form>

    <el-row :gutter="10" class="mb8">
      <el-col :span="1.5">
        <el-button type="primary" plain icon="Plus" @click="handleAdd" v-hasPermi="['scada:algsubmng:add']"
          >新增</el-button
        >
      </el-col>
      <!-- <el-col :span="1.5">
        <el-button
          type="success"
          plain
          icon="Edit"
          :disabled="!isSingle"
          @click="handleUpdate"
          v-hasPermi="['scada:algsubmng:edit']"
          >修改</el-button
        >
      </el-col>
      <el-col :span="1.5">
        <el-button
          type="danger"
          plain
          icon="Delete"
          :disabled="hasMultiple"
          @click="handleDelete"
          v-hasPermi="['scada:algsubmng:remove']"
          >删除</el-button
        >
      </el-col>
      <el-col :span="1.5">
        <el-button type="warning" plain icon="Download" @click="handleExport" v-hasPermi="['scada:algsubmng:export']"
          >导出</el-button
        >
      </el-col> -->
      <right-toolbar v-model:showSearch="showSearch" @queryTable="getList"></right-toolbar>
    </el-row>

    <el-table v-loading="loading" :data="tableData" row-key="algsId" @selection-change="handleSelectionChange">
      <!-- <el-table-column type="selection" width="55" align="center" /> -->
      <!-- <el-table-column label="算子id" align="center" prop="algsId" /> -->
      <el-table-column label="序号" align="center" type="index" width="80" />
      <el-table-column label="算子分类" align="center" prop="groupType" width="120">
        <template #default="scope">
          <dict-tag :options="scada_algsub_group_type" :value="scope.row.groupType" />
        </template>
      </el-table-column>
      <el-table-column label="算子名称" align="center" prop="algsName" min-width="120" />
      <!-- <el-table-column label="算子编号" align="center" prop="algsCode" min-width="100" /> -->
      <!-- <el-table-column label="算子文件" align="center" prop="attachPath" />
      <el-table-column label="算子说明文件" align="center" prop="attachDesPath" /> -->
      <el-table-column label="算子类型" align="center" prop="algsType" width="120">
        <template #default="scope">
          <dict-tag :options="scada_algsub_type" :value="scope.row.algsType" />
        </template>
      </el-table-column>
      <el-table-column label="版本号" align="center" prop="algsVersion" width="120" />
      <el-table-column label="发布状态" align="center" prop="publishStatus" width="100">
        <template #default="scope">
          <dict-tag :options="scada_algsub_publish_status" :value="scope.row.publishStatus" />
        </template>
      </el-table-column>
      <!-- <el-table-column label="函数名" align="center" prop="functionName" />
      <el-table-column label="函数说明" align="center" prop="functionDes" />
      <el-table-column label="入口参数json" align="center" prop="paramArr" />
      <el-table-column label="返回值类型" align="center" prop="returnName" />
      <el-table-column label="返回值说明" align="center" prop="returnDes" /> -->
      <el-table-column label="测试状态" align="center" prop="testStatus" width="120">
        <template #default="scope">
          <dict-tag :options="scada_test_status" :value="scope.row.testStatus" />
        </template>
      </el-table-column>
      <!-- <el-table-column label="显示顺序" align="center" prop="orderNum" width="80" /> -->
      <el-table-column label="备注" align="center" prop="remark" min-width="120" show-overflow-tooltip />
      <el-table-column label="操作" align="center" class-name="small-padding fixed-width" min-width="150">
        <template #default="scope">
          <el-button link type="primary" icon="View" @click="handleView(scope.row)">查看</el-button>
          <el-button
            link
            type="primary"
            icon="Edit"
            @click="handleUpdate(scope.row)"
            v-hasPermi="['scada:algsubmng:edit']"
            >修改</el-button
          >
          <el-button
            link
            type="primary"
            icon="Delete"
            @click="handleDelete(scope.row)"
            v-hasPermi="['scada:algsubmng:remove']"
            >删除</el-button
          >
          <el-button
            link
            type="primary"
            icon="CircleCheck"
            @click="handleCheck(scope.row)"
            v-hasPermi="['scada:algsubmng:test']"
            >测试</el-button
          >
          <el-button
            link
            type="primary"
            icon="Promotion"
            @click="handleRelease(scope.row)"
            v-hasPermi="['scada:algsubmng:release']"
            >发布</el-button
          >
        </template>
      </el-table-column>
    </el-table>

    <pagination
      v-show="total > 0"
      :total="total"
      v-model:page="page.pageNum"
      v-model:limit="page.pageSize"
      @pagination="getList" />
  </div>
</template>

<script setup name="Algsubmng">
import { checkAlgsubmng, delAlgsubmng, listAlgsubmng } from '@/api/scada/algsubmng'
import { useCommandDialog, useTable } from '@/hooks'
import ReleaseOperator from './components/ReleaseOperator.vue'
import SaveOperator from './components/SaveOperator.vue'
import TestAlgsubmng from './components/TestAlgsubmng.vue'
import ViewSourceCode from './components/ViewSourceCode.vue'

const { proxy } = getCurrentInstance()
const { scada_algsub_type, scada_algsub_group_type, scada_algsub_publish_status, scada_test_status } = proxy.useDict(
  'scada_algsub_type',
  'scada_algsub_group_type',
  'scada_algsub_publish_status',
  'scada_test_status'
)
const testAlgsubmng = useCommandDialog(TestAlgsubmng)
const viewSourceCode = useCommandDialog(ViewSourceCode)
const saveOperator = useCommandDialog(SaveOperator)
const releaseOperator = useCommandDialog(ReleaseOperator)
const showSearch = ref(true) // 显示搜索条件

const {
  tableData,
  selectedIds,
  loading,
  // isSingle,
  // hasMultiple,
  total,
  queryParams,
  page,
  getList,
  resetQuery,
  handleQuery,
  handleSelectionChange
} = useTable(listAlgsubmng, { uniqueId: 'algsId', params: {} })

onMounted(() => {
  getList()
})
/** 新增按钮操作 */
function handleAdd() {
  saveOperator({
    title: '添加算子',
    onSubmit: () => {
      getList()
    }
  })
}
/** 修改按钮操作 */
function handleUpdate(row) {
  saveOperator({
    title: '修改算子',
    algsId: row.algsId,
    onSubmit: () => {
      getList()
    }
  })
}

function handleCheck(row) {
  checkAlgsubmng(row.algsId).then((response) => {
    console.log('check', response)
    testAlgsubmng({
      title: '算子测试',
      algsId: row.algsId,
      onClose: () => {
        getList()
      }
    })
  })
}

function handleRelease(row) {
  releaseOperator({
    title: '发布算子',
    algsId: row.algsId,
    onSubmit: () => {
      getList()
    }
  })
}
/** 删除按钮操作 */
function handleDelete(row) {
  const algsIds = row.algsId || selectedIds.value
  proxy.$modal
    .confirm('是否确认删除算子名称为"' + row.algsName + '"的数据项？')
    .then(function () {
      return delAlgsubmng(algsIds)
    })
    .then(() => {
      getList()
      proxy.$modal.msgSuccess('删除成功')
    })
    .catch(() => {})
}
// /** 导出按钮操作 */
// function handleExport() {
//   proxy.download(
//     'scada/algsubmng/export',
//     {
//       ...queryParams
//     },
//     `algsubmng_${new Date().getTime()}.xlsx`
//   )
// }
function handleView(row) {
  viewSourceCode({
    title: '算子测试',
    algsId: row.algsId
  })
}
</script>
