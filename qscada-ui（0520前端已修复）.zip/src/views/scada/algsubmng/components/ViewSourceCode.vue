<script setup>
import { getAlgsubmng, getAlgsubmngCode, getHistoryAlgsubmng, setDefaultVersion } from '@/api/scada/algsubmng'
import CodeEditor from '@/components/CodeEditor/index.vue'
import { ElMessage } from 'element-plus'
const { proxy } = getCurrentInstance()
const { scada_algsub_type, scada_algsub_group_type } = proxy.useDict('scada_algsub_type', 'scada_algsub_group_type')
const { algsId, visible } = defineProps({
  visible: { type: Boolean, default: false },
  title: { type: String },
  algsId: { type: Number, required: true }
})
const emits = defineEmits(['update:visible', 'close'])

const dialogVisible = computed({
  get() {
    return visible
  },
  set(val) {
    emits('update:visible', val)
    if (!val) {
      emits('close')
    }
  }
})

const loading = ref(false)
const code = ref('')
const codeVersion = ref('')
const defaultVersion = ref(null)

const versions = ref([])
const language = ref('python')
const history = ref([])

const activeName = ref('first')

const formRef = ref(null)
const formRef_Ver = ref(null)

const form = reactive({
  groupType: null,
  algsName: null,
  algsCode: null,
  attachPath: null,
  attachDesPath: null,
  algsType: null,
  publishStatus: '0',
  functionName: null,
  functionDes: null,
  paramArr: null,
  returnName: null,
  returnDes: null,
  checkStatus: '0',
  orderNum: null,
  createBy: null,
  createTime: null,
  updateBy: null,
  updateTime: null,
  remark: null
})

function getSourceCode() {
  loading.value = false

  getAlgsubmng(algsId).then((response) => {
    defaultVersion.value = response.data.defaultVersion
  })

  getAlgsubmngCode(algsId)
    .then((response) => {
      code.value = response.data.srcCode
      codeVersion.value = response.data.version
      return getHistoryAlgsubmng(algsId)
    })
    .then((res) => {
      history.value = res.data
      res.data.forEach((item) => {
        versions.value.push({
          label: item.algsVersion,
          value: item.algsVersion
        })
      })

      versions.value.push({
        label: '当前版本',
        value: ''
      })
      changeVersion(codeVersion.value)
    })
    .finally(() => {
      loading.value = false
    })
}

function changeVersion(value) {
  const version = history.value.find((item) => item.algsVersion === value)
  if (!version && !value) {
    getAlgsubmng(algsId).then((response) => {
      response.data.algsVersion = ''

      const curVer = response.data
      history.value.push(curVer)
      _changeVersion(value, curVer)
    })
  } else {
    _changeVersion(value, version)
  }
}

function _changeVersion(value, version) {
  if (version) {
    // let reqValue = value;
    // if (reqValue == '-1')
    //   reqValue = "";

    getAlgsubmngCode(algsId, value).then((res) => {
      code.value = res.data.srcCode
      codeVersion.value = value
    })

    formRef.value?.resetFields?.()
    formRef_Ver.value?.resetFields?.()
    for (let key of Object.keys(form)) {
      form[key] = version[key]
    }
  }
}

function handleSetDefaultVersion() {
  setDefaultVersion(algsId, codeVersion.value)
    .then((res) => {
      ElMessage.success(res.msg)
      defaultVersion.value = codeVersion.value
    })
    .catch((err) => {
      ElMessage.error(err.msg)
    })
}

onMounted(() => {
  getSourceCode()
})
</script>

<template>
  <el-dialog v-model="dialogVisible" width="1000px" append-to-body>
    <template #header>
      <el-space>
        <el-text class="title" size="large" type="primary">查看算子</el-text>
        <el-select
          v-model="codeVersion"
          placeholder="请选择算法版本"
          style="width: 160px"
          :empty-values="[null, undefined]"
          @change="changeVersion">
          <!-- <el-option v-for="item in versions" :key="item.value" :label="item.label" :value="item.value" /> -->

          <el-option v-for="item in versions" :key="item.value" :label="item.label" :value="item.value">
            <el-space :size="30">
              <span style="float: left">{{ item.label }}</span>
              <span
                v-if="item.label == defaultVersion"
                style="float: right; color: var(--el-text-color-secondary); font-size: 12px">
                <el-tag type="primary">默认</el-tag>
              </span>
            </el-space>
          </el-option>
        </el-select>
        <el-button v-if="versions.length" type="primary" :disabled="!codeVersion" @click="handleSetDefaultVersion"
          >设为默认</el-button
        >
      </el-space>
    </template>
    <el-tabs v-model="activeName" @tab-click="handleClick">
      <el-tab-pane label="源代码查看" name="first">
        <code-editor
          ref="monaco"
          v-model="code"
          :language="language"
          height="calc(100vh - 200px)"
          readOnly
          v-loading="loading" />
      </el-tab-pane>
      <el-tab-pane label="算子信息" name="second">
        <el-form ref="formRef" :model="form" disabled="true" label-width="80px">
          <el-form-item label="算子分类" prop="groupType">
            <el-select v-model="form.groupType" placeholder="请选择算子分类">
              <el-option
                v-for="dict in scada_algsub_group_type"
                :key="dict.value"
                :label="dict.label"
                :value="dict.value"></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="算子类型" prop="algsType">
            <el-select v-model="form.algsType" placeholder="请选择算子类型">
              <el-option
                v-for="dict in scada_algsub_type"
                :key="dict.value"
                :label="dict.label"
                :value="dict.value"></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="算子名称" prop="algsName">
            <el-input v-model="form.algsName" placeholder="请输入算子名称" />
          </el-form-item>
          <el-form-item label="算子文件">
            <file-upload v-model="form.attachPath" disabled="true" :limit="1" :fileType="fileType" />
          </el-form-item>
          <el-form-item label="算子说明">
            <file-upload v-model="form.attachDesPath" :limit="1" :disabled="true" :fileType="['md']" />
          </el-form-item>
        </el-form>
      </el-tab-pane>

      <el-tab-pane label="版本信息" name="third" :disabled="!codeVersion">
        <el-form v-show="codeVersion" ref="formRef_Ver" :model="form" label-width="auto" disabled="true">
          <el-row>
            <el-col :span="12">
              <el-form-item label="版本号" prop="algsVersion">
                <el-input v-model="form.algsVersion" placeholder="" />
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="发布时间" prop="algsVersion">
                <el-input v-model="form.createTime" placeholder="" />
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="24">
              <el-form-item label="备注" prop="remark">
                <el-input v-model="form.remark" type="textarea" placeholder="请输入内容" />
              </el-form-item>
            </el-col>
          </el-row>
        </el-form>
      </el-tab-pane>
    </el-tabs>
  </el-dialog>
</template>
