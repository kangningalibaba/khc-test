<script setup>
import { changePubStatus, getNextVersion, isRepeatVersion } from '@/api/scada/algsubmng'
import { ElMessage, ElMessageBox } from 'element-plus'
import { computed, onMounted, ref } from 'vue'
const { algsId, visible, onSubmit } = defineProps({
  visible: { type: Boolean, default: false },
  title: { type: String },
  algsId: { type: Number, required: true },
  onSubmit: { type: Function, default: () => {} }
})

const emits = defineEmits(['update:visible', 'close'])

const dialogVisible = computed({
  get() {
    return visible
  },
  set(val) {
    emits('update:visible', val)
    if (!val) {
      emits('close')
    }
  }
})
const loading = ref(false)
const formRef = ref(null)
const form = reactive({ algsVersion: '', remark: '' })

function cancel() {
  dialogVisible.value = false
  formRef.value.resetFields?.()
}

function init() {
  getNextVersion(algsId).then((response) => {
    const { version: algsVersion, remark } = response.data
    form.algsVersion = algsVersion
    form.remark = remark
  })
}

onMounted(() => {
  init()
})

function release() {
  changePubStatus(algsId, form)
    .then(() => {
      ElMessage({ message: '发布成功', type: 'success' })
      onSubmit()
      cancel()
    })
    .finally(() => {
      loading.value = false
    })
}

function submitForm() {
  loading.value = true
  isRepeatVersion(algsId, form.algsVersion).then((response) => {
    console.log(response)
    const { data } = response
    if (data) {
      ElMessageBox.confirm('发现相同版本号，是否覆盖？', '提示', { type: 'warning' })
        .then(() => {
          release()
        })
        .catch(() => {
          loading.value = false
        })
    } else {
      release()
    }
  })
}
</script>

<template>
  <el-dialog :title="title" v-model="dialogVisible" width="600px" append-to-body>
    <el-form ref="formRef" :model="form" label-width="auto">
      <el-form-item label="版本号" prop="algsVersion">
        <el-input v-model="form.algsVersion" placeholder="" />
      </el-form-item>
      <el-form-item label="备注" prop="remark">
        <el-input v-model="form.remark" type="textarea" placeholder="请输入内容" />
      </el-form-item>
    </el-form>
    <template #footer>
      <div class="dialog-footer">
        <el-button type="primary" @click="submitForm" :loading="loading">发 布</el-button>
        <el-button @click="cancel">取 消</el-button>
      </div>
    </template>
  </el-dialog>
</template>
