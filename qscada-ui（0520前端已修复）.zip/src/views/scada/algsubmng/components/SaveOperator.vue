<script setup>
import { addAlgsubmng, getAlgsubmng, updateAlgsubmng } from '@/api/scada/algsubmng'
import { computed, onMounted, ref } from 'vue'
const { proxy } = getCurrentInstance()
const { scada_algsub_type, scada_algsub_group_type } = proxy.useDict('scada_algsub_type', 'scada_algsub_group_type')
const { algsId, visible, onSubmit } = defineProps({
  visible: { type: Boolean, default: false },
  title: { type: String },
  algsId: { type: Number },
  onSubmit: { type: Function, default: () => {} }
})

const emits = defineEmits(['update:visible', 'close'])

const dialogVisible = computed({
  get() {
    return visible
  },
  set(val) {
    emits('update:visible', val)
    if (!val) {
      emits('close')
    }
  }
})
const loading = ref(false)
const formRef = ref(null)
const form = reactive({
  groupType: null,
  algsName: null,
  algsCode: null,
  attachPath: null,
  attachDesPath: null,
  algsType: null,
  publishStatus: '0',
  functionName: null,
  functionDes: null,
  paramArr: null,
  returnName: null,
  returnDes: null,
  checkStatus: '0',
  orderNum: null,
  createBy: null,
  createTime: null,
  updateBy: null,
  updateTime: null,
  remark: null
})
const rules = reactive({
  algsName: [{ required: true, message: '算子名称不能为空', trigger: 'blur' }],
  groupType: [{ required: true, message: '请选择算子分类', trigger: 'change' }],
  algsType: [{ required: true, message: '请选择算子类型', trigger: 'change' }]
})
const fileType = computed(() => {
  const currentFile = scada_algsub_type.value.find((item) => form.algsType == item.value)
  if (currentFile?.label == 'python') {
    return ['py']
  } else if (currentFile?.label == 'C') {
    return ['c']
  } else if (currentFile?.label == 'cpp') {
    return ['cpp']
  } else if (currentFile?.label == 'lua') {
    return ['lua']
  } else if (currentFile?.label == 'js') {
    return ['js']
  } else if (currentFile?.label == 'Java') {
    return ['java']
  } else {
    return ['py', 'c', 'cpp', 'txt', 'h', 'lua', 'js', 'java']
  }
})

function cancel() {
  dialogVisible.value = false
  formRef.value?.resetFields?.()
}

function submitForm() {
  loading.value = false
  formRef.value.validate((valid, fields) => {
    if (valid) {
      if (algsId != null) {
        updateAlgsubmng(Object.assign({}, form, { algsId })).then(() => {
          proxy.$modal.msgSuccess('修改成功')
          onSubmit()
          cancel()
        })
      } else {
        addAlgsubmng(form).then(() => {
          proxy.$modal.msgSuccess('新增成功')
          onSubmit()
          cancel()
        })
      }
    } else {
      console.log(fields)
    }
  })
}

function getOperatorInfo() {
  formRef.value?.resetFields?.()
  getAlgsubmng(algsId).then((response) => {
    const data = response.data
    for (let key of Object.keys(form)) {
      form[key] = data[key]
    }
  })
}

function handleAlgsTypeChange() {
  form.attachPath = ''
}

onMounted(() => {
  if (algsId) {
    getOperatorInfo()
  }
})
</script>

<template>
  <!-- 添加或修改算子管理对话框 -->
  <el-dialog :title="title" v-model="dialogVisible" width="800px" append-to-body>
    <el-form ref="formRef" :model="form" :rules="rules" label-width="80px">
      <el-form-item label="算子分类" prop="groupType">
        <el-select v-model="form.groupType" placeholder="请选择算子分类">
          <el-option
            v-for="dict in scada_algsub_group_type"
            :key="dict.value"
            :label="dict.label"
            :value="dict.value"></el-option>
        </el-select>
      </el-form-item>
      <el-form-item label="算子类型" prop="algsType">
        <el-select v-model="form.algsType" placeholder="请选择算子类型" @change="handleAlgsTypeChange">
          <el-option
            v-for="dict in scada_algsub_type"
            :key="dict.value"
            :label="dict.label"
            :value="dict.value"></el-option>
        </el-select>
      </el-form-item>
      <el-form-item label="算子名称" prop="algsName">
        <el-input v-model="form.algsName" placeholder="请输入算子名称" />
      </el-form-item>
      <!-- <el-form-item label="算子编号" prop="algsCode">
        <el-input v-model="form.algsCode" placeholder="请输入算子编号" />
      </el-form-item>
      <el-form-item label="版本号" prop="algsVersion">
        <el-input v-model="form.algsVersion" placeholder="" />
      </el-form-item> -->
      <!-- <el-form-item label="显示顺序" prop="orderNum">
        <el-input v-model="form.orderNum" placeholder="请输入显示顺序" />
      </el-form-item> -->

      <!-- <el-form-item label="发布状态">
        <el-radio-group v-model="form.publishStatus">
          <el-radio v-for="dict in scada_algsub_publish_status" :key="dict.value" :value="dict.value">{{
            dict.label
          }}</el-radio>
        </el-radio-group>
      </el-form-item>

      <el-form-item label="检测状态">
        <el-radio-group v-model="form.checkStatus">
          <el-radio v-for="dict in scada_algsub_check_status" :key="dict.value" :value="dict.value">{{
            dict.label
          }}</el-radio>
        </el-radio-group>
      </el-form-item> -->

      <el-form-item label="算子文件">
        <file-upload v-model="form.attachPath" :disabled="!form.algsType" :limit="1" :fileType="fileType" />
      </el-form-item>
      <el-form-item label="算子说明">
        <file-upload v-model="form.attachDesPath" :limit="1" :fileType="['md']" />
      </el-form-item>

      <!-- <el-form-item label="函数名" prop="functionName">
          <el-input v-model="form.functionName" type="textarea" placeholder="请输入内容" />
        </el-form-item>
        <el-form-item label="函数说明" prop="functionDes">
          <el-input v-model="form.functionDes" type="textarea" placeholder="请输入内容" />
        </el-form-item>
        <el-form-item label="入口参数json" prop="paramArr">
          <el-input v-model="form.paramArr" type="textarea" placeholder="请输入内容" />
        </el-form-item>
        <el-form-item label="返回值类型" prop="returnName">
          <el-input v-model="form.returnName" type="textarea" placeholder="请输入内容" />
        </el-form-item>
        <el-form-item label="返回值说明" prop="returnDes">
          <el-input v-model="form.returnDes" type="textarea" placeholder="请输入内容" />
        </el-form-item>
      <el-form-item label="备注" prop="remark">
        <el-input v-model="form.remark" type="textarea" placeholder="请输入内容" />
      </el-form-item> -->
    </el-form>
    <template v-slot:footer>
      <div class="dialog-footer">
        <el-button type="primary" @click="submitForm(formRef)">确 定</el-button>
        <el-button @click="cancel">取 消</el-button>
      </div>
    </template>
  </el-dialog>
</template>
