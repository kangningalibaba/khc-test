<script setup>
import { getAlgsubmng, runTestAlgsubmng } from '@/api/scada/algsubmng'
import { computed, onMounted, ref } from 'vue'
const { algsId, visible } = defineProps({
  visible: { type: Boolean, default: false },
  title: { type: String },
  algsId: { type: Number, required: true }
})

const emits = defineEmits(['update:visible', 'close'])

const dialogVisible = computed({
  get() {
    return visible
  },
  set(val) {
    emits('update:visible', val)
    if (!val) {
      emits('close')
    }
  }
})
const loading = ref(false)
const formRef = ref(null)
const form = reactive({
  params: []
})
const name = ref('')
const runlog = ref([])
const returnType = ref('')
const returnDescribe = ref('')

function cancel() {
  dialogVisible.value = false
  formRef.value?.resetFields?.()
}

function submitForm() {
  loading.value = true
  const inputs = form.params.map((item) => item.value)
  runTestAlgsubmng(algsId, inputs)
    .then((response) => {
      runlog.value = response.runlog ?? []
    })
    .catch((error) => {
      runlog.value = error.runlog ?? []
    })
    .finally(() => {
      loading.value = false
    })
}

function getOperatorInfo() {
  getAlgsubmng(algsId).then((response) => {
    const { paramArr, functionDes, functionName, returnName, returnDes } = response.data
    if (functionDes) {
      name.value = functionDes ?? functionName
    }
    returnType.value = returnName
    returnDescribe.value = returnDes
    const formItems = JSON.parse(paramArr)
    formItems.map((item) => {
      form.params.push({
        name: item.name,
        value: null,
        label: item.des,
        type: item.type
      })
    })
  })
}

onMounted(() => {
  getOperatorInfo()
})
</script>

<template>
  <el-dialog :title="title" v-model="dialogVisible" width="600px" append-to-body>
    <el-alert
      :title="`算子说明：${name}`"
      :description="`返回值类型(${returnType})：${returnDescribe}`"
      type="warning"
      show-icon
      :closable="false" />
    <el-form ref="formRef" :model="form" label-width="auto">
      <el-form-item
        v-for="(param, index) in form.params"
        :key="param.name"
        :label="`${param.label}(${param.type})`"
        :prop="`params.${index}.value`">
        <el-switch v-if="param.type === 'BOOLEAN'" v-model="param.value" />
        <el-input-number
          v-else-if="param.type === 'INTEGER' || param.type === 'DOUBLE'"
          v-model="param.value"
          :precision="param.type === 'DOUBLE' ? 2 : 0" />
        <el-input v-else v-model="param.value" placeholder="请输入内容" />
      </el-form-item>
    </el-form>
    <template v-if="runlog.length">
      <el-divider content-position="left">运行日志</el-divider>
      <el-timeline>
        <el-timeline-item v-for="(log, index) in runlog" :key="index" :timestamp="log.time">
          {{ log.msg }}
        </el-timeline-item>
      </el-timeline>
    </template>
    <template #footer>
      <div class="dialog-footer">
        <el-button type="primary" @click="submitForm" :loading="loading">运 行</el-button>
        <el-button @click="cancel">取 消</el-button>
      </div>
    </template>
  </el-dialog>
</template>

<style lang="scss" scoped>
.el-alert {
  margin-bottom: 20px;

  --el-alert-title-with-description-font-size: 12px;
  --el-alert-description-font-size: 12px;
}
</style>
