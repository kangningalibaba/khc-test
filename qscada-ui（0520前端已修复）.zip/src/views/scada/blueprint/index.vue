<template>
  <div class="blueprint">
    <BlueprintDesigner ref="blueprintDesigner" v-loading="loading" />
  </div>
</template>

<script setup name="BlueprintDesigner">
import { getAlgmng, runTestAlgmng } from '@/api/scada/algmng'
import BlueprintDesigner from '@/components/BlueprintDesigner'
import { useCommandDialog } from '@/hooks'
import RunLog from './components/RunLog.vue'
import SaveBlueprint from './components/SaveBlueprint.vue'

const route = useRoute()
const router = useRouter()
const { proxy } = getCurrentInstance()
// const { scada_alg_start_status, scada_alg_publish_status, scada_algsub_check_status } = proxy.useDict(
//   'scada_alg_start_status',
//   'scada_alg_publish_status',
//   'scada_algsub_check_status'
// )
const blueprintData = ref(null)
const blueprintDesigner = ref(null)
const lf = ref(null)

const openRunLog = useCommandDialog(RunLog)
const openSaveBlueprint = useCommandDialog(SaveBlueprint)
const loading = ref(false)
const runLogs = ref([])

function handleSave(algJson) {
  const algId = route.query.id
  const options = {
    title: '新增算法',
    algJson,
    onSubmit() {
      router.push({ path: '/algorithm/algmng' })
      if (algId) {
        proxy.$modal.msgSuccess('修改成功')
      } else {
        proxy.$modal.msgSuccess('新增成功')
      }
    }
  }
  if (algId) {
    options.title = '修改算法'
    options.algId = algId
  }
  openSaveBlueprint(options)
}

function loadData() {
  const algId = route.query.id
  if (algId) {
    getAlgmng(algId).then((response) => {
      let data = response.data
      data.algJson = JSON.parse(data.algJson)
      blueprintData.value = data.algJson
      lf.value.renderRawData(blueprintData.value)
      if (data.testLogJson) {
        runLogs.value = JSON.parse(data.testLogJson)
      }
    })
  }
}

onMounted(() => {
  lf.value = blueprintDesigner.value.lf
  loadData()
  lf.value.extension.control.addItem({
    key: 'save',
    iconClass: 'icon-save',
    title: '',
    text: '保存',
    onClick: () => {
      handleSave(lf.value.getGraphData())
    }
  })
  if (route.query.id) {
    lf.value.extension.control.addItem({
      key: 'test',
      iconClass: 'icon-test',
      title: '',
      text: '测试',
      onClick: () => {
        loading.value = true
        runTestAlgmng(route.query.id)
          .then((res) => {
            runLogs.value = res.runlog
            openRunLog({ visible: true, runLog: res.runlog })
            proxy.$modal.msgSuccess('测试成功')
          })
          .catch((err) => {
            runLogs.value = err.runlog
            openRunLog({ visible: true, runLog: err.runlog })
          })
          .finally(() => {
            loading.value = false
          })
      }
    })
    lf.value.extension.control.addItem({
      key: 'logs',
      iconClass: 'icon-logs',
      title: '',
      text: '日志',
      onClick: () => {
        openRunLog({ visible: true, runLog: runLogs.value })
      }
    })
  }

  lf.value.render(blueprintData.value)
})
</script>

<style lang="scss" scoped>
.blueprint {
  height: calc(100vh - 84px);

  :deep(.icon-save) {
    background-image: url('data:image/svg+xml;charset=utf-8;base64,PHN2ZyB0PSIxNzM4OTk4NTQ2MTkyIiBjbGFzcz0iaWNvbiIgdmlld0JveD0iMCAwIDEwMjQgMTAyNCIgdmVyc2lvbj0iMS4xIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHAtaWQ9IjQyMDUiIHdpZHRoPSIyMDAiIGhlaWdodD0iMjAwIj48cGF0aCBkPSJNNzY4IDgxMC42NjY2NjdoNDIuNjY2NjY3VjI5MS4zMjhMNzMyLjY3MiAyMTMuMzMzMzMzSDY4Mi42NjY2Njd2MTcwLjY2NjY2N0gyOTguNjY2NjY3VjIxMy4zMzMzMzNIMjEzLjMzMzMzM3Y1OTcuMzMzMzM0aDQyLjY2NjY2N3YtMjk4LjY2NjY2N2g1MTJ2Mjk4LjY2NjY2N3pNMTcwLjY2NjY2NyAxMjhoNTk3LjMzMzMzM2wxMTUuNDk4NjY3IDExNS40OTg2NjdhNDIuNjY2NjY3IDQyLjY2NjY2NyAwIDAgMSAxMi41MDEzMzMgMzAuMTY1MzMzVjg1My4zMzMzMzNhNDIuNjY2NjY3IDQyLjY2NjY2NyAwIDAgMS00Mi42NjY2NjcgNDIuNjY2NjY3SDE3MC42NjY2NjdhNDIuNjY2NjY3IDQyLjY2NjY2NyAwIDAgMS00Mi42NjY2NjctNDIuNjY2NjY3VjE3MC42NjY2NjdhNDIuNjY2NjY3IDQyLjY2NjY2NyAwIDAgMSA0Mi42NjY2NjctNDIuNjY2NjY3eiBtMTcwLjY2NjY2NiA0NjkuMzMzMzMzdjIxMy4zMzMzMzRoMzQxLjMzMzMzNHYtMjEzLjMzMzMzNEgzNDEuMzMzMzMzeiIgZmlsbD0iIzAwMDAwMCIgcC1pZD0iNDIwNiI+PC9wYXRoPjwvc3ZnPg==');
  }

  :deep(.icon-test) {
    background-image: url('data:image/svg+xml;charset=utf-8;base64,PHN2ZyB0PSIxNzQwNDU1MzIwMTE4IiBjbGFzcz0iaWNvbiIgdmlld0JveD0iMCAwIDEwMjQgMTAyNCIgdmVyc2lvbj0iMS4xIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHAtaWQ9IjM4NDIyIiB3aWR0aD0iMjAwIiBoZWlnaHQ9IjIwMCI+PHBhdGggZD0iTTYwMi44OCA0ODcuMjk2YzguMTkyIDMwLjk3NiAwLjE5MiA2NS4zNDQtMjQuMTI4IDg5LjYtMzYuMjg4IDM2LjI4OC05NS4xNjggMzYuMjg4LTEzMS40NTYgMC0zNi4yODgtMzYuMjg4LTM2LjI4OC05NS4xNjggMC0xMzEuNDU2IDI2LjI0LTI2LjI0IDY0LjMyLTMzLjQ3MiA5Ny4xNTItMjEuNzZsMzM3LjI4LTMwNi4zMDRjMTcuODU2LTE3Ljc5MiA0MC4zODQtMjQuMTI4IDQ3LjM2LTE3LjIxNiA4LjU3NiA4LjU3NiAwLjU3NiAyOS41MDQtMTcuMjE2IDQ3LjI5Nkw2MDIuODggNDg3LjI5NnpNNTEyIDE3NmMtMTg1LjUzNiAwLTMzNiAxNTAuNDY0LTMzNiAzMzZzMTUwLjQ2NCAzMzYgMzM2IDMzNiAzMzYtMTUwLjQ2NCAzMzYtMzM2YzAtNDQuMDk2LTkuMDI0LTg1Ljk1Mi0yNC40NDgtMTI0LjU0NGw4MS40MDgtOTAuNjg4QzkzOS45NjggMzYwLjcwNCA5NjAgNDMzLjk4NCA5NjAgNTEyYzAgMjQ3LjQyNC0yMDAuNTc2IDQ0OC00NDggNDQ4UzY0IDc1OS40MjQgNjQgNTEyIDI2NC41NzYgNjQgNTEyIDY0YzgwLjEyOCAwIDE1NS4yIDIxLjMxMiAyMjAuMjI0IDU4LjE3Nkw2NDQuMTYgMjAzLjJDNjAzLjU4NCAxODUuNzkyIDU1OC45NzYgMTc2IDUxMiAxNzZ6IiBwLWlkPSIzODQyMyI+PC9wYXRoPjwvc3ZnPg==');
  }

  :deep(.icon-logs) {
    background-image: url('data:image/svg+xml;charset=utf-8;base64,PHN2ZyB0PSIxNzQxMzM3MjEzOTYyIiBjbGFzcz0iaWNvbiIgdmlld0JveD0iMCAwIDEwMjQgMTAyNCIgdmVyc2lvbj0iMS4xIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHAtaWQ9IjUxNjIiIHdpZHRoPSIyMDAiIGhlaWdodD0iMjAwIj48cGF0aCBkPSJNODM5Ljc0IDk1OS4zMmgtNjUxLjlhODEuNDkgODEuNDkgMCAwIDEtODEuNDgtODEuNDl2LTY1MS45YTgxLjQ4IDgxLjQ4IDAgMCAxIDgxLjQ4LTgxLjQ4aDY1MS45YTgxLjQ5IDgxLjQ5IDAgMCAxIDgxLjQ5IDgxLjQ4djY1MS45YTgxLjUgODEuNSAwIDAgMS04MS40OSA4MS40OXpNODM1IDg3Ny44M3YtNjUxLjlIMTkyLjY0djY1MS45eiIgcC1pZD0iNTE2MyI+PC9wYXRoPjxwYXRoIGQ9Ik0yNjkuMzMgNjIuOTZtNDAuNzQgMGwwLjAxIDBxNDAuNzQgMCA0MC43NCA0MC43NGwwIDE2Mi45OHEwIDQwLjc0LTQwLjc0IDQwLjc0bC0wLjAxIDBxLTQwLjc0IDAtNDAuNzQtNDAuNzRsMC0xNjIuOThxMC00MC43NCA0MC43NC00MC43NFoiIHAtaWQ9IjUxNjQiPjwvcGF0aD48cGF0aCBkPSJNNDczLjA1IDYyLjk2bTQwLjc0IDBsMC4wMSAwcTQwLjc0IDAgNDAuNzQgNDAuNzRsMCAxNjIuOThxMCA0MC43NC00MC43NCA0MC43NGwtMC4wMSAwcS00MC43NCAwLTQwLjc0LTQwLjc0bDAtMTYyLjk4cTAtNDAuNzQgNDAuNzQtNDAuNzRaIiBwLWlkPSI1MTY1Ij48L3BhdGg+PHBhdGggZD0iTTY3Ni43NyA2Mi45Nm00MC43NCAwbDAuMDEgMHE0MC43NCAwIDQwLjc0IDQwLjc0bDAgMTYyLjk4cTAgNDAuNzQtNDAuNzQgNDAuNzRsLTAuMDEgMHEtNDAuNzQgMC00MC43NC00MC43NGwwLTE2Mi45OHEwLTQwLjc0IDQwLjc0LTQwLjc0WiIgcC1pZD0iNTE2NiI+PC9wYXRoPjxwYXRoIGQ9Ik0yNjkuMzMgMzg4LjkxbTQwLjc0IDBsNDA3LjQ0IDBxNDAuNzQgMCA0MC43NCA0MC43NGwwIDAuMDFxMCA0MC43NC00MC43NCA0MC43NGwtNDA3LjQ0IDBxLTQwLjc0IDAtNDAuNzQtNDAuNzRsMC0wLjAxcTAtNDAuNzQgNDAuNzQtNDAuNzRaIiBwLWlkPSI1MTY3Ij48L3BhdGg+PHBhdGggZD0iTTI2OS4zMyA1NTEuODhtNDAuNzQgMGw0MDcuNDQgMHE0MC43NCAwIDQwLjc0IDQwLjc0bDAgMC4wMXEwIDQwLjc0LTQwLjc0IDQwLjc0bC00MDcuNDQgMHEtNDAuNzQgMC00MC43NC00MC43NGwwLTAuMDFxMC00MC43NCA0MC43NC00MC43NFoiIHAtaWQ9IjUxNjgiPjwvcGF0aD48cGF0aCBkPSJNMjY5LjMzIDcxNC44Nm00MC43NCAwbDQwNy40NCAwcTQwLjc0IDAgNDAuNzQgNDAuNzRsMCAwLjAxcTAgNDAuNzQtNDAuNzQgNDAuNzRsLTQwNy40NCAwcS00MC43NCAwLTQwLjc0LTQwLjc0bDAtMC4wMXEwLTQwLjc0IDQwLjc0LTQwLjc0WiIgcC1pZD0iNTE2OSI+PC9wYXRoPjwvc3ZnPg==');
  }
}
</style>
