<script setup>
const { visible, runLog } = defineProps({
  visible: { type: Boolean, default: false },
  runlog: { type: Object, required: true }
})
const emits = defineEmits(['update:visible', 'close'])

const dialogVisible = computed({
  get() {
    return visible
  },
  set(val) {
    emits('update:visible', val)
    if (!val) {
      emits('close')
    }
  }
})
</script>

<template>
  <el-drawer v-model="dialogVisible" title="算法测试（运行日志）" direction="btt">
    <el-timeline>
      <el-timeline-item v-for="(log, index) in runLog" :key="index" :timestamp="log.time">
        {{ log.msg }}
      </el-timeline-item>
    </el-timeline>
  </el-drawer>
</template>
