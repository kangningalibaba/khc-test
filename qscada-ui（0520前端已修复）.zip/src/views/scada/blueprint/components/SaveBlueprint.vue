<script setup>
import { addAlgmng, getAlgmng, updateAlgmng } from '@/api/scada/algmng'
import Crontab from '@/components/Crontab'
import { useConfirmDialog } from '@vueuse/core'
import { computed, onMounted, ref, useTemplateRef } from 'vue'

const { algId, algJson, visible, onSubmit } = defineProps({
  visible: { type: Boolean, default: false },
  title: { type: String },
  algId: { type: [Number, String] },
  algJson: { type: Object, required: true },
  onSubmit: { type: Function, default: () => {} }
})

const emits = defineEmits(['update:visible', 'close'])

const { isRevealed, reveal, confirm, cancel: close, onReveal, onConfirm } = useConfirmDialog()
const expression = ref('')

const dialogVisible = computed({
  get() {
    return visible
  },
  set(val) {
    emits('update:visible', val)
    if (!val) {
      emits('close')
    }
  }
})
const loading = ref(false)
const formRef = useTemplateRef('formRef')
const form = reactive({
  algName: null,
  algCode: null,
  algJson: null,
  exeFrequency: null,
  publishStatus: '0',
  startStatus: '0',
  checkStatus: '0',
  orderNum: null,
  createBy: null,
  createTime: null,
  updateBy: null,
  updateTime: null,
  remark: null
})
const rules = {
  algName: [
    {
      required: true,
      message: '请输入算法名称',
      trigger: 'blur'
    }
  ],
  exeFrequency: [
    {
      required: true
    }
  ]
}

function cancel() {
  dialogVisible.value = false
  formRef.value?.resetFields?.()
}

function init() {
  if (algId) {
    form.algId = algId
    getAlgmng(algId).then((response) => {
      const { data } = response
      for (let [key, value] of Object.entries(form)) {
        if (key != 'algJson') {
          form[key] = data[key] ?? value
        } else {
          form.algJson = algJson
        }
      }
    })
  } else {
    formRef.value?.resetField?.()
    form.algJson = algJson
    delete form.algId
  }
}

onReveal(() => {
  expression.value = form.exeFrequency
})

onConfirm((expression) => {
  form.exeFrequency = expression
})

onMounted(() => {
  init()
})

function submitForm() {
  formRef.value.validate((valid) => {
    if (valid) {
      let data = Object.assign({}, form)
      data.algJson = JSON.stringify(data.algJson)
      loading.value = true
      if (data.algId != null) {
        updateAlgmng(data)
          .then(() => {
            onSubmit()
          })
          .finally(() => {
            loading.value = false
            cancel()
          })
      } else {
        addAlgmng(data)
          .then(() => {
            onSubmit()
          })
          .finally(() => {
            loading.value = false
            cancel()
          })
      }
    }
  })
}
</script>

<template>
  <el-dialog :title="title" v-model="dialogVisible" width="600px" append-to-body>
    <el-form ref="formRef" :model="form" :rules="rules" label-width="80px">
      <el-row>
        <el-col :span="12">
          <el-form-item label="算法名称" prop="algName">
            <el-input v-model="form.algName" placeholder="请输入算法名称" />
          </el-form-item>
        </el-col>
        <el-col :span="12">
          <el-form-item label="算法编号" prop="algCode">
            <el-input v-model="form.algCode" placeholder="请输入算法编号" />
          </el-form-item>
        </el-col>
      </el-row>
      <el-row>
        <el-col :span="12">
          <el-form-item label="执行频率" prop="exeFrequency">
            <el-input v-model="form.exeFrequency" placeholder="请生成执行频率表达式">
              <template #append>
                <el-button type="primary" @click="reveal">
                  生成表达式
                  <i class="el-icon-time el-icon--right"></i>
                </el-button>
              </template>
            </el-input>
          </el-form-item>
        </el-col>
        <el-col :span="12">
          <el-form-item label="版本号" prop="algVersion">
            <el-input v-model="form.algVersion" placeholder="" :disabled="true" />
          </el-form-item>
        </el-col>
      </el-row>

      <!-- <el-row>
          <el-col :span="12">
            <el-form-item label="显示顺序" prop="orderNum">
              <el-input v-model="form.orderNum" placeholder="请输入显示顺序" />
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="检测状态">
              <el-radio-group v-model="form.checkStatus">
                <el-radio v-for="dict in scada_algsub_check_status" :key="dict.value" :value="dict.value">{{
                  dict.label
                }}</el-radio>
              </el-radio-group>
            </el-form-item>
          </el-col>
        </el-row>

        <el-row>
          <el-col :span="12">
            <el-form-item label="发布状态">
              <el-radio-group v-model="form.publishStatus">
                <el-radio v-for="dict in scada_alg_publish_status" :key="dict.value" :value="dict.value">{{
                  dict.label
                }}</el-radio>
              </el-radio-group>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="启用状态">
              <el-radio-group v-model="form.startStatus">
                <el-radio v-for="dict in scada_alg_start_status" :key="dict.value" :value="dict.value">{{
                  dict.label
                }}</el-radio>
              </el-radio-group>
            </el-form-item>
          </el-col>
        </el-row> -->

      <!-- <el-form-item label="算法json" prop="algJson">
          <el-input v-model="form.algJson" type="textarea" placeholder="请输入内容" />
        </el-form-item> -->

      <el-form-item label="备注" prop="remark">
        <el-input v-model="form.remark" type="textarea" placeholder="请输入内容" />
      </el-form-item>
    </el-form>
    <el-dialog title="执行频率" v-model="isRevealed" append-to-body destroy-on-close class="scrollbar">
      <crontab @hide="close" @fill="confirm" :expression="expression"></crontab>
    </el-dialog>
    <template #footer>
      <div class="dialog-footer">
        <el-button type="primary" @click="submitForm" :loading="loading">保 存</el-button>
        <el-button @click="cancel">取 消</el-button>
      </div>
    </template>
  </el-dialog>
</template>
