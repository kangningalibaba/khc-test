<template>
  <div class="app-container">
    <el-form :model="queryParams" ref="queryForm" size="small" :inline="true" v-show="showSearch" label-width="68px">
      <el-form-item label="名称" prop="name">
        <el-input v-model="queryParams.name" placeholder="请输入名称" clearable @keyup.enter="handleQuery" />
      </el-form-item>
      <el-form-item label="所属设备" prop="deviceId">
        <el-select v-model="queryParams.deviceId" placeholder="请选择" style="width: 200px">
          <el-option v-for="v in devices" :key="v.id" :label="v.name" :value="v.id"></el-option>
        </el-select>
      </el-form-item>
      <el-form-item>
        <el-button type="primary" icon="Search" @click="handleQuery">搜索</el-button>
        <el-button icon="Refresh" @click="resetQuery">重置</el-button>
      </el-form-item>
    </el-form>

    <el-row :gutter="10" class="mb8">
      <el-col :span="1.5">
        <el-button type="primary" plain icon="Plus" @click="handleAdd" v-hasPermi="['scada:variable:add']"
          >新增</el-button
        >
      </el-col>
      <!-- <el-col :span="1.5">
        <el-button
          type="success"
          plain
          icon="Edit"
          :disabled="single"
          @click="handleUpdate"
          v-hasPermi="['scada:variable:edit']"
          >修改</el-button
        >
      </el-col>
      <el-col :span="1.5">
        <el-button
          type="danger"
          plain
          icon="Delete"
          :disabled="multiple"
          @click="handleDelete"
          v-hasPermi="['scada:variable:remove']"
          >删除</el-button
        >
      </el-col>
      <el-col :span="1.5">
        <el-button type="warning" plain icon="Download" @click="handleExport" v-hasPermi="['scada:variable:export']"
          >导出</el-button
        >
      </el-col> -->
      <right-toolbar v-model:showSearch="showSearch" @queryTable="getList"></right-toolbar>
    </el-row>

    <el-table v-loading="loading" :data="variableList" @selection-change="handleSelectionChange">
      <!-- <el-table-column type="selection" width="50" align="center" /> -->
      <!-- <el-table-column label="序号" width="80" align="center" prop="id" /> -->
      <el-table-column label="序号" align="center" type="index" width="60" />

      <el-table-column label="名称" align="center" prop="name" />
      <el-table-column label="所属设备" align="center" prop="deviceName" />
      <el-table-column label="数据类型" align="center" prop="dataType" />
      <el-table-column label="数据长度" align="center" prop="dataLength" />
      <el-table-column label="DB块" align="center" prop="block" />
      <el-table-column label="地址" align="center" prop="address" />
      <el-table-column label="地址字符串" align="center" prop="addressStr" />
      <el-table-column label="操作" align="center" class-name="small-padding fixed-width">
        <template #default="scope">
          <el-button
            link
            type="primary"
            icon="Edit"
            @click="handleUpdate(scope.row)"
            v-hasPermi="['scada:variable:edit']"
            >修改</el-button
          >
          <el-button
            link
            type="primary"
            icon="Delete"
            @click="handleDelete(scope.row)"
            v-hasPermi="['scada:variable:remove']"
            >删除</el-button
          >
        </template>
      </el-table-column>
    </el-table>

    <pagination
      v-show="total > 0"
      :total="total"
      v-model:page="queryParams.pageNum"
      v-model:limit="queryParams.pageSize"
      @pagination="getList" />

    <!-- 添加或修改变量管理对话框 -->
    <el-dialog :title="title" v-model="open" width="500px" append-to-body>
      <el-form ref="formRef" :model="form" :rules="rules" label-width="120px">
        <el-form-item label="名称" prop="name">
          <el-input v-model="form.name" placeholder="请输入名称" />
        </el-form-item>
        <el-form-item label="所属设备" prop="deviceId">
          <el-select v-model="form.deviceId" placeholder="请选择" @change="changeDevice">
            <el-option v-for="v in devices" :key="v.id" :label="v.name" :value="v.id"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="DB块" prop="block">
          <el-input v-model="form.block" placeholder="请输入DB块" @change="onAddress" />
        </el-form-item>
        <el-form-item label="地址" prop="address">
          <el-input v-model="form.address" placeholder="请输入地址" @change="onAddress" />
        </el-form-item>
        <el-form-item label="类型" prop="dataType">
          <el-select v-model="form.dataType" @change="changeType">
            <el-option v-for="v in dataTypes" :key="v" :label="v" :value="v"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="长度" prop="dataLength">
          <el-input v-model="form.dataLength" placeholder="请输入数据长度" />
        </el-form-item>
        <el-form-item label="地址字符串" prop="addressStr">
          <el-input v-model="form.addressStr" placeholder="请输入地址字符串" />
        </el-form-item>
      </el-form>
      <template v-slot:footer>
        <div class="dialog-footer">
          <el-button type="primary" @click="submitForm">确 定</el-button>
          <el-button @click="cancel">取 消</el-button>
        </div>
      </template>
    </el-dialog>
  </div>
</template>

<script setup name="Variable">
import { listDevice } from '@/api/scada/device'
import { addVariable, delVariable, getLast, getVariable, listVariable, updateVariable } from '@/api/scada/variable'
const { proxy } = getCurrentInstance()
const variableList = ref([]) // 变量管理表格数据
const open = ref(false) // 是否显示弹出层
const loading = ref(true) // 遮罩层
const showSearch = ref(true) // 显示搜索条件
const ids = ref([]) // 选中数组
const single = ref(true) // 非单个禁用
const multiple = ref(true) // 非多个禁用
const total = ref(0) // 总条数
const title = ref('') // 弹出层标题
const devices = ref([])
const dataTypes = ref(['short', 'int', 'float', 'bool', 'double'])
const dataLength = ref([2, 4, 4, 1, 8])

const data = reactive({
  form: {}, // 表单参数
  queryParams: {
    // 查询参数
    pageNum: 1,
    pageSize: 10,
    name: null,
    dataType: null,
    deviceId: null
  },
  rules: {
    // 表单校验
    dataType: [{ required: true, message: '数据类型不能为空', trigger: 'change' }],
    deviceId: [{ required: true, message: '所属设备不能为空', trigger: 'blur' }]
  }
})

const { queryParams, form, rules } = toRefs(data)

onMounted(() => {
  getDevice()
  getList()
})

function getDevice() {
  listDevice({ pageSize: 100000 }).then((r) => {
    devices.value = r.rows
  })
}
/** 查询变量管理列表 */
function getList() {
  loading.value = true
  listVariable(queryParams.value).then((response) => {
    variableList.value = response.rows
    total.value = response.total
    loading.value = false
  })
}
function changeDevice() {
  getLast(form.value.deviceId).then((r) => {
    if (r.data != null) {
      var lastvar = r.data
      form.value.address = lastvar.address + 1
      form.value.block = lastvar.block
      form.value.addressStr = form.value.block + form.value.address
      form.value.dataType = lastvar.dataType
      form.value.dataLength = lastvar.dataLength
      form.value.name = lastvar.name + '_1'
    }
  })
}
function changeType(i) {
  let p = dataTypes.value.indexOf(i)
  form.value.dataLength = dataLength.value[p]
}
function onAddress() {
  console.log(form.value)
  let block = ''
  let add = ''
  if (form.value.block != undefined) block = form.value.block
  if (form.value.address != undefined) add = form.value.address
  form.value.addressStr = block + add
}
// 取消按钮
function cancel() {
  open.value = false
  reset()
}
// 表单重置
function reset() {
  form.value = {
    id: null,
    name: null,
    dataType: null,
    deviceId: null,
    blockNum: null,
    address: null,
    addressStr: null
  }
  proxy.resetForm('formRef')
}
/** 搜索按钮操作 */
function handleQuery() {
  queryParams.value.pageNum = 1
  getList()
}
/** 重置按钮操作 */
function resetQuery() {
  proxy.resetForm('queryForm')
  handleQuery()
}
// 多选框选中数据
function handleSelectionChange(selection) {
  ids.value = selection.map((item) => item.id)
  single.value = selection.length !== 1
  multiple.value = !selection.length
}
/** 新增按钮操作 */
function handleAdd() {
  reset()
  open.value = true
  title.value = '添加变量管理'
}
/** 修改按钮操作 */
function handleUpdate(row) {
  reset()
  const id = row.id || ids.value
  getVariable(id).then((response) => {
    form.value = response.data
    open.value = true
    title.value = '修改变量管理'
  })
}
/** 提交按钮 */
function submitForm() {
  proxy.$refs['formRef'].validate((valid) => {
    if (valid) {
      if (form.value.id != null) {
        updateVariable(form.value).then(() => {
          proxy.$modal.msgSuccess('修改成功')
          open.value = false
          getList()
        })
      } else {
        addVariable(form.value).then(() => {
          proxy.$modal.msgSuccess('新增成功')
          open.value = false
          getList()
        })
      }
    }
  })
}
/** 删除按钮操作 */
function handleDelete(row) {
  const ids = row.id || ids.value
  proxy.$modal
    .confirm('是否确认删除变量管理名称为"' + row.name + '"的数据项？')
    .then(function () {
      return delVariable(ids)
    })
    .then(() => {
      getList()
      proxy.$modal.msgSuccess('删除成功')
    })
    .catch(() => {})
}
/** 导出按钮操作 */
// function handleExport() {
//   proxy.download(
//     'scada/variable/export',
//     {
//       ...queryParams.value
//     },
//     `variable_${new Date().getTime()}.xlsx`
//   )
// }
</script>
