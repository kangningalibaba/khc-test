import request from '@/utils/request'

export function getGlobalJs() {
  return request({
    url: '/scada/js',
    method: 'get'
  })
}

export function setGlobalJs(jsCode) {
  return request({
    url: '/scada/js',
    method: 'post',
    data: { jsCode }
  })
}
