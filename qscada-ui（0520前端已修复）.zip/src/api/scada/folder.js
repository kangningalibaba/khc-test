import request from '@/utils/request'

// 查询组态文件夹列表
export function listFolder(query) {
  return request({
    url: '/scada/folder/list',
    method: 'get',
    params: query
  })
}

// 全量查询组态文件夹
export function listAllFolder() {
  return request({
    url: '/scada/folder/listAllFolder',
    method: 'get',
    params: null
  })
}

// 查询组态文件夹详细
export function getFolder(id) {
  return request({
    url: '/scada/folder/' + id,
    method: 'get'
  })
}

// 新增组态文件夹
export function addFolder(data) {
  return request({
    url: '/scada/folder',
    method: 'post',
    data: data
  })
}

// 修改组态文件夹
export function updateFolder(data) {
  return request({
    url: '/scada/folder',
    method: 'put',
    data: data
  })
}

// 删除组态文件夹
export function delFolder(id) {
  return request({
    url: '/scada/folder/' + id,
    method: 'delete'
  })
}
