import request from '@/utils/request'

// 查询状态管理列表
export function listState(query) {
  return request({
    url: '/scada/state/list',
    method: 'get',
    params: query
  })
}

// 查询状态管理详细
export function getState(rtable, id) {
  return request({
    url: '/scada/state/' + rtable + '/' + id,
    method: 'get'
  })
}

// 新增状态管理
export function addState(data) {
  return request({
    url: '/scada/state',
    method: 'post',
    data: data
  })
}

// 修改状态管理
export function updateState(data) {
  return request({
    url: '/scada/state',
    method: 'put',
    data: data
  })
}

// 删除状态管理
export function delState(rtable, id) {
  return request({
    url: '/scada/state/' + rtable + '/' + id,
    method: 'delete'
  })
}
