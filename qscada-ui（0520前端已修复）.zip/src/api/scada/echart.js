import request from '@/utils/request'
// 查询最近一段时间的数据
export function getDataByPastTime(data) {
  return request({
    url: '/scada/echart/dataByPastTime',
    method: 'post',
    data
  })
}
// 查询时间范围内的数据
export function getDataByRange(data) {
  return request({
    url: '/scada/echart/dataByRange',
    method: 'post',
    data
  })
}
// 生成测试数据
export function generateTestData() {
  return request({
    url: '/scada/echart/testData',
    method: 'get'
  })
}
