import request from '@/utils/request'

// 查询算法管理列表
export function listAlgmng(query) {
  return request({
    url: '/scada/algmng/list',
    method: 'get',
    params: query
  })
}

// 查询算法管理详细
export function getAlgmng(algId) {
  return request({
    url: '/scada/algmng/' + algId,
    method: 'get'
  })
}

// 新增算法管理
export function addAlgmng(data) {
  return request({
    url: '/scada/algmng',
    method: 'post',
    data: data
  })
}

// 修改算法管理
export function updateAlgmng(data) {
  return request({
    url: '/scada/algmng',
    method: 'put',
    data: data
  })
}

// 删除算法管理
export function delAlgmng(algId) {
  return request({
    url: '/scada/algmng/' + algId,
    method: 'delete'
  })
}

// 测试算法
export function runTestAlgmng(algId) {
  return request({ url: '/scada/algmng/runTest/' + algId, method: 'post' })
}
// 发布算子
export function changePubStatus(algId, data = {}) {
  return request({
    url: '/scada/algmng/changePubStatus',
    method: 'put',
    data: { algId, publishStatus: 1, ...data }
  })
}
// 历史版本
export function getHistoryAlgsubmng(algId) {
  return request({ url: '/scada/algmng/history/' + algId, method: 'get' })
}
// 获取下一个版本
export function getNextVersion(algId) {
  return request({ url: '/scada/algmng/nextversion/' + algId, method: 'get' })
}
// 算法版本是否重复
export function isRepeatVersion(algId, version) {
  return request({ url: '/scada/algmng/version/isRepeat', method: 'post', data: { id: algId, version: version } })
}
// 获取算法启停日志
export function getAlgmngOptLogs(query) {
  return request({
    url: '/scada/algmng/log/opt/list',
    method: 'get',
    params: { algId: query.algId, algVersion: query.algVersion }
  })
}
// 获取算法单次启停日志
export function getAlgmngStartStopLogs(query) {
  return request({ url: '/scada/algmng/log/single/list', method: 'get', params: query })
}
// 获取算法轮次日志
export function getAlgmngLogs(query) {
  return request({
    url: '/scada/algmng/log/list',
    method: 'get',
    params: query
  })
}
// 获取算法单次执行日志
export function getAlgmngLog(logId) {
  return request({ url: '/scada/algmng/log/detail/list/' + logId, method: 'get' })
}
// 运行算法
export function runAlgmng(id, version) {
  return request({ url: '/scada/algmng/run/', method: 'post', data: { id, version } })
}
// 停止算法
export function stopAlgmng(algId) {
  return request({ url: '/scada/algmng/stop/' + algId, method: 'post' })
}
