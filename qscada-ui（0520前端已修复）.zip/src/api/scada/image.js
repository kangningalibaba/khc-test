import request from '@/utils/request'

// 查询组态文件夹关联图片列表
export function listImage(query) {
  return request({
    url: '/scada/image/list',
    method: 'get',
    params: query
  })
}

// 查询组态文件夹关联图片详细
export function getImage(id) {
  return request({
    url: '/scada/image/' + id,
    method: 'get'
  })
}

// // 新增组态文件夹关联图片
// export function addImage(data) {
//   return request({
//     url: '/scada/image',
//     method: 'post',
//     data: data,
//     headers: {
//       'Content-Type': 'multipart/form-data'
//     }
//   })
// }

// 新增组态文件夹关联图片
export function addImage(data) {
  return request({
    url: '/scada/image',
    method: 'post',
    data: data
  })
}

// 修改组态文件夹关联图片
export function updateImage(data) {
  return request({
    url: '/scada/image',
    method: 'put',
    data: data
  })
}

// 删除组态文件夹关联图片
export function delImage(id) {
  return request({
    url: '/scada/image/' + id,
    method: 'delete'
  })
}

// 获取所有图片
export function getAllImages() {
  return request({
    url: '/scada/image/listFolderIma',
    method: 'get'
  })
}
// 根据文件夹id获取图片
export function getImagesByFolderId(folderId) {
  return request({
    url: '/scada/image/listFolderIdIma',
    method: 'get',
    params: {
      folderId
    }
  })
}
