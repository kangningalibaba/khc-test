import request from '@/utils/request'

// 查询组态画面列表
export function listScene(query) {
  return request({
    url: '/scada/scene/list',
    method: 'get',
    params: query
  })
}

// 查询组态画面详细
export function getScene(id) {
  return request({
    url: '/scada/scene/' + id,
    method: 'get'
  })
}

// 新增组态画面
export function addScene(data) {
  return request({
    url: '/scada/scene',
    method: 'post',
    data: data
  })
}

// 修改组态画面
export function updateScene(data) {
  return request({
    url: '/scada/scene',
    method: 'put',
    data: data
  })
}

// 删除组态画面
export function delScene(id) {
  return request({
    url: '/scada/scene/' + id,
    method: 'delete'
  })
}

export function setVar(n, v) {
  return request({
    url: '/scada/scene/set/' + n + '/' + v,
    method: 'get'
  })
}
