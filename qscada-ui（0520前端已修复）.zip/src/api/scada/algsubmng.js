import request from '@/utils/request'

// 查询算子分类以及分类下的所有算子
export function allAlgsubmng() {
  return request({ url: '/scada/algsubmng/list/all', method: 'get' })
}

// 查询算子管理列表
export function listAlgsubmng(query) {
  return request({ url: '/scada/algsubmng/list', method: 'get', params: query })
}

// 查询算子管理详细
export function getAlgsubmng(algsId) {
  return request({ url: '/scada/algsubmng/' + algsId, method: 'get' })
}

// 新增算子管理
export function addAlgsubmng(data) {
  return request({ url: '/scada/algsubmng', method: 'post', data: data })
}

// 修改算子管理
export function updateAlgsubmng(data) {
  return request({ url: '/scada/algsubmng', method: 'put', data: data })
}

// 删除算子管理
export function delAlgsubmng(algsId) {
  return request({ url: '/scada/algsubmng/' + algsId, method: 'delete' })
}

// 获取算子源代码以及版本号
export function getAlgsubmngCode(algsId, version) {
  return request({ url: '/scada/algsubmng/code/' + algsId, method: 'get', params: { version: version ?? '' } })
}
// 校验算子
export function checkAlgsubmng(algsId) {
  return request({ url: '/scada/algsubmng/check/' + algsId, method: 'get' })
}
// 测试算子
export function runTestAlgsubmng(algsId, data = [{}]) {
  return request({ url: '/scada/algsubmng/runTest/' + algsId, method: 'post', data: data })
}
// 发布算子
export function changePubStatus(algsId, data = {}) {
  return request({
    url: '/scada/algsubmng/changePubStatus',
    method: 'put',
    data: { algsId, publishStatus: 1, ...data }
  })
}
// 历史版本
export function getHistoryAlgsubmng(algsId) {
  return request({ url: '/scada/algsubmng/history/' + algsId, method: 'get' })
}
// 获取下一个版本
export function getNextVersion(algsId) {
  return request({ url: '/scada/algsubmng/nextversion/' + algsId, method: 'get' })
}
// 算子版本是否重复
export function isRepeatVersion(algsId, version) {
  return request({ url: '/scada/algsubmng/version/isRepeat', method: 'post', data: { id: algsId, version: version } })
}
// 设置默认版本
export function setDefaultVersion(algsId, version) {
  return request({
    url: '/scada/algsubmng/version/default',
    method: 'post',
    data: { id: algsId, version: version }
  })
}
