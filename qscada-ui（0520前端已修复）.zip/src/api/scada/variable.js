import request from '@/utils/request'

// 查询变量管理列表
export function listVariable(query) {
  return request({
    url: '/scada/variable/list',
    method: 'get',
    params: query
  })
}

// 查询变量管理详细
export function getVariable(id) {
  return request({
    url: '/scada/variable/' + id,
    method: 'get'
  })
}

export function getLast(id) {
  return request({
    url: '/scada/variable/last/' + id,
    method: 'get'
  })
}

// 新增变量管理
export function addVariable(data) {
  return request({
    url: '/scada/variable',
    method: 'post',
    data: data
  })
}

// 修改变量管理
export function updateVariable(data) {
  return request({
    url: '/scada/variable',
    method: 'put',
    data: data
  })
}

// 删除变量管理
export function delVariable(id) {
  return request({
    url: '/scada/variable/' + id,
    method: 'delete'
  })
}
// 设置变量值
export function setVariable(data) {
  return request({
    url: `/scada/variable/set/${data.variable}/${data.value}`,
    method: 'get'
  })
}

// 设置多个变量值
export function setVariables(data) {
  return request({
    url: `/scada/variable/setvars`,
    method: 'post',
    data: data
  })
}
