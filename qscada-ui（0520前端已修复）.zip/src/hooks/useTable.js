import { reactive, ref } from 'vue'
// 自定义的 useTable 钩子函数，用于处理表格相关的数据和操作
export default function useTable(apiRequest, options = { uniqueId: 'id', params: {} }) {
  // 获取传入的参数
  const { uniqueId, params, formatParams, formatResult, errorCallback } = options
  // 表格数据数组
  const tableData = ref([])
  // 加载状态标识
  const loading = ref(false)
  // 数据总数
  const total = ref(0)
  // 选中的行的 ID 数组
  const selectedIds = ref([])
  // 是否为单选标识
  const isSingle = ref(true)
  // 是否为多选标识
  const hasMultiple = ref(false)
  // 初始化参数
  const defaultParams = Object.assign({}, params)
  // 查询参数对象，初始值为默认参数
  const queryParams = ref({ ...defaultParams })
  // 分页参数对象
  const page = reactive({
    pageNum: 1,
    pageSize: 10
  })
  /**
   * 获取表格数据的函数
   * @param {params} - 传递给 apiRequest 的参数
   * @returns {Promise} 返回一个 Promise 对象
   */
  const getList = (params = {}) => {
    loading.value = true // 开始加载，设置 loading 为 true
    let parameters = queryParams.value
    if (typeof formatParams === 'function') {
      parameters = formatParams(queryParams.value)
    }
    Object.assign(parameters, page, params)
    // 调用传入的 apiRequest 函数请求数据
    apiRequest(parameters)
      .then((response) => {
        // 请求成功，设置表格数据和总数
        let data = response.rows
        if (formatResult) {
          data = formatResult(response)
        }
        tableData.value = data
        total.value = response.total
      })
      .catch((error) => {
        if (errorCallback) {
          errorCallback(error) // 捕获错误并拒绝 Promise
        }
      })
      .finally(() => {
        loading.value = false // 无论成功或失败，都设置 loading 为 false
      })
  }

  /**
   * 处理表格行选择变化的函数
   * @param {Array} selection - 当前选中的行数据数组
   */
  const handleSelectionChange = (selection) => {
    // 更新选中的行的 ID 数组
    selectedIds.value = selection.map((item) => item[uniqueId])
    // 根据选中行的数量更新单选和多选的标识
    isSingle.value = selection.length === 1
    hasMultiple.value = selection.length > 1
  }

  const handleQuery = () => {
    page.pageNum = 1
    getList()
  }

  const resetQuery = () => {
    // 重置查询参数为默认参数
    queryParams.value = { ...defaultParams }
    getList()
  }

  // 返回所有相关的响应式数据和函数，以便在组件中使用
  return {
    tableData,
    loading,
    total,
    selectedIds,
    isSingle,
    hasMultiple,
    queryParams,
    page,
    getList,
    resetQuery,
    handleQuery,
    handleSelectionChange
  }
}
