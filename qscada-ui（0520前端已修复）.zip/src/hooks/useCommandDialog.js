import { createVNode, getCurrentInstance, render } from 'vue'

const getAppendTarget = (props) => {
  // 获取要附加到的目标元素，默认为 document.body
  let appendTo = props?.appendTo || document.body

  // 如果 appendTo 是字符串，则尝试通过 querySelector 获取元素
  if (typeof appendTo === 'string') {
    appendTo = document.querySelector(appendTo)
  }
  // 如果 appendTo 不是 HTMLElement，则设置为 document.body
  else if (!(appendTo instanceof HTMLElement)) {
    appendTo = document.body
  }

  return appendTo
}

const initInstance = (Component, props, container, appContext = null) => {
  // 创建虚拟节点
  const vNode = createVNode(Component, props)
  vNode.appContext = appContext
  // 渲染虚拟节点到容器中
  render(vNode, container)

  // 将容器附加到目标元素
  getAppendTarget(props).appendChild(container)
  return vNode
}

export const useCommandDialog = (Component) => {
  // 获取当前应用上下文
  const appContext = getCurrentInstance()?.appContext
  if (appContext) {
    // 合并当前实例的 provides 到 appContext
    const currentProvides = getCurrentInstance()?.provides
    appContext.provides = { ...appContext.provides, ...currentProvides }
  }

  // 创建一个 div 容器用于挂载组件
  const container = document.createElement('div')

  // 定义关闭组件的方法
  const close = () => {
    // 渲染 null 到容器中以卸载组件
    render(null, container)
    // 移除容器元素
    container.parentNode?.removeChild(container)
  }

  // 定义 CommandDialog 函数，用于创建并显示组件实例
  const CommandDialog = (options) => {
    // 如果 options 中没有 visible 属性，则默认设置为 true
    if (!Object.prototype.hasOwnProperty.call(options, 'visible')) {
      options.visible = true
    }
    // 如果 options 中没有 onClose 回调，则使用默认的 close 方法
    if (typeof options.onClose !== 'function') {
      options.onClose = close
    } else {
      // 如果有 onClose 回调，则在调用原 onClose 后调用默认的 close 方法
      const originOnClose = options.onClose
      options.onClose = () => {
        originOnClose?.()
        close()
      }
    }
    // 初始化组件实例
    const vNode = initInstance(Component, options, container, appContext)
    const vm = vNode.component?.proxy
    // 将 options 中非 props 的属性赋值给组件实例
    for (const prop in options) {
      if (
        Object.prototype.hasOwnProperty.call(options, prop) &&
        !Object.prototype.hasOwnProperty.call(vm.$props, prop)
      ) {
        vm[prop] = options[prop]
      }
    }
    return vNode
  }

  // 将 close 方法挂载到 CommandDialog 上
  CommandDialog.close = close

  return CommandDialog
}

export default useCommandDialog
