import { onMounted, onUnmounted, ref } from 'vue'

/**
 * WebSocket 服务类，负责建立和管理 WebSocket 连接
 */
class WebSocketService {
  /**
   * 构造函数，初始化 WebSocket 连接
   * @param {string} url - WebSocket 服务器的 URL
   */
  constructor(url) {
    this.url = url
    this.socket = null
    this.isAlive = false // 用于判断心跳是否正常
    this.reconnectAttempts = 0 // 重连尝试次数
    this.MAX_RECONNECT_ATTEMPTS = 5 // 最大重连次数
    this.HEARTBEAT_INTERVAL = 30000 // 心跳间隔时间 (30秒)
    this.heartbeatTimer = null
    this.reconnectTimer = null

    this.connect()
  }

  /**
   * 建立 WebSocket 连接
   */
  connect() {
    this.socket = new WebSocket(this.url)

    this.socket.onopen = () => {
      console.log('WebSocket 连接已建立')
      this.reconnectAttempts = 0 // 成功连接后重置重试次数
      this.startHeartbeat() // 开始心跳检测
    }

    this.socket.onmessage = (event) => {
      // 处理接收到的消息
      console.log('收到消息:', event.data)
    }

    this.socket.onclose = () => {
      console.log('WebSocket 连接已关闭')
      this.stopHeartbeat()
      this.attemptReconnect()
    }

    this.socket.onerror = (error) => {
      console.error('WebSocket 错误:', error)
    }
  }

  /**
   * 启动心跳检测机制
   */
  startHeartbeat() {
    if (!this.heartbeatTimer) {
      this.heartbeatTimer = setInterval(() => {
        if (this.socket.readyState === WebSocket.OPEN) {
          this.isAlive = false
          this.sendPing()
        }
      }, this.HEARTBEAT_INTERVAL)
    }
  }

  /**
   * 停止心跳检测机制
   */
  stopHeartbeat() {
    if (this.heartbeatTimer) {
      clearInterval(this.heartbeatTimer)
      this.heartbeatTimer = null
    }
  }

  /**
   * 发送心跳包
   */
  sendPing() {
    this.socket.send(JSON.stringify({ type: 'ping' }))
    setTimeout(() => {
      if (!this.isAlive) {
        console.warn('WebSocket 心跳失败，尝试重新连接...')
        this.socket.close()
      }
    }, this.HEARTBEAT_INTERVAL / 2) // 如果没有pong响应，则关闭并重连
  }

  /**
   * 接收心跳响应包
   */
  receivePong() {
    this.isAlive = true
  }

  /**
   * 尝试重连
   */
  attemptReconnect() {
    if (this.reconnectAttempts < this.MAX_RECONNECT_ATTEMPTS) {
      this.reconnectAttempts++
      console.log(`正在尝试重新连接 (${this.reconnectAttempts})...`)
      this.reconnectTimer = setTimeout(() => {
        this.connect()
      }, 1000 * this.reconnectAttempts) // 指数退避算法
    } else {
      console.error('达到最大重连次数')
    }
  }

  /**
   * 发送消息
   * @param {Object} message - 要发送的消息对象
   */
  sendMessage(message) {
    if (this.socket && this.socket.readyState === WebSocket.OPEN) {
      this.socket.send(JSON.stringify(message))
    }
  }

  /**
   * 关闭 WebSocket 连接
   */
  close() {
    this.stopHeartbeat()
    if (this.reconnectTimer) {
      clearTimeout(this.reconnectTimer)
      this.reconnectTimer = null
    }
    if (this.socket) {
      this.socket.close()
      this.socket = null
    }
  }
}

/**
 * Vue 自定义 Hook，用于管理 WebSocket 连接
 * @param {string} url - WebSocket 服务器的 URL
 * @returns {Object} - 包含连接状态、发送消息和接收消息的函数
 */
export default function useWebSocket(url) {
  const ws = new WebSocketService(url)

  const message = ref(null)
  const isConnected = ref(false)

  /**
   * 设置消息接收的回调函数
   * @param {Function} callback - 消息接收时的回调函数
   */
  const onMessage = (callback) => {
    ws.socket.onmessage = (event) => {
      message.value = event.data
      callback(event.data)
      if (event.data.includes('pong')) {
        ws.receivePong()
      }
    }
  }

  /**
   * 设置连接关闭的回调函数
   * @param {Function} callback - 连接关闭时的回调函数
   */
  const onClose = (callback) => {
    ws.socket.onclose = () => {
      isConnected.value = false
      callback()
    }
  }

  /**
   * 设置连接建立的回调函数
   * @param {Function} callback - 连接建立时的回调函数
   */
  const onOpen = (callback) => {
    ws.socket.onopen = () => {
      isConnected.value = true
      callback()
    }
  }

  // 生命周期钩子：挂载时
  onMounted(() => {
    onOpen(() => console.log('已连接'))
    onClose(() => console.log('已断开连接'))
    onMessage((data) => console.log('收到:', data))
  })

  // 生命周期钩子：卸载时
  onUnmounted(() => {
    ws.close()
  })

  return { isConnected, sendMessage: ws.sendMessage.bind(ws), message }
}
