import autoImport from 'unplugin-auto-import/vite'

export default function createAutoImport() {
    return autoImport({
      imports: ['vue', 'vue-router', 'pinia', '@vueuse/core'],
      dts: false,
      eslintrc: {
        enabled: true,
        filepath: './.eslintrc-auto-import.mjs',
        globalsPropValue: true
      }
    })
}
