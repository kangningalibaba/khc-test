import { resolve } from 'path'
import { createSvgIconsPlugin } from 'vite-plugin-svg-icons'

export default function createSvgIcon() {
  return createSvgIconsPlugin({
    iconDirs: [resolve(process.cwd(), 'src/assets/icons/svg'), resolve(process.cwd(), 'src/assets/svgs')],
    symbolId: 'icon-[dir]-[name]',
    // 禁用压缩 否则想要修改无状态组件的stroke或者fill会影响到预设样式 例如stroke-width
    svgoOptions: false
  })
}
