import pluginJs from '@eslint/js'
import skipFormatting from '@vue/eslint-config-prettier/skip-formatting'
import pluginVue from 'eslint-plugin-vue'
import globals from 'globals'
import autoImport from './.eslintrc-auto-import.mjs'

export default [
  {
    name: 'app/files-to-lint',
    files: ['src/**/*.{js,mjs,jsx,vue}']
  },

  {
    name: 'app/files-to-ignore',
    ignores: ['**/dist/**', '**/dist-ssr/**', '**/coverage/**']
  },

  pluginJs.configs.recommended,
  ...pluginVue.configs['flat/essential'],
  skipFormatting,
  {
    languageOptions: {
      globals: {
        ...globals.browser,
        ...globals.node,
        ...autoImport.globals,
        meta2d: true
      }
    },
    settings: {
      'import/resolver': {
        // eslint-import-resolver-alias 可以解决绝对路径的问题
        alias: {
          map: [
            ['', './public'], // <-- this line
            ['@', './src'] // <-- this line
          ],
          extensions: ['.js', '.jsx', '.ts', '.tsx', '.svg', '.vue']
        }
      }
    },
    rules: {
      'max-lines': ['warn', { max: 600, skipBlankLines: true, skipComments: true }],
      'no-empty': ['error', { allowEmptyCatch: true }],
      'no-unused-vars': ['error', { caughtErrors: 'none' }],
      'vue/multi-word-component-names': 'off'
    }
  }
]
